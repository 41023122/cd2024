﻿# NX 1872
# Journal created by Admin on Fri Jun 14 15:10:35 2024 台北標準時間

#
import math
import NXOpen
import NXOpen.Annotations
import NXOpen.Assemblies
import NXOpen.Drawings
import NXOpen.Features
import NXOpen.GeometricUtilities
import NXOpen.Preferences
def main() : 

    theSession  = NXOpen.Session.GetSession()
    # ----------------------------------------------
    #   Menu: File->New...
    # ----------------------------------------------
    markId1 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    fileNew1 = theSession.Parts.FileNew()
    
    theSession.SetUndoMarkName(markId1, "New Dialog")
    
    markId2 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    theSession.DeleteUndoMark(markId2, None)
    
    markId3 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "New")
    
    fileNew1.TemplateFileName = "model-plain-1-mm-template.prt"
    
    fileNew1.UseBlankTemplate = False
    
    fileNew1.ApplicationName = "ModelTemplate"
    
    fileNew1.Units = NXOpen.Part.Units.Millimeters
    
    fileNew1.RelationType = ""
    
    fileNew1.UsesMasterModel = "No"
    
    fileNew1.TemplateType = NXOpen.FileNewTemplateType.Item
    
    fileNew1.TemplatePresentationName = "Model"
    
    fileNew1.ItemType = ""
    
    fileNew1.Specialization = ""
    
    fileNew1.SetCanCreateAltrep(False)
    
    fileNew1.NewFileName = "F:\\Siemens_NX1872\\Siemens\\car.prt"
    
    fileNew1.MasterFileName = ""
    
    fileNew1.MakeDisplayedPart = True
    
    fileNew1.DisplayPartOption = NXOpen.DisplayPartOption.AllowAdditional
    
    # User Function call - UF_PART_ask_part_name
    
    nXObject1 = fileNew1.Commit()
    
    workPart = theSession.Parts.Work
    displayPart = theSession.Parts.Display
    theSession.DeleteUndoMark(markId3, None)
    
    fileNew1.Destroy()
    
    theSession.ApplicationSwitchImmediate("UG_APP_MODELING")
    
    # ----------------------------------------------
    #   Menu: Insert->Datum/Point->Datum Plane...
    # ----------------------------------------------
    markId4 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    datumPlaneBuilder1 = workPart.Features.CreateDatumPlaneBuilder(NXOpen.Features.Feature.Null)
    
    plane1 = datumPlaneBuilder1.GetPlane()
    
    unit1 = workPart.UnitCollection.FindObject("MilliMeter")
    expression1 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression2 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    coordinates1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point1 = workPart.Points.CreatePoint(coordinates1)
    
    theSession.SetUndoMarkName(markId4, "Datum Plane Dialog")
    
    plane1.SetUpdateOption(NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane1.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom1 = [NXOpen.NXObject.Null] * 1 
    datumPlane1 = workPart.Datums.FindObject("DATUM_CSYS(0) XY plane")
    geom1[0] = datumPlane1
    plane1.SetGeometry(geom1)
    
    plane1.SetFlip(False)
    
    plane1.SetReverseSide(False)
    
    expression3 = plane1.Expression
    
    expression3.RightHandSide = "0"
    
    plane1.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane1.Evaluate()
    
    plane1.SetMethod(NXOpen.PlaneTypes.MethodType.Distance)
    
    geom2 = [NXOpen.NXObject.Null] * 1 
    geom2[0] = datumPlane1
    plane1.SetGeometry(geom2)
    
    plane1.SetFlip(False)
    
    plane1.SetReverseSide(False)
    
    expression4 = plane1.Expression
    
    expression4.RightHandSide = "0"
    
    plane1.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane1.Evaluate()
    
    coordinates2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2 = workPart.Points.CreatePoint(coordinates2)
    
    workPart.Points.DeletePoint(point1)
    
    coordinates3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point3 = workPart.Points.CreatePoint(coordinates3)
    
    workPart.Points.DeletePoint(point2)
    
    coordinates4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point4 = workPart.Points.CreatePoint(coordinates4)
    
    workPart.Points.DeletePoint(point3)
    
    coordinates5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point5 = workPart.Points.CreatePoint(coordinates5)
    
    workPart.Points.DeletePoint(point4)
    
    markId5 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    theSession.DeleteUndoMark(markId5, None)
    
    markId6 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Datum Plane")
    
    plane1.RemoveOffsetData()
    
    plane1.Evaluate()
    
    corner1_1 = NXOpen.Point3d(-14.867383554553019, -14.867383554553019, 0.0)
    corner2_1 = NXOpen.Point3d(14.867383554553019, -14.867383554553019, 0.0)
    corner3_1 = NXOpen.Point3d(14.867383554553019, 14.867383554553019, 0.0)
    corner4_1 = NXOpen.Point3d(-14.867383554553019, 14.867383554553019, 0.0)
    datumPlaneBuilder1.SetCornerPoints(corner1_1, corner2_1, corner3_1, corner4_1)
    
    datumPlaneBuilder1.ResizeDuringUpdate = True
    
    feature1 = datumPlaneBuilder1.CommitFeature()
    
    datumPlaneFeature1 = feature1
    datumPlane2 = datumPlaneFeature1.DatumPlane
    
    datumPlane2.SetReverseSection(False)
    
    theSession.DeleteUndoMark(markId6, None)
    
    theSession.SetUndoMarkName(markId4, "Datum Plane")
    
    datumPlaneBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId7 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder1 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane2 = workPart.Planes.CreatePlane(origin1, normal1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder1.PlaneReference = plane2
    
    expression5 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression6 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder1 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder1.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId7, "Create Sketch Dialog")
    
    markId8 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId8, None)
    
    markId9 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject2 = sketchInPlaceBuilder1.Commit()
    
    sketch1 = nXObject2
    feature2 = sketch1.Feature
    
    markId10 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs1 = theSession.UpdateManager.DoUpdate(markId10)
    
    sketch1.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId9, None)
    
    theSession.SetUndoMarkName(markId7, "Create Sketch")
    
    sketchInPlaceBuilder1.Destroy()
    
    sketchAlongPathBuilder1.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression6)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression5)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane2.DestroyPlane()
    
    scaleAboutPoint1 = NXOpen.Point3d(21.534107132586694, -11.504522988642217, 0.0)
    viewCenter1 = NXOpen.Point3d(-21.534107132586694, 11.504522988642217, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint1, viewCenter1)
    
    scaleAboutPoint2 = NXOpen.Point3d(29.867511605128829, -30.604981027477677, 0.0)
    viewCenter2 = NXOpen.Point3d(-29.867511605128829, 30.604981027477677, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint2, viewCenter2)
    
    scaleAboutPoint3 = NXOpen.Point3d(38.256226284347051, -43.326328562995492, 0.0)
    viewCenter3 = NXOpen.Point3d(-38.256226284347051, 43.326328562995492, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint3, viewCenter3)
    
    scaleAboutPoint4 = NXOpen.Point3d(53.581762717534353, -49.548726814064004, 0.0)
    viewCenter4 = NXOpen.Point3d(-53.581762717534353, 49.548726814063954, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint4, viewCenter4)
    
    scaleAboutPoint5 = NXOpen.Point3d(45.630920507835704, -40.560818229187305, 0.0)
    viewCenter5 = NXOpen.Point3d(-45.630920507835704, 40.560818229187227, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint5, viewCenter5)
    
    scaleAboutPoint6 = NXOpen.Point3d(41.298287651536135, -34.661062850396462, 0.0)
    viewCenter6 = NXOpen.Point3d(-41.298287651536135, 34.661062850396334, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint6, viewCenter6)
    
    scaleAboutPoint7 = NXOpen.Point3d(34.513568965926645, -28.318825818196249, 0.0)
    viewCenter7 = NXOpen.Point3d(-34.513568965926702, 28.318825818196174, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint7, viewCenter7)
    
    scaleAboutPoint8 = NXOpen.Point3d(31.150708400015844, -23.835011730315184, 0.0)
    viewCenter8 = NXOpen.Point3d(-31.150708400015844, 23.835011730315085, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint8, viewCenter8)
    
    scaleAboutPoint9 = NXOpen.Point3d(26.619696269104445, -19.445593728494774, 0.0)
    viewCenter9 = NXOpen.Point3d(-26.619696269104445, 19.445593728494661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint9, viewCenter9)
    
    scaleAboutPoint10 = NXOpen.Point3d(-13.744070130431236, 18.124048523645527, 0.0)
    viewCenter10 = NXOpen.Point3d(13.744070130431236, -18.12404852364563, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint10, viewCenter10)
    
    scaleAboutPoint11 = NXOpen.Point3d(-17.180087663039046, 22.655060654556927, 0.0)
    viewCenter11 = NXOpen.Point3d(17.180087663039046, -22.655060654557023, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint11, viewCenter11)
    
    scaleAboutPoint12 = NXOpen.Point3d(-21.475109578798808, 28.318825818196181, 0.0)
    viewCenter12 = NXOpen.Point3d(21.475109578798808, -28.31882581819626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint12, viewCenter12)
    
    scaleAboutPoint13 = NXOpen.Point3d(-26.843886973498506, 35.398532272745243, 0.0)
    viewCenter13 = NXOpen.Point3d(26.843886973498506, -35.3985322727453, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint13, viewCenter13)
    
    scaleAboutPoint14 = NXOpen.Point3d(-21.475109578798808, 28.318825818196181, 0.0)
    viewCenter14 = NXOpen.Point3d(21.475109578798808, -28.318825818196242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint14, viewCenter14)
    
    scaleAboutPoint15 = NXOpen.Point3d(-17.180087663039046, 22.655060654556944, 0.0)
    viewCenter15 = NXOpen.Point3d(17.180087663039046, -22.655060654557008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint15, viewCenter15)
    
    scaleAboutPoint16 = NXOpen.Point3d(-13.744070130431236, 18.124048523645566, 0.0)
    viewCenter16 = NXOpen.Point3d(13.744070130431236, -18.124048523645605, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint16, viewCenter16)
    
    # ----------------------------------------------
    #   Menu: Edit->Delete...
    # ----------------------------------------------
    markId11 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Delete")
    
    notifyOnDelete1 = theSession.Preferences.Modeling.NotifyOnDelete
    
    theSession.UpdateManager.ClearErrorList()
    
    markId12 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Delete")
    
    objects1 = [NXOpen.TaggedObject.Null] * 1 
    datumCsys1 = workPart.Features.FindObject("DATUM_CSYS(0)")
    objects1[0] = datumCsys1
    nErrs2 = theSession.UpdateManager.AddObjectsToDeleteList(objects1)
    
    notifyOnDelete2 = theSession.Preferences.Modeling.NotifyOnDelete
    
    id1 = theSession.NewestVisibleUndoMark
    
    nErrs3 = theSession.UpdateManager.DoUpdate(id1)
    
    theSession.DeleteUndoMark(markId11, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId13 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder2 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal2 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane3 = workPart.Planes.CreatePlane(origin2, normal2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder2.PlaneReference = plane3
    
    expression7 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression8 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder2 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder2.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId13, "Create Sketch Dialog")
    
    rotMatrix1 = NXOpen.Matrix3x3()
    
    rotMatrix1.Xx = 0.99837021662907477
    rotMatrix1.Xy = 0.037863495785907642
    rotMatrix1.Xz = -0.042699721719060252
    rotMatrix1.Yx = 0.011910157837822821
    rotMatrix1.Yy = 0.59349556825557548
    rotMatrix1.Yz = 0.80474912774185092
    rotMatrix1.Zx = 0.05581271081297505
    rotMatrix1.Zy = -0.8039461214209952
    rotMatrix1.Zz = 0.59207733883661318
    translation1 = NXOpen.Point3d(-21.395713620788747, 14.290239984622751, 0.0)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix1, translation1, 2.1897701249376818)
    
    markId14 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId14, None)
    
    markId15 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId16 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject3 = sketchInPlaceBuilder2.Commit()
    
    sketch2 = nXObject3
    feature3 = sketch2.Feature
    
    markId17 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs4 = theSession.UpdateManager.DoUpdate(markId17)
    
    sketch2.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId15, None)
    
    theSession.SetUndoMarkName(markId13, "Create Sketch")
    
    sketchInPlaceBuilder2.Destroy()
    
    sketchAlongPathBuilder2.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression8)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression7)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane3.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId18 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId19 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId19, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    endPoint1 = NXOpen.Point3d(1.1117074095763466e-14, 22.0, 0.0)
    line1 = workPart.Curves.CreateLine(startPoint1, endPoint1)
    
    startPoint2 = NXOpen.Point3d(1.1117074095763466e-14, 22.0, 0.0)
    endPoint2 = NXOpen.Point3d(25.132013952788544, 22.0, 0.0)
    line2 = workPart.Curves.CreateLine(startPoint2, endPoint2)
    
    startPoint3 = NXOpen.Point3d(25.132013952788544, 22.0, 0.0)
    endPoint3 = NXOpen.Point3d(25.132013952788537, -3.656035269904474e-14, 0.0)
    line3 = workPart.Curves.CreateLine(startPoint3, endPoint3)
    
    startPoint4 = NXOpen.Point3d(25.132013952788537, -3.656035269904474e-14, 0.0)
    endPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    line4 = workPart.Curves.CreateLine(startPoint4, endPoint4)
    
    theSession.ActiveSketch.AddGeometry(line1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line4, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_1.Geometry = line1
    geom1_1.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_1.SplineDefiningPointIndex = 0
    geom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_1.Geometry = line2
    geom2_1.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint1 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_1, geom2_1)
    
    geom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_2.Geometry = line2
    geom1_2.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_2.SplineDefiningPointIndex = 0
    geom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_2.Geometry = line3
    geom2_2.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint2 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_2, geom2_2)
    
    geom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_3.Geometry = line3
    geom1_3.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_3.SplineDefiningPointIndex = 0
    geom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_3.Geometry = line4
    geom2_3.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint3 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_3, geom2_3)
    
    geom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_4.Geometry = line4
    geom1_4.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_4.SplineDefiningPointIndex = 0
    geom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_4.Geometry = line1
    geom2_4.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint4 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_4, geom2_4)
    
    geom3 = NXOpen.Sketch.ConstraintGeometry()
    
    geom3.Geometry = line2
    geom3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint5 = theSession.ActiveSketch.CreateHorizontalConstraint(geom3)
    
    conGeom1_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_1.Geometry = line1
    conGeom1_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_1.SplineDefiningPointIndex = 0
    conGeom2_1 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_1.Geometry = line2
    conGeom2_1.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_1.SplineDefiningPointIndex = 0
    sketchGeometricConstraint6 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_1, conGeom2_1)
    
    conGeom1_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_2.Geometry = line2
    conGeom1_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_2.SplineDefiningPointIndex = 0
    conGeom2_2 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_2.Geometry = line3
    conGeom2_2.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_2.SplineDefiningPointIndex = 0
    sketchGeometricConstraint7 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_2, conGeom2_2)
    
    conGeom1_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_3.Geometry = line3
    conGeom1_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_3.SplineDefiningPointIndex = 0
    conGeom2_3 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_3.Geometry = line4
    conGeom2_3.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_3.SplineDefiningPointIndex = 0
    sketchGeometricConstraint8 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_3, conGeom2_3)
    
    conGeom1_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_4.Geometry = line4
    conGeom1_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_4.SplineDefiningPointIndex = 0
    conGeom2_4 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_4.Geometry = line1
    conGeom2_4.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_4.SplineDefiningPointIndex = 0
    sketchGeometricConstraint9 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_4, conGeom2_4)
    
    geom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_5.Geometry = line1
    geom1_5.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_5.SplineDefiningPointIndex = 0
    geom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    datumCsys2 = workPart.Features.FindObject("SKETCH(1:1B)")
    point6 = datumCsys2.FindObject("POINT 1")
    geom2_5.Geometry = point6
    geom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint10 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_5, geom2_5)
    
    dimObject1_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_1.Geometry = line1
    dimObject1_1.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_1.AssocValue = 0
    dimObject1_1.HelpPoint.X = 0.0
    dimObject1_1.HelpPoint.Y = 0.0
    dimObject1_1.HelpPoint.Z = 0.0
    dimObject1_1.View = NXOpen.NXObject.Null
    dimObject2_1 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_1.Geometry = line1
    dimObject2_1.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_1.AssocValue = 0
    dimObject2_1.HelpPoint.X = 0.0
    dimObject2_1.HelpPoint.Y = 0.0
    dimObject2_1.HelpPoint.Z = 0.0
    dimObject2_1.View = NXOpen.NXObject.Null
    dimOrigin1 = NXOpen.Point3d(4.1100204526062489, 10.999999999999998, 0.0)
    sketchDimensionalConstraint1 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_1, dimObject2_1, dimOrigin1, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint1 = sketchDimensionalConstraint1
    dimension1 = sketchHelpedDimensionalConstraint1.AssociatedDimension
    
    expression9 = sketchHelpedDimensionalConstraint1.AssociatedExpression
    
    dimObject1_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_2.Geometry = line2
    dimObject1_2.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_2.AssocValue = 0
    dimObject1_2.HelpPoint.X = 0.0
    dimObject1_2.HelpPoint.Y = 0.0
    dimObject1_2.HelpPoint.Z = 0.0
    dimObject1_2.View = NXOpen.NXObject.Null
    dimObject2_2 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_2.Geometry = line2
    dimObject2_2.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_2.AssocValue = 0
    dimObject2_2.HelpPoint.X = 0.0
    dimObject2_2.HelpPoint.Y = 0.0
    dimObject2_2.HelpPoint.Z = 0.0
    dimObject2_2.View = NXOpen.NXObject.Null
    dimOrigin2 = NXOpen.Point3d(12.566006976394277, 17.889979547393757, 0.0)
    sketchDimensionalConstraint2 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_2, dimObject2_2, dimOrigin2, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint2 = sketchDimensionalConstraint2
    dimension2 = sketchHelpedDimensionalConstraint2.AssociatedDimension
    
    expression10 = sketchHelpedDimensionalConstraint2.AssociatedExpression
    
    dimObject1_3 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis1 = workPart.Datums.FindObject("SKETCH(1:1B) X axis")
    dimObject1_3.Geometry = datumAxis1
    dimObject1_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_3.AssocValue = 0
    dimObject1_3.HelpPoint.X = 28.574999999999999
    dimObject1_3.HelpPoint.Y = 0.0
    dimObject1_3.HelpPoint.Z = 0.0
    dimObject1_3.View = NXOpen.NXObject.Null
    dimObject2_3 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_3.Geometry = line1
    dimObject2_3.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_3.AssocValue = 0
    dimObject2_3.HelpPoint.X = 1.1117074095763466e-14
    dimObject2_3.HelpPoint.Y = 22.0
    dimObject2_3.HelpPoint.Z = 0.0
    dimObject2_3.View = NXOpen.NXObject.Null
    dimOrigin3 = NXOpen.Point3d(2.9062233328532789, 2.9062233328532776, 0.0)
    sketchDimensionalConstraint3 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_3, dimObject2_3, dimOrigin3, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension3 = sketchDimensionalConstraint3.AssociatedDimension
    
    expression11 = sketchDimensionalConstraint3.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms1 = [NXOpen.SmartObject.Null] * 4 
    geoms1[0] = line1
    geoms1[1] = line2
    geoms1[2] = line3
    geoms1[3] = line4
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms1)
    
    geoms2 = [NXOpen.SmartObject.Null] * 4 
    geoms2[0] = line1
    geoms2[1] = line2
    geoms2[2] = line3
    geoms2[3] = line4
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms2)
    
    markId20 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension1 = dimension2
    sketchLinearDimensionBuilder1 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension1)
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId20, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits1 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits2 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits3 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits4 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits5 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits6 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits7 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits8 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits9 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits10 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits11 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits12 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits13 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits14 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits15 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits16 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits17 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits18 = sketchLinearDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId21 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId21, None)
    
    markId22 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("100")
    
    sketchLinearDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    nXObject4 = sketchLinearDimensionBuilder1.Commit()
    
    point1_1 = NXOpen.Point3d(4.4234712413603914e-14, 87.537751814584269, 0.0)
    point2_1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, NXOpen.View.Null, point1_1, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_1)
    
    point1_2 = NXOpen.Point3d(99.999999999994202, 87.537751814584269, 0.0)
    point2_2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line2, NXOpen.View.Null, point1_2, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_2)
    
    sketchLinearDimensionBuilder1.Driving.ExpressionValue.SetFormula("100")
    
    theSession.SetUndoMarkName(markId22, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId22, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId20, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId23 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    markId24 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject5 = sketchLinearDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId24, None)
    
    theSession.SetUndoMarkName(markId20, "Linear Dimension")
    
    expression12 = sketchLinearDimensionBuilder1.Driving.ExpressionValue
    sketchLinearDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId23, None)
    
    theSession.SetUndoMarkVisibility(markId20, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId22, None)
    
    markId25 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    parallelDimension2 = dimension1
    sketchLinearDimensionBuilder2 = workPart.Sketches.CreateLinearDimensionBuilder(parallelDimension2)
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchLinearDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId25, "Linear Dimension Dialog")
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits19 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits20 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits21 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits22 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits23 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits24 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchLinearDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchLinearDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits25 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits26 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits27 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits28 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits29 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits30 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits31 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits32 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits33 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits34 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits35 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits36 = sketchLinearDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Linear Dimension
    # ----------------------------------------------
    markId26 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    theSession.DeleteUndoMark(markId26, None)
    
    markId27 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("100")
    
    sketchLinearDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    sketchLinearDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    nXObject6 = sketchLinearDimensionBuilder2.Commit()
    
    point1_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line1, NXOpen.View.Null, point1_3, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_3)
    
    point1_4 = NXOpen.Point3d(-1.0329489919888848e-14, 100.0, 0.0)
    point2_4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchLinearDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line1, NXOpen.View.Null, point1_4, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_4)
    
    sketchLinearDimensionBuilder2.Driving.ExpressionValue.SetFormula("100")
    
    theSession.SetUndoMarkName(markId27, "Linear Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId27, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId25, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId28 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    scaleAboutPoint17 = NXOpen.Point3d(14.861719789389383, 2.0540588326798197, 0.0)
    viewCenter17 = NXOpen.Point3d(-14.861719789389383, -2.054058832679861, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint17, viewCenter17)
    
    scaleAboutPoint18 = NXOpen.Point3d(18.577149736736725, 2.4165398031527232, 0.0)
    viewCenter18 = NXOpen.Point3d(-18.577149736736725, -2.4165398031527618, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint18, viewCenter18)
    
    scaleAboutPoint19 = NXOpen.Point3d(23.221437170920904, 3.02067475394092, 0.0)
    viewCenter19 = NXOpen.Point3d(-23.221437170920904, -3.020674753940952, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint19, viewCenter19)
    
    scaleAboutPoint20 = NXOpen.Point3d(29.026796463651127, 3.7758434424261491, 0.0)
    viewCenter20 = NXOpen.Point3d(-29.026796463651127, -3.7758434424261695, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint20, viewCenter20)
    
    scaleAboutPoint21 = NXOpen.Point3d(36.283495579563905, 4.7198043030326859, 0.0)
    viewCenter21 = NXOpen.Point3d(-36.283495579563905, -4.7198043030327108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint21, viewCenter21)
    
    scaleAboutPoint22 = NXOpen.Point3d(45.354369474454877, 5.8997553787908572, 0.0)
    viewCenter22 = NXOpen.Point3d(-45.354369474454877, -5.8997553787909203, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint22, viewCenter22)
    
    scaleAboutPoint23 = NXOpen.Point3d(56.692961843068595, 7.3746942234885715, 0.0)
    viewCenter23 = NXOpen.Point3d(-56.692961843068595, -7.3746942234886497, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint23, viewCenter23)
    
    scaleAboutPoint24 = NXOpen.Point3d(70.866202303835749, 9.2183677793607153, 0.0)
    viewCenter24 = NXOpen.Point3d(-70.866202303835749, -9.2183677793607632, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint24, viewCenter24)
    
    scaleAboutPoint25 = NXOpen.Point3d(88.582752879794796, 11.522959724200891, 0.0)
    viewCenter25 = NXOpen.Point3d(-88.582752879794555, -11.522959724201014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint25, viewCenter25)
    
    scaleAboutPoint26 = NXOpen.Point3d(110.72844109974332, 14.403699655251113, 0.0)
    viewCenter26 = NXOpen.Point3d(-110.72844109974332, -14.403699655251266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint26, viewCenter26)
    
    scaleAboutPoint27 = NXOpen.Point3d(138.41055137467916, 18.004624569063889, 0.0)
    viewCenter27 = NXOpen.Point3d(-138.41055137467916, -18.004624569063985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint27, viewCenter27)
    
    scaleAboutPoint28 = NXOpen.Point3d(173.01318921834894, 22.505780711329862, 0.0)
    viewCenter28 = NXOpen.Point3d(-173.01318921834894, -22.505780711330104, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint28, viewCenter28)
    
    scaleAboutPoint29 = NXOpen.Point3d(455.39040658081683, 138.90286532773939, 0.0)
    viewCenter29 = NXOpen.Point3d(-455.39040658081683, -138.90286532773968, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint29, viewCenter29)
    
    scaleAboutPoint30 = NXOpen.Point3d(364.3123252646534, 111.12229226219151, 0.0)
    viewCenter30 = NXOpen.Point3d(-364.3123252646534, -111.12229226219175, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint30, viewCenter30)
    
    scaleAboutPoint31 = NXOpen.Point3d(291.44986021172269, 88.897833809753209, 0.0)
    viewCenter31 = NXOpen.Point3d(-291.44986021172269, -88.897833809753408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint31, viewCenter31)
    
    scaleAboutPoint32 = NXOpen.Point3d(233.15988816937818, 71.11826704780249, 0.0)
    viewCenter32 = NXOpen.Point3d(-233.15988816937801, -71.118267047802732, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint32, viewCenter32)
    
    scaleAboutPoint33 = NXOpen.Point3d(-114.50941225924674, -70.578128310730804, 0.0)
    viewCenter33 = NXOpen.Point3d(114.50941225924674, 70.578128310730563, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint33, viewCenter33)
    
    scaleAboutPoint34 = NXOpen.Point3d(-91.607529807397398, -56.462502648584646, 0.0)
    viewCenter34 = NXOpen.Point3d(91.607529807397398, 56.462502648584447, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint34, viewCenter34)
    
    scaleAboutPoint35 = NXOpen.Point3d(-73.286023845917924, -45.170002118867757, 0.0)
    viewCenter35 = NXOpen.Point3d(73.286023845917924, 45.170002118867522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint35, viewCenter35)
    
    scaleAboutPoint36 = NXOpen.Point3d(156.34351753795821, 24.336490937512238, 0.0)
    viewCenter36 = NXOpen.Point3d(-156.34351753795821, -24.336490937512458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint36, viewCenter36)
    
    scaleAboutPoint37 = NXOpen.Point3d(125.0748140303666, 19.469192750009771, 0.0)
    viewCenter37 = NXOpen.Point3d(-125.07481403036664, -19.469192750009999, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint37, viewCenter37)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId29 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Linear Dimension")
    
    nXObject7 = sketchLinearDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId29, None)
    
    theSession.SetUndoMarkName(markId25, "Linear Dimension")
    
    expression13 = sketchLinearDimensionBuilder2.Driving.ExpressionValue
    sketchLinearDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId28, None)
    
    theSession.SetUndoMarkVisibility(markId25, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId27, None)
    
    markId30 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder1 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section1 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder1.Section = section1
    
    extrudeBuilder1.AllowSelfIntersectingSection(True)
    
    unit2 = extrudeBuilder1.Draft.FrontDraftAngle.Units
    
    expression14 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder1.DistanceTolerance = 0.01
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies1 = [NXOpen.Body.Null] * 1 
    targetBodies1[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies1)
    
    extrudeBuilder1.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("-115")
    
    extrudeBuilder1.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder1.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder1.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder1 = extrudeBuilder1.SmartVolumeProfile
    
    smartVolumeProfileBuilder1.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder1.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId30, "Extrude Dialog")
    
    section1.DistanceTolerance = 0.01
    
    section1.ChainingTolerance = 0.0094999999999999998
    
    section1.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId31 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves1 = [NXOpen.ICurve.Null] * 4 
    curves1[0] = line2
    curves1[1] = line3
    curves1[2] = line1
    curves1[3] = line4
    seedPoint1 = NXOpen.Point3d(33.333333333333329, 33.333333333333243, 0.0)
    regionBoundaryRule1 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves1, seedPoint1, 0.01)
    
    section1.AllowSelfIntersection(True)
    
    rules1 = [None] * 1 
    rules1[0] = regionBoundaryRule1
    helpPoint1 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section1.AddToSection(rules1, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint1, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId31, None)
    
    markId32 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId33 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId33, None)
    
    direction1 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder1.Direction = direction1
    
    expression15 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId32, None)
    
    extrudeBuilder1.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies2 = [NXOpen.Body.Null] * 1 
    targetBodies2[0] = NXOpen.Body.Null
    extrudeBuilder1.BooleanOperation.SetTargetBodies(targetBodies2)
    
    extrudeBuilder1.Limits.EndExtend.Value.SetFormula("40")
    
    markId34 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId34, None)
    
    markId35 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder1.ParentFeatureInternal = False
    
    markId36 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature4 = extrudeBuilder1.CommitFeature()
    
    theSession.DeleteUndoMark(markId35, None)
    
    theSession.SetUndoMarkName(markId30, "Extrude")
    
    expression16 = extrudeBuilder1.Limits.StartExtend.Value
    expression17 = extrudeBuilder1.Limits.EndExtend.Value
    extrudeBuilder1.Destroy()
    
    workPart.Expressions.Delete(expression14)
    
    workPart.Expressions.Delete(expression15)
    
    rotMatrix2 = NXOpen.Matrix3x3()
    
    rotMatrix2.Xx = 0.99993329980345125
    rotMatrix2.Xy = -0.011438959393018954
    rotMatrix2.Xz = 0.0015956666902079883
    rotMatrix2.Yx = 0.0
    rotMatrix2.Yy = 0.1381563549518833
    rotMatrix2.Yz = 0.99041043087520519
    rotMatrix2.Zx = -0.011549716194841146
    rotMatrix2.Zy = -0.99034437030480194
    rotMatrix2.Zz = 0.13814713989585356
    translation2 = NXOpen.Point3d(-67.317432797245743, -6.8140873822838159, 67.33176152706497)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix2, translation2, 1.1211623039680938)
    
    rotMatrix3 = NXOpen.Matrix3x3()
    
    rotMatrix3.Xx = 0.54593057886700125
    rotMatrix3.Xy = 0.82981440056679301
    rotMatrix3.Xz = -0.11561947790020545
    rotMatrix3.Yx = 0.0096032380467285759
    rotMatrix3.Yy = 0.13179199456037249
    rotMatrix3.Yz = 0.99123087521970232
    rotMatrix3.Zx = 0.83777537614623165
    rotMatrix3.Zy = -0.54225356686865045
    rotMatrix3.Zz = 0.063980374657134562
    translation3 = NXOpen.Point3d(-84.33566185660554, -6.9924401519346482, 3.9443020429781797)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix3, translation3, 1.1211623039680938)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId37 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder3 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin3 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal3 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane4 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.PlaneReference = plane4
    
    expression18 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression19 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder3 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder3.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId37, "Create Sketch Dialog")
    
    scalar1 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude1 = feature4
    edge1 = extrude1.FindObject("EDGE * 120 * 160 {(99.9999999999942,-0.0000000000001,0)(99.9999999999971,49.9999999999999,0)(100,100,0) EXTRUDE(2)}")
    point7 = workPart.Points.CreatePoint(edge1, scalar1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction2 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face1 = extrude1.FindObject("FACE 160 {(99.9999999999971,49.9999999999999,20) EXTRUDE(2)}")
    xform1 = workPart.Xforms.CreateXformByPlaneXDirPoint(face1, direction2, point7, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem1 = workPart.CoordinateSystems.CreateCoordinateSystem(xform1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder3.Csystem = cartesianCoordinateSystem1
    
    origin4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal4 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane5 = workPart.Planes.CreatePlane(origin4, normal4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane5.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom4 = [NXOpen.NXObject.Null] * 1 
    geom4[0] = face1
    plane5.SetGeometry(geom4)
    
    plane5.SetFlip(False)
    
    plane5.SetExpression(None)
    
    plane5.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane5.Evaluate()
    
    origin5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal5 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane6 = workPart.Planes.CreatePlane(origin5, normal5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression20 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression21 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane6.SynchronizeToPlane(plane5)
    
    scalar2 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point8 = workPart.Points.CreatePoint(edge1, scalar2, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom5 = [NXOpen.NXObject.Null] * 1 
    geom5[0] = face1
    plane6.SetGeometry(geom5)
    
    plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane6.Evaluate()
    
    markId38 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId38, None)
    
    markId39 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject8 = sketchInPlaceBuilder3.Commit()
    
    sketch3 = nXObject8
    feature5 = sketch3.Feature
    
    markId40 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs5 = theSession.UpdateManager.DoUpdate(markId40)
    
    sketch3.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId39, None)
    
    theSession.SetUndoMarkName(markId37, "Create Sketch")
    
    sketchInPlaceBuilder3.Destroy()
    
    sketchAlongPathBuilder3.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression19)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point8)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression18)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane4.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression21)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression20)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane6.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId41 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint38 = NXOpen.Point3d(77.640780784887923, -7.0797064545491537, 0.0)
    viewCenter38 = NXOpen.Point3d(-77.640780784887923, 7.0797064545489325, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint38, viewCenter38)
    
    scaleAboutPoint39 = NXOpen.Point3d(105.01564574247762, -7.0797064545491795, 0.0)
    viewCenter39 = NXOpen.Point3d(-105.01564574247762, 7.079706454548953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint39, viewCenter39)
    
    scaleAboutPoint40 = NXOpen.Point3d(146.75641504742302, -4.0560818229188431, 0.0)
    viewCenter40 = NXOpen.Point3d(-146.75641504742302, 4.0560818229185918, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint40, viewCenter40)
    
    scaleAboutPoint41 = NXOpen.Point3d(186.6719475320551, 5.5310206676163292, 0.0)
    viewCenter41 = NXOpen.Point3d(-186.6719475320551, -5.5310206676165654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint41, viewCenter41)
    
    scaleAboutPoint42 = NXOpen.Point3d(149.33755802564406, 4.424816534093031, 0.0)
    viewCenter42 = NXOpen.Point3d(-149.33755802564406, -4.4248165340932513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint42, viewCenter42)
    
    scaleAboutPoint43 = NXOpen.Point3d(119.4700464205153, 3.5398532272744259, 0.0)
    viewCenter43 = NXOpen.Point3d(-119.4700464205153, -3.5398532272746275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint43, viewCenter43)
    
    scaleAboutPoint44 = NXOpen.Point3d(95.576037136412239, 2.8318825818195199, 0.0)
    viewCenter44 = NXOpen.Point3d(-95.576037136412197, -2.8318825818197215, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint44, viewCenter44)
    
    scaleAboutPoint45 = NXOpen.Point3d(76.460829709129825, 2.2655060654556167, 0.0)
    viewCenter45 = NXOpen.Point3d(-76.460829709129726, -2.2655060654557775, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint45, viewCenter45)
    
    scaleAboutPoint46 = NXOpen.Point3d(61.168663767303862, 1.8124048523644805, 0.0)
    viewCenter46 = NXOpen.Point3d(-61.168663767303784, -1.8124048523646479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint46, viewCenter46)
    
    markId42 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId42, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint5 = NXOpen.Point3d(99.999999999994159, 15.390072382336967, 0.0)
    endPoint5 = NXOpen.Point3d(99.999999999994159, 15.390072382336973, 12.0)
    line5 = workPart.Curves.CreateLine(startPoint5, endPoint5)
    
    startPoint6 = NXOpen.Point3d(99.999999999994159, 15.390072382336973, 12.0)
    endPoint6 = NXOpen.Point3d(99.999999999994159, 31.460062073302744, 11.999999999999972)
    line6 = workPart.Curves.CreateLine(startPoint6, endPoint6)
    
    startPoint7 = NXOpen.Point3d(99.999999999994159, 31.460062073302744, 11.999999999999972)
    endPoint7 = NXOpen.Point3d(99.999999999994159, 31.460062073302723, -2.3377533216216121e-14)
    line7 = workPart.Curves.CreateLine(startPoint7, endPoint7)
    
    startPoint8 = NXOpen.Point3d(99.999999999994159, 31.460062073302723, -2.3377533216216121e-14)
    endPoint8 = NXOpen.Point3d(99.999999999994159, 15.390072382336967, 0.0)
    line8 = workPart.Curves.CreateLine(startPoint8, endPoint8)
    
    theSession.ActiveSketch.AddGeometry(line5, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line6, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line7, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line8, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_6.Geometry = line5
    geom1_6.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_6.SplineDefiningPointIndex = 0
    geom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_6.Geometry = line6
    geom2_6.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint11 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_6, geom2_6)
    
    geom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_7.Geometry = line6
    geom1_7.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_7.SplineDefiningPointIndex = 0
    geom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_7.Geometry = line7
    geom2_7.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint12 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_7, geom2_7)
    
    geom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_8.Geometry = line7
    geom1_8.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_8.SplineDefiningPointIndex = 0
    geom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_8.Geometry = line8
    geom2_8.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint13 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_8, geom2_8)
    
    geom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_9.Geometry = line8
    geom1_9.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_9.SplineDefiningPointIndex = 0
    geom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_9.Geometry = line5
    geom2_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint14 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_9, geom2_9)
    
    geom6 = NXOpen.Sketch.ConstraintGeometry()
    
    geom6.Geometry = line6
    geom6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint15 = theSession.ActiveSketch.CreateHorizontalConstraint(geom6)
    
    conGeom1_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_5.Geometry = line5
    conGeom1_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_5.SplineDefiningPointIndex = 0
    conGeom2_5 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_5.Geometry = line6
    conGeom2_5.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_5.SplineDefiningPointIndex = 0
    sketchGeometricConstraint16 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_5, conGeom2_5)
    
    conGeom1_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_6.Geometry = line6
    conGeom1_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_6.SplineDefiningPointIndex = 0
    conGeom2_6 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_6.Geometry = line7
    conGeom2_6.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_6.SplineDefiningPointIndex = 0
    sketchGeometricConstraint17 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_6, conGeom2_6)
    
    conGeom1_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_7.Geometry = line7
    conGeom1_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_7.SplineDefiningPointIndex = 0
    conGeom2_7 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_7.Geometry = line8
    conGeom2_7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint18 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_7, conGeom2_7)
    
    conGeom1_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_8.Geometry = line8
    conGeom1_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_8.SplineDefiningPointIndex = 0
    conGeom2_8 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_8.Geometry = line5
    conGeom2_8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint19 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_8, conGeom2_8)
    
    conGeom1_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_9.Geometry = line5
    conGeom1_9.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_9.SplineDefiningPointIndex = 0
    conGeom2_9 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_9.Geometry = line3
    conGeom2_9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_9.SplineDefiningPointIndex = 0
    help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help1.Point.X = 99.999999999994159
    help1.Point.Y = 15.390072382336967
    help1.Point.Z = 0.0
    help1.Parameter = 0.0
    sketchHelpedGeometricConstraint1 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_9, conGeom2_9, help1)
    
    geom7 = NXOpen.Sketch.ConstraintGeometry()
    
    geom7.Geometry = line5
    geom7.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom7.SplineDefiningPointIndex = 0
    sketchGeometricConstraint20 = theSession.ActiveSketch.CreateVerticalConstraint(geom7)
    
    conGeom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_10.Geometry = line5
    conGeom1_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_10.SplineDefiningPointIndex = 0
    geom1Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help1.Point.X = 99.999999999994159
    geom1Help1.Point.Y = 15.390072382336967
    geom1Help1.Point.Z = 0.0
    geom1Help1.Parameter = 0.0
    conGeom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_10.Geometry = edge1
    conGeom2_10.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_10.SplineDefiningPointIndex = 0
    geom2Help1 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help1.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help1.Point.X = 99.999999999994159
    geom2Help1.Point.Y = 15.390072382336967
    geom2Help1.Point.Z = 0.0
    geom2Help1.Parameter = 0.0
    try:
        # Invalid object type
        sketchGeometricConstraint21 = theSession.ActiveSketch.CreateNormalConstraint(conGeom1_10, geom1Help1, conGeom2_10, geom2Help1)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(875033)
        
    conGeom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_11.Geometry = line7
    conGeom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_11.SplineDefiningPointIndex = 0
    conGeom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_11.Geometry = line3
    conGeom2_11.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_11.SplineDefiningPointIndex = 0
    help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help2.Point.X = 99.999999999994159
    help2.Point.Y = 31.460062073302723
    help2.Point.Z = 0.0
    help2.Parameter = 0.0
    sketchHelpedGeometricConstraint2 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_11, conGeom2_11, help2)
    
    dimObject1_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_4.Geometry = line5
    dimObject1_4.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_4.AssocValue = 0
    dimObject1_4.HelpPoint.X = 0.0
    dimObject1_4.HelpPoint.Y = 0.0
    dimObject1_4.HelpPoint.Z = 0.0
    dimObject1_4.View = NXOpen.NXObject.Null
    dimObject2_4 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_4.Geometry = line5
    dimObject2_4.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_4.AssocValue = 0
    dimObject2_4.HelpPoint.X = 0.0
    dimObject2_4.HelpPoint.Y = 0.0
    dimObject2_4.HelpPoint.Z = 0.0
    dimObject2_4.View = NXOpen.NXObject.Null
    dimOrigin4 = NXOpen.Point3d(99.999999999994159, 19.50009283494321, 5.9999999999999982)
    sketchDimensionalConstraint4 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_4, dimObject2_4, dimOrigin4, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint3 = sketchDimensionalConstraint4
    dimension4 = sketchHelpedDimensionalConstraint3.AssociatedDimension
    
    expression22 = sketchHelpedDimensionalConstraint3.AssociatedExpression
    
    dimObject1_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_5.Geometry = line6
    dimObject1_5.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_5.AssocValue = 0
    dimObject1_5.HelpPoint.X = 0.0
    dimObject1_5.HelpPoint.Y = 0.0
    dimObject1_5.HelpPoint.Z = 0.0
    dimObject1_5.View = NXOpen.NXObject.Null
    dimObject2_5 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_5.Geometry = line6
    dimObject2_5.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_5.AssocValue = 0
    dimObject2_5.HelpPoint.X = 0.0
    dimObject2_5.HelpPoint.Y = 0.0
    dimObject2_5.HelpPoint.Z = 0.0
    dimObject2_5.View = NXOpen.NXObject.Null
    dimOrigin5 = NXOpen.Point3d(99.999999999994159, 23.425067227819852, 7.8899795473937457)
    sketchDimensionalConstraint5 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_5, dimObject2_5, dimOrigin5, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint4 = sketchDimensionalConstraint5
    dimension5 = sketchHelpedDimensionalConstraint4.AssociatedDimension
    
    expression23 = sketchHelpedDimensionalConstraint4.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms3 = [NXOpen.SmartObject.Null] * 4 
    geoms3[0] = line5
    geoms3[1] = line6
    geoms3[2] = line7
    geoms3[3] = line8
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms3)
    
    geoms4 = [NXOpen.SmartObject.Null] * 4 
    geoms4[0] = line5
    geoms4[1] = line6
    geoms4[2] = line7
    geoms4[3] = line8
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms4)
    
    markId43 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId43, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint9 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 0.0)
    endPoint9 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 12.0)
    line9 = workPart.Curves.CreateLine(startPoint9, endPoint9)
    
    startPoint10 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 12.0)
    endPoint10 = NXOpen.Point3d(99.999999999994159, 76.891010372574272, 12.000000000000027)
    line10 = workPart.Curves.CreateLine(startPoint10, endPoint10)
    
    startPoint11 = NXOpen.Point3d(99.999999999994159, 76.891010372574272, 12.000000000000027)
    endPoint11 = NXOpen.Point3d(99.999999999994159, 76.891010372574257, 2.2147136731152124e-14)
    line11 = workPart.Curves.CreateLine(startPoint11, endPoint11)
    
    startPoint12 = NXOpen.Point3d(99.999999999994159, 76.891010372574257, 2.2147136731152124e-14)
    endPoint12 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 0.0)
    line12 = workPart.Curves.CreateLine(startPoint12, endPoint12)
    
    theSession.ActiveSketch.AddGeometry(line9, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line10, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line11, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line12, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_10.Geometry = line9
    geom1_10.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_10.SplineDefiningPointIndex = 0
    geom2_10 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_10.Geometry = line10
    geom2_10.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_10.SplineDefiningPointIndex = 0
    sketchGeometricConstraint22 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_10, geom2_10)
    
    geom1_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_11.Geometry = line10
    geom1_11.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_11.SplineDefiningPointIndex = 0
    geom2_11 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_11.Geometry = line11
    geom2_11.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_11.SplineDefiningPointIndex = 0
    sketchGeometricConstraint23 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_11, geom2_11)
    
    geom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_12.Geometry = line11
    geom1_12.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_12.SplineDefiningPointIndex = 0
    geom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_12.Geometry = line12
    geom2_12.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint24 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_12, geom2_12)
    
    geom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_13.Geometry = line12
    geom1_13.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_13.SplineDefiningPointIndex = 0
    geom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_13.Geometry = line9
    geom2_13.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint25 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_13, geom2_13)
    
    geom8 = NXOpen.Sketch.ConstraintGeometry()
    
    geom8.Geometry = line10
    geom8.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom8.SplineDefiningPointIndex = 0
    sketchGeometricConstraint26 = theSession.ActiveSketch.CreateHorizontalConstraint(geom8)
    
    conGeom1_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_12.Geometry = line9
    conGeom1_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_12.SplineDefiningPointIndex = 0
    conGeom2_12 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_12.Geometry = line10
    conGeom2_12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint27 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_12, conGeom2_12)
    
    conGeom1_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_13.Geometry = line10
    conGeom1_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_13.SplineDefiningPointIndex = 0
    conGeom2_13 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_13.Geometry = line11
    conGeom2_13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_13.SplineDefiningPointIndex = 0
    sketchGeometricConstraint28 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_13, conGeom2_13)
    
    conGeom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_14.Geometry = line11
    conGeom1_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_14.SplineDefiningPointIndex = 0
    conGeom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_14.Geometry = line12
    conGeom2_14.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint29 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_14, conGeom2_14)
    
    conGeom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_15.Geometry = line12
    conGeom1_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_15.SplineDefiningPointIndex = 0
    conGeom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_15.Geometry = line9
    conGeom2_15.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint30 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_15, conGeom2_15)
    
    conGeom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_16.Geometry = line9
    conGeom1_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_16.SplineDefiningPointIndex = 0
    conGeom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_16.Geometry = line3
    conGeom2_16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_16.SplineDefiningPointIndex = 0
    help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help3.Point.X = 99.999999999994159
    help3.Point.Y = 92.115211132436556
    help3.Point.Z = 0.0
    help3.Parameter = 0.0
    sketchHelpedGeometricConstraint3 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_16, conGeom2_16, help3)
    
    geom9 = NXOpen.Sketch.ConstraintGeometry()
    
    geom9.Geometry = line9
    geom9.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom9.SplineDefiningPointIndex = 0
    sketchGeometricConstraint31 = theSession.ActiveSketch.CreateVerticalConstraint(geom9)
    
    conGeom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_17.Geometry = line9
    conGeom1_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_17.SplineDefiningPointIndex = 0
    geom1Help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help2.Point.X = 99.999999999994159
    geom1Help2.Point.Y = 92.115211132436556
    geom1Help2.Point.Z = 0.0
    geom1Help2.Parameter = 0.0
    conGeom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_17.Geometry = edge1
    conGeom2_17.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_17.SplineDefiningPointIndex = 0
    geom2Help2 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help2.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help2.Point.X = 99.999999999994159
    geom2Help2.Point.Y = 92.115211132436556
    geom2Help2.Point.Z = 0.0
    geom2Help2.Parameter = 0.0
    try:
        # Invalid object type
        sketchGeometricConstraint32 = theSession.ActiveSketch.CreateNormalConstraint(conGeom1_17, geom1Help2, conGeom2_17, geom2Help2)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(875033)
        
    dimObject1_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_6.Geometry = line9
    dimObject1_6.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_6.AssocValue = 0
    dimObject1_6.HelpPoint.X = 0.0
    dimObject1_6.HelpPoint.Y = 0.0
    dimObject1_6.HelpPoint.Z = 0.0
    dimObject1_6.View = NXOpen.NXObject.Null
    dimObject2_6 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_6.Geometry = line9
    dimObject2_6.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_6.AssocValue = 0
    dimObject2_6.HelpPoint.X = 0.0
    dimObject2_6.HelpPoint.Y = 0.0
    dimObject2_6.HelpPoint.Z = 0.0
    dimObject2_6.View = NXOpen.NXObject.Null
    dimOrigin6 = NXOpen.Point3d(99.999999999994159, 96.225231585042792, 6.0)
    sketchDimensionalConstraint6 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_6, dimObject2_6, dimOrigin6, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint5 = sketchDimensionalConstraint6
    dimension6 = sketchHelpedDimensionalConstraint5.AssociatedDimension
    
    expression24 = sketchHelpedDimensionalConstraint5.AssociatedExpression
    
    dimObject1_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_7.Geometry = line10
    dimObject1_7.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_7.AssocValue = 0
    dimObject1_7.HelpPoint.X = 0.0
    dimObject1_7.HelpPoint.Y = 0.0
    dimObject1_7.HelpPoint.Z = 0.0
    dimObject1_7.View = NXOpen.NXObject.Null
    dimObject2_7 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_7.Geometry = line10
    dimObject2_7.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_7.AssocValue = 0
    dimObject2_7.HelpPoint.X = 0.0
    dimObject2_7.HelpPoint.Y = 0.0
    dimObject2_7.HelpPoint.Z = 0.0
    dimObject2_7.View = NXOpen.NXObject.Null
    dimOrigin7 = NXOpen.Point3d(99.999999999994159, 84.503110752505435, 16.110020452606253)
    sketchDimensionalConstraint7 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_7, dimObject2_7, dimOrigin7, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint6 = sketchDimensionalConstraint7
    dimension7 = sketchHelpedDimensionalConstraint6.AssociatedDimension
    
    expression25 = sketchHelpedDimensionalConstraint6.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms5 = [NXOpen.SmartObject.Null] * 4 
    geoms5[0] = line9
    geoms5[1] = line10
    geoms5[2] = line11
    geoms5[3] = line12
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms5)
    
    geoms6 = [NXOpen.SmartObject.Null] * 4 
    geoms6[0] = line9
    geoms6[1] = line10
    geoms6[2] = line11
    geoms6[3] = line12
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms6)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId44 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder1 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines1 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines1)
    
    lines2 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines2)
    
    lines3 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines3)
    
    lines4 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines4)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines5 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBefore(lines5)
    
    lines6 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAfter(lines6)
    
    lines7 = []
    sketchRapidDimensionBuilder1.AppendedText.SetAbove(lines7)
    
    lines8 = []
    sketchRapidDimensionBuilder1.AppendedText.SetBelow(lines8)
    
    theSession.SetUndoMarkName(markId44, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder1.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits37 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits38 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits39 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits40 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits41 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits42 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits43 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits44 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits45 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits46 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits47 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits48 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits49 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits50 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits51 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits52 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits53 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits54 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits55 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits56 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint47 = NXOpen.Point3d(33.831557244138438, -3.6248097047292078, 0.0)
    viewCenter47 = NXOpen.Point3d(-33.831557244138381, 3.6248097047290222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint47, viewCenter47)
    
    scaleAboutPoint48 = NXOpen.Point3d(42.289446555172994, -4.5310121309114821, 0.0)
    viewCenter48 = NXOpen.Point3d(-42.289446555172923, 4.5310121309113018, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint48, viewCenter48)
    
    scaleAboutPoint49 = NXOpen.Point3d(53.0506003660876, -5.8525573357606202, 0.0)
    viewCenter49 = NXOpen.Point3d(-53.050600366087522, 5.8525573357604435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint49, viewCenter49)
    
    scaleAboutPoint50 = NXOpen.Point3d(42.440480292870085, -4.6820458686085091, 0.0)
    viewCenter50 = NXOpen.Point3d(-42.440480292870006, 4.6820458686083422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint50, viewCenter50)
    
    scaleAboutPoint51 = NXOpen.Point3d(33.952384234296069, -3.7456366948868278, 0.0)
    viewCenter51 = NXOpen.Point3d(-33.952384234296012, 3.7456366948866733, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint51, viewCenter51)
    
    scaleAboutPoint52 = NXOpen.Point3d(27.161907387436866, -3.0931709480355831, 0.0)
    viewCenter52 = NXOpen.Point3d(-27.161907387436791, 3.0931709480354264, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint52, viewCenter52)
    
    scaleAboutPoint53 = NXOpen.Point3d(21.806855183650395, -2.4745367584284796, 0.0)
    viewCenter53 = NXOpen.Point3d(-21.806855183650317, 2.4745367584283278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint53, viewCenter53)
    
    scaleAboutPoint54 = NXOpen.Point3d(-22.332694244816349, -1.0516781223321463, 0.0)
    viewCenter54 = NXOpen.Point3d(22.332694244816444, 1.0516781223319933, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint54, viewCenter54)
    
    scaleAboutPoint55 = NXOpen.Point3d(-32.400965680671938, -1.3145976529151693, 0.0)
    viewCenter55 = NXOpen.Point3d(32.40096568067203, 1.314597652915011, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint55, viewCenter55)
    
    scaleAboutPoint56 = NXOpen.Point3d(-46.010917852028186, -1.3532622897656075, 0.0)
    viewCenter56 = NXOpen.Point3d(46.010917852028271, 1.3532622897654591, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint56, viewCenter56)
    
    scaleAboutPoint57 = NXOpen.Point3d(-81.316564376089744, 0.36248097047283928, 0.0)
    viewCenter57 = NXOpen.Point3d(81.316564376089829, -0.3624809704729835, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint57, viewCenter57)
    
    scaleAboutPoint58 = NXOpen.Point3d(-13.593036392734149, -8.9109905241258094, 0.0)
    viewCenter58 = NXOpen.Point3d(13.5930363927342, 8.9109905241256673, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint58, viewCenter58)
    
    scaleAboutPoint59 = NXOpen.Point3d(-11.116083094502619, -7.1287924193006571, 0.0)
    viewCenter59 = NXOpen.Point3d(11.11608309450264, 7.1287924193005132, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint59, viewCenter59)
    
    scaleAboutPoint60 = NXOpen.Point3d(-9.2795128441065131, -5.7030339354405344, 0.0)
    viewCenter60 = NXOpen.Point3d(9.2795128441065451, 5.7030339354403941, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint60, viewCenter60)
    
    scaleAboutPoint61 = NXOpen.Point3d(-7.578268822686991, -4.7170856957542142, 0.0)
    viewCenter61 = NXOpen.Point3d(7.5782688226870301, 4.7170856957540828, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint61, viewCenter61)
    
    point9 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 3.1177080306557934)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(line9, workPart.ModelingViews.WorkView, point9)
    
    point1_5 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 0.0)
    point2_5 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, workPart.ModelingViews.WorkView, point1_5, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_5)
    
    point1_6 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 12.0)
    point2_6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line9, workPart.ModelingViews.WorkView, point1_6, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_6)
    
    dimensionlinearunits57 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits58 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits59 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits60 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits61 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits62 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    edge2 = extrude1.FindObject("EDGE * 160 * 170 {(100,100,40)(100,100,20)(100,100,0) EXTRUDE(2)}")
    point1_7 = NXOpen.Point3d(99.999999999999986, 100.0, 0.0)
    point2_7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_7, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_7)
    
    point1_8 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 3.1177080306557934)
    point2_8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_8, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_8)
    
    point1_9 = NXOpen.Point3d(99.999999999999986, 100.0, 0.0)
    point2_9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_9, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_9)
    
    point1_10 = NXOpen.Point3d(99.999999999994159, 92.115211132436556, 3.1177080306557934)
    point2_10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line9, workPart.ModelingViews.WorkView, point1_10, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_10)
    
    point1_11 = NXOpen.Point3d(99.999999999999986, 100.0, 0.0)
    point2_11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder1.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, edge2, workPart.ModelingViews.WorkView, point1_11, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_11)
    
    dimensionlinearunits63 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits64 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits65 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits66 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits67 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits68 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits69 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits70 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits71 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits72 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits73 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits74 = sketchRapidDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin1 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin1.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin1.View = NXOpen.View.Null
    assocOrigin1.ViewOfGeometry = workPart.ModelingViews.WorkView
    point10 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin1.PointOnGeometry = point10
    assocOrigin1.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.DimensionLine = 0
    assocOrigin1.AssociatedView = NXOpen.View.Null
    assocOrigin1.AssociatedPoint = NXOpen.Point.Null
    assocOrigin1.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin1.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin1.XOffsetFactor = 0.0
    assocOrigin1.YOffsetFactor = 0.0
    assocOrigin1.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin1)
    
    point11 = NXOpen.Point3d(99.999999999994159, 96.370314831322872, -7.9558439633113363)
    sketchRapidDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point11)
    
    sketchRapidDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder1.Style.DimensionStyle.TextCentered = True
    
    markId45 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject9 = sketchRapidDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId45, None)
    
    theSession.SetUndoMarkName(markId44, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId44, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder1.Destroy()
    
    markId46 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder2 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines9 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBefore(lines9)
    
    lines10 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAfter(lines10)
    
    lines11 = []
    sketchRapidDimensionBuilder2.AppendedText.SetAbove(lines11)
    
    lines12 = []
    sketchRapidDimensionBuilder2.AppendedText.SetBelow(lines12)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId46, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder2.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits75 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits76 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits77 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits78 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits79 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits80 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits81 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits82 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits83 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits84 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder2.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits85 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits86 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits87 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits88 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits89 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits90 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits91 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits92 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits93 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits94 = sketchRapidDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    expression26 = workPart.Expressions.FindObject("p19")
    expression26.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId46, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId47 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId47, None)
    
    markId48 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId46, "Edit Driving Value")
    
    scaleAboutPoint62 = NXOpen.Point3d(-2.7219904342712313, -6.0626150581496612, 0.0)
    viewCenter62 = NXOpen.Point3d(2.7219904342712842, 6.0626150581495342, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint62, viewCenter62)
    
    scaleAboutPoint63 = NXOpen.Point3d(-3.4024880428390456, -7.6555980963879531, 0.0)
    viewCenter63 = NXOpen.Point3d(3.4024880428390851, 7.6555980963878278, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint63, viewCenter63)
    
    scaleAboutPoint64 = NXOpen.Point3d(-4.2531100535488076, -9.9561439889893588, 0.0)
    viewCenter64 = NXOpen.Point3d(4.2531100535488573, 9.9561439889892274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint64, viewCenter64)
    
    scaleAboutPoint65 = NXOpen.Point3d(-5.3163875669360285, -12.566006976394327, 0.0)
    viewCenter65 = NXOpen.Point3d(5.316387566936049, 12.566006976394192, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint65, viewCenter65)
    
    scaleAboutPoint66 = NXOpen.Point3d(-6.6454844586700474, -15.85854245818993, 0.0)
    viewCenter66 = NXOpen.Point3d(6.6454844586700474, 15.858542458189802, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint66, viewCenter66)
    
    scaleAboutPoint67 = NXOpen.Point3d(-7.9292712290949332, -19.823178072737381, 0.0)
    viewCenter67 = NXOpen.Point3d(7.9292712290949332, 19.823178072737271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint67, viewCenter67)
    
    scaleAboutPoint68 = NXOpen.Point3d(-9.6755988212170063, -24.778972590921729, 0.0)
    viewCenter68 = NXOpen.Point3d(9.6755988212170472, 24.778972590921608, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint68, viewCenter68)
    
    scaleAboutPoint69 = NXOpen.Point3d(-113.5702910417243, -17.404278367433115, 0.0)
    viewCenter69 = NXOpen.Point3d(113.57029104172436, 17.40427836743299, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint69, viewCenter69)
    
    scaleAboutPoint70 = NXOpen.Point3d(-90.856232833379408, -13.923422693946513, 0.0)
    viewCenter70 = NXOpen.Point3d(90.856232833379494, 13.923422693946392, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint70, viewCenter70)
    
    scaleAboutPoint71 = NXOpen.Point3d(-72.684986266703532, -11.138738155157226, 0.0)
    viewCenter71 = NXOpen.Point3d(72.684986266703561, 11.13873815515708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint71, viewCenter71)
    
    scaleAboutPoint72 = NXOpen.Point3d(-58.147989013362796, -8.9109905241258058, 0.0)
    viewCenter72 = NXOpen.Point3d(58.147989013362874, 8.9109905241256513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint72, viewCenter72)
    
    perpendicularDimension1 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    point12 = NXOpen.Point3d(199.99999999998823, 7.8285834079080061, 14.097339694835973)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(perpendicularDimension1, workPart.ModelingViews.WorkView, point12)
    
    line13 = theSession.ActiveSketch.FindObject("Curve DATUM6")
    point1_12 = NXOpen.Point3d(99.999999999994159, -1.4547323094648304e-13, 14.287500000000001)
    point2_12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line13, NXOpen.View.Null, point1_12, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_12)
    
    point1_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_13, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_13)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder1 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList1 = convertToFromReferenceBuilder1.InputObjects
    
    added1 = selectNXObjectList1.Add(perpendicularDimension1)
    
    convertToFromReferenceBuilder1.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject10 = convertToFromReferenceBuilder1.Commit()
    
    convertToFromReferenceBuilder1.Destroy()
    
    expression27 = workPart.Expressions.FindObject("p20")
    expression27.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId48, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId49 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId49, None)
    
    markId50 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId48, "Edit Driving Value")
    
    scaleAboutPoint73 = NXOpen.Point3d(11.478564064975549, -19.090664444906725, 0.0)
    viewCenter73 = NXOpen.Point3d(-11.478564064975467, 19.090664444906572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint73, viewCenter73)
    
    scaleAboutPoint74 = NXOpen.Point3d(15.659177924429803, -16.915778622069265, 0.0)
    viewCenter74 = NXOpen.Point3d(-15.65917792442972, 16.915778622069098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint74, viewCenter74)
    
    scaleAboutPoint75 = NXOpen.Point3d(13.300635076552737, -13.687281445057213, 0.0)
    viewCenter75 = NXOpen.Point3d(-13.300635076552645, 13.687281445057041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint75, viewCenter75)
    
    parallelDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    point13 = NXOpen.Point3d(199.99999999998823, 22.708668899801332, 9.7388685058696769)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(parallelDimension3, workPart.ModelingViews.WorkView, point13)
    
    point1_14 = NXOpen.Point3d(99.999999999994159, 14.999999999999854, 12.0)
    point2_14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line6, NXOpen.View.Null, point1_14, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_14)
    
    point1_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_15, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_15)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder2 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList2 = convertToFromReferenceBuilder2.InputObjects
    
    added2 = selectNXObjectList2.Add(parallelDimension3)
    
    convertToFromReferenceBuilder2.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject11 = convertToFromReferenceBuilder2.Commit()
    
    convertToFromReferenceBuilder2.Destroy()
    
    expression28 = workPart.Expressions.FindObject("p21")
    expression28.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId50, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId51 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId51, None)
    
    markId52 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId50, "Edit Driving Value")
    
    parallelDimension4 = theSession.ActiveSketch.FindObject("ENTITY 26 3 1")
    point14 = NXOpen.Point3d(199.99999999998823, 77.02475074730485, 14.131171252080101)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(parallelDimension4, workPart.ModelingViews.WorkView, point14)
    
    point1_16 = NXOpen.Point3d(99.999999999994159, 69.775799240137715, 11.999999999999996)
    point2_16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line10, NXOpen.View.Null, point1_16, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_16)
    
    point1_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_17, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_17)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder3 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList3 = convertToFromReferenceBuilder3.InputObjects
    
    added3 = selectNXObjectList3.Add(parallelDimension4)
    
    convertToFromReferenceBuilder3.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject12 = convertToFromReferenceBuilder3.Commit()
    
    convertToFromReferenceBuilder3.Destroy()
    
    expression29 = workPart.Expressions.FindObject("p22")
    expression29.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId52, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId53 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId53, None)
    
    markId54 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId52, "Edit Driving Value")
    
    parallelDimension5 = dimension6
    point15 = NXOpen.Point3d(199.99999999998823, 89.397434539446891, 5.9651999492663599)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(parallelDimension5, workPart.ModelingViews.WorkView, point15)
    
    point1_18 = NXOpen.Point3d(99.999999999994159, 85.0, 0.0)
    point2_18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line9, NXOpen.View.Null, point1_18, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_18)
    
    point1_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_19, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_19)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder4 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList4 = convertToFromReferenceBuilder4.InputObjects
    
    added4 = selectNXObjectList4.Add(parallelDimension5)
    
    convertToFromReferenceBuilder4.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject13 = convertToFromReferenceBuilder4.Commit()
    
    convertToFromReferenceBuilder4.Destroy()
    
    expression30 = workPart.Expressions.FindObject("p23")
    expression30.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId54, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId55 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId55, None)
    
    markId56 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId54, "Edit Driving Value")
    
    parallelDimension6 = dimension4
    point16 = NXOpen.Point3d(199.99999999998823, 18.935000343198013, 6.0270633682270667)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(parallelDimension6, workPart.ModelingViews.WorkView, point16)
    
    point1_20 = NXOpen.Point3d(99.999999999994159, 14.999999999999854, 12.0)
    point2_20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line5, NXOpen.View.Null, point1_20, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_20)
    
    point1_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_21 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder2.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_21, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_21)
    
    sketchRapidDimensionBuilder2.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder5 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList5 = convertToFromReferenceBuilder5.InputObjects
    
    added5 = selectNXObjectList5.Add(parallelDimension6)
    
    convertToFromReferenceBuilder5.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject14 = convertToFromReferenceBuilder5.Commit()
    
    convertToFromReferenceBuilder5.Destroy()
    
    expression31 = workPart.Expressions.FindObject("p24")
    expression31.SetFormula("15")
    
    theSession.SetUndoMarkVisibility(markId56, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId57 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId57, None)
    
    markId58 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId56, "Edit Driving Value")
    
    scaleAboutPoint76 = NXOpen.Point3d(-27.652948275437399, -3.0931709480355907, 0.0)
    viewCenter76 = NXOpen.Point3d(27.652948275437485, 3.0931709480354219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint76, viewCenter76)
    
    scaleAboutPoint77 = NXOpen.Point3d(-30.158416743346159, -6.263671169771988, 0.0)
    viewCenter77 = NXOpen.Point3d(30.158416743346251, 6.2636711697718166, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint77, viewCenter77)
    
    scaleAboutPoint78 = NXOpen.Point3d(-33.251587691381665, -9.1828512519804999, 0.0)
    viewCenter78 = NXOpen.Point3d(33.251587691381751, 9.1828512519803276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint78, viewCenter78)
    
    scaleAboutPoint79 = NXOpen.Point3d(-37.69802092918269, -12.566006976394327, 0.0)
    viewCenter79 = NXOpen.Point3d(37.698020929182796, 12.566006976394162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint79, viewCenter79)
    
    scaleAboutPoint80 = NXOpen.Point3d(-43.195648981355184, -16.311643671281082, 0.0)
    viewCenter80 = NXOpen.Point3d(43.195648981355312, 16.311643671280901, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint80, viewCenter80)
    
    scaleAboutPoint81 = NXOpen.Point3d(-51.917847333359589, -20.955931105465247, 0.0)
    viewCenter81 = NXOpen.Point3d(51.917847333359717, 20.955931105465083, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint81, viewCenter81)
    
    scaleAboutPoint82 = NXOpen.Point3d(-62.301416800031511, -23.599021515163539, 0.0)
    viewCenter82 = NXOpen.Point3d(62.30141680003161, 23.599021515163379, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint82, viewCenter82)
    
    scaleAboutPoint83 = NXOpen.Point3d(-49.6523412679039, -18.879217212130847, 0.0)
    viewCenter83 = NXOpen.Point3d(49.652341267903999, 18.879217212130683, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint83, viewCenter83)
    
    scaleAboutPoint84 = NXOpen.Point3d(-39.721873014323116, -15.103373769704703, 0.0)
    viewCenter84 = NXOpen.Point3d(39.721873014323187, 15.103373769704524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint84, viewCenter84)
    
    scaleAboutPoint85 = NXOpen.Point3d(-31.777498411458488, -12.082699015763776, 0.0)
    viewCenter85 = NXOpen.Point3d(31.777498411458581, 12.082699015763611, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint85, viewCenter85)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    sketchRapidDimensionBuilder2.Destroy()
    
    theSession.UndoToMark(markId58, None)
    
    theSession.DeleteUndoMark(markId58, None)
    
    sketchRapidDimensionBuilder2.Destroy()
    
    markId59 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder2 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section2 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder2.Section = section2
    
    extrudeBuilder2.AllowSelfIntersectingSection(True)
    
    expression32 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder2.DistanceTolerance = 0.01
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies3 = [NXOpen.Body.Null] * 1 
    targetBodies3[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies3)
    
    extrudeBuilder2.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("40")
    
    extrudeBuilder2.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies4 = [NXOpen.Body.Null] * 1 
    targetBodies4[0] = NXOpen.Body.Null
    extrudeBuilder2.BooleanOperation.SetTargetBodies(targetBodies4)
    
    extrudeBuilder2.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder2.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder2.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder2 = extrudeBuilder2.SmartVolumeProfile
    
    smartVolumeProfileBuilder2.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder2.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId59, "Extrude Dialog")
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId60 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves2 = [NXOpen.ICurve.Null] * 8 
    curves2[0] = line7
    curves2[1] = line5
    curves2[2] = line11
    curves2[3] = line9
    curves2[4] = line8
    curves2[5] = line6
    curves2[6] = line12
    curves2[7] = line10
    seedPoint2 = NXOpen.Point3d(99.999999999994159, 75.000000000000014, 10.0)
    regionBoundaryRule2 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves2, seedPoint2, 0.01)
    
    curves3 = [NXOpen.ICurve.Null] * 8 
    curves3[0] = line7
    curves3[1] = line5
    curves3[2] = line11
    curves3[3] = line9
    curves3[4] = line8
    curves3[5] = line6
    curves3[6] = line12
    curves3[7] = line10
    seedPoint3 = NXOpen.Point3d(99.999999999994159, 19.999999999999851, 10.000000000000004)
    regionBoundaryRule3 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves3, seedPoint3, 0.01)
    
    section2.AllowSelfIntersection(True)
    
    rules2 = [None] * 2 
    rules2[0] = regionBoundaryRule2
    rules2[1] = regionBoundaryRule3
    helpPoint2 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section2.AddToSection(rules2, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint2, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId60, None)
    
    markId61 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId62 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId62, None)
    
    direction3 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction3
    
    expression33 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression34 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId61, None)
    
    markId63 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId64 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section2.Clear()
    
    theSession.DeleteUndoMark(markId64, None)
    
    workPart.Expressions.Delete(expression33)
    
    workPart.Expressions.Delete(expression34)
    
    theSession.DeleteUndoMark(markId63, None)
    
    rotMatrix4 = NXOpen.Matrix3x3()
    
    rotMatrix4.Xx = -0.011209842422786328
    rotMatrix4.Xy = 0.99993155972164993
    rotMatrix4.Xz = -0.0033489260196452857
    rotMatrix4.Yx = -0.50662858349121354
    rotMatrix4.Yy = -0.0027921079789334177
    rotMatrix4.Yz = 0.86215989382638381
    rotMatrix4.Zx = 0.86209153680020767
    rotMatrix4.Zy = 0.011361338198589716
    rotMatrix4.Zz = 0.50662520878041051
    translation4 = NXOpen.Point3d(-78.922553984100716, 18.208899497873688, -101.43143902225471)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix4, translation4, 2.7372126561721077)
    
    scaleAboutPoint86 = NXOpen.Point3d(-27.355230571688974, -26.195291466175775, 0.0)
    viewCenter86 = NXOpen.Point3d(27.355230571689056, 26.195291466175611, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint86, viewCenter86)
    
    scaleAboutPoint87 = NXOpen.Point3d(-21.884184457351175, -20.956233172940635, 0.0)
    viewCenter87 = NXOpen.Point3d(21.884184457351243, 20.956233172940458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint87, viewCenter87)
    
    scaleAboutPoint88 = NXOpen.Point3d(-17.50734756588092, -16.764986538352524, 0.0)
    viewCenter88 = NXOpen.Point3d(17.507347565881009, 16.76498653835236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint88, viewCenter88)
    
    scaleAboutPoint89 = NXOpen.Point3d(-14.005878052704734, -13.510970701019165, 0.0)
    viewCenter89 = NXOpen.Point3d(14.00587805270481, 13.510970701019014, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint89, viewCenter89)
    
    scaleAboutPoint90 = NXOpen.Point3d(-17.50734756588092, -16.888713376273945, 0.0)
    viewCenter90 = NXOpen.Point3d(17.507347565881009, 16.888713376273785, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint90, viewCenter90)
    
    scaleAboutPoint91 = NXOpen.Point3d(-21.884184457351168, -21.110891720342401, 0.0)
    viewCenter91 = NXOpen.Point3d(21.88418445735125, 21.110891720342259, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint91, viewCenter91)
    
    scaleAboutPoint92 = NXOpen.Point3d(-27.355230571688971, -26.388614650427986, 0.0)
    viewCenter92 = NXOpen.Point3d(27.355230571689052, 26.388614650427847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint92, viewCenter92)
    
    extrudeBuilder2.Limits.EndExtend.Value.SetFormula("10")
    
    markId65 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId66 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    origin6 = NXOpen.Point3d(99.999999999997073, 49.999999999999936, 20.0)
    normal6 = NXOpen.Vector3d(1.0, -5.8147930914742485e-14, -0.0)
    geometry1 = [NXOpen.NXObject.Null] * 1 
    geometry1[0] = face1
    plane7 = workPart.Planes.CreatePlane(NXOpen.PlaneTypes.MethodType.Coincident, NXOpen.PlaneTypes.AlternateType.One, origin6, normal6, "", False, False, geometry1)
    
    plane7.Evaluate()
    
    direction4 = workPart.Directions.CreateDirection(edge1, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression35 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar3 = workPart.Scalars.CreateScalarExpression(expression35, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression36 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar4 = workPart.Scalars.CreateScalarExpression(expression36, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression37 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar5 = workPart.Scalars.CreateScalarExpression(expression37, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point17 = workPart.Points.CreatePoint(scalar3, scalar4, scalar5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder4 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder4.PlaneReference = plane7
    
    sketchInPlaceBuilder4.AxisReference = direction4
    
    sketchInPlaceBuilder4.SketchOrigin = point17
    
    sketchInPlaceBuilder4.AxisOrientation = NXOpen.AxisOrientation.Horizontal
    
    sketchInPlaceBuilder4.PlaneOption = NXOpen.Sketch.PlaneOption.ExistingPlane
    
    sketchInPlaceBuilder4.OriginOption = NXOpen.OriginMethod.SpecifyPoint
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject15 = sketchInPlaceBuilder4.Commit()
    
    sketch4 = nXObject15
    sketch4.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId67 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    sketchInPlaceBuilder4.Destroy()
    
    theSession.DeleteUndoMarksUpToMark(markId67, None, True)
    
    markId68 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_003")
    
    markId69 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Dialog Begin Profile
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId69, "Curve")
    
    scaleAboutPoint93 = NXOpen.Point3d(105.13364085005342, -1.0290119534329089e-13, 0.0)
    viewCenter93 = NXOpen.Point3d(-105.13364085005342, -1.2348143441194907e-13, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint93, viewCenter93)
    
    scaleAboutPoint94 = NXOpen.Point3d(145.57646397166488, -1.1799510757583032, 0.0)
    viewCenter94 = NXOpen.Point3d(-145.57646397166482, 1.1799510757580718, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint94, viewCenter94)
    
    scaleAboutPoint95 = NXOpen.Point3d(190.45147832159304, -1.4749388446978147, 0.0)
    viewCenter95 = NXOpen.Point3d(-190.45147832159304, 1.4749388446976217, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint95, viewCenter95)
    
    scaleAboutPoint96 = NXOpen.Point3d(244.51720534754375, 0.92183677793601349, 0.0)
    viewCenter96 = NXOpen.Point3d(-244.51720534754375, -0.92183677793617425, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint96, viewCenter96)
    
    scaleAboutPoint97 = NXOpen.Point3d(195.61376427803501, 0.73746942234877855, 0.0)
    viewCenter97 = NXOpen.Point3d(-195.61376427803501, -0.73746942234893942, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint97, viewCenter97)
    
    scaleAboutPoint98 = NXOpen.Point3d(156.49101142242802, 0.58997553787899715, 0.0)
    viewCenter98 = NXOpen.Point3d(-156.49101142242802, -0.58997553787920298, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint98, viewCenter98)
    
    scaleAboutPoint99 = NXOpen.Point3d(125.19280913794239, 0.4719804303031771, 0.0)
    viewCenter99 = NXOpen.Point3d(-125.19280913794239, -0.47198043030338294, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint99, viewCenter99)
    
    scaleAboutPoint100 = NXOpen.Point3d(100.15424731035391, 0.37758434424252518, 0.0)
    viewCenter100 = NXOpen.Point3d(-100.15424731035391, -0.37758434424272275, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint100, viewCenter100)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.Preferences.Sketch.SectionView = False
    
    markId70 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.SketchOnly)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId65, None)
    
    theSession.DeleteUndoMark(markId65, None)
    
    section2.DistanceTolerance = 0.01
    
    section2.ChainingTolerance = 0.0094999999999999998
    
    scaleAboutPoint101 = NXOpen.Point3d(26.430904096983117, -26.194913881831596, 0.0)
    viewCenter101 = NXOpen.Point3d(-26.430904096983117, 26.194913881831376, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint101, viewCenter101)
    
    scaleAboutPoint102 = NXOpen.Point3d(33.038630121228927, -32.743642352289498, 0.0)
    viewCenter102 = NXOpen.Point3d(-33.038630121228927, 32.743642352289271, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint102, viewCenter102)
    
    scaleAboutPoint103 = NXOpen.Point3d(41.298287651536057, -40.929552940361837, 0.0)
    viewCenter103 = NXOpen.Point3d(-41.298287651536185, 40.929552940361589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint103, viewCenter103)
    
    scaleAboutPoint104 = NXOpen.Point3d(50.240104397515957, -47.013675674739922, 0.0)
    viewCenter104 = NXOpen.Point3d(-50.240104397516113, 47.013675674739687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint104, viewCenter104)
    
    scaleAboutPoint105 = NXOpen.Point3d(62.223982510685026, -57.038650634794706, 0.0)
    viewCenter105 = NXOpen.Point3d(-62.223982510685026, 57.038650634794507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint105, viewCenter105)
    
    scaleAboutPoint106 = NXOpen.Point3d(77.059793155593638, -69.857943327968229, 0.0)
    viewCenter106 = NXOpen.Point3d(-77.059793155593638, 69.857943327967973, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint106, viewCenter106)
    
    scaleAboutPoint107 = NXOpen.Point3d(61.647834524474966, -55.886354662374629, 0.0)
    viewCenter107 = NXOpen.Point3d(-61.647834524474916, 55.886354662374337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint107, viewCenter107)
    
    scaleAboutPoint108 = NXOpen.Point3d(49.318267619579977, -44.709083729899746, 0.0)
    viewCenter108 = NXOpen.Point3d(-49.318267619579899, 44.709083729899433, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint108, viewCenter108)
    
    scaleAboutPoint109 = NXOpen.Point3d(39.454614095664006, -35.767266983919825, 0.0)
    viewCenter109 = NXOpen.Point3d(-39.454614095663878, 35.767266983919541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint109, viewCenter109)
    
    scaleAboutPoint110 = NXOpen.Point3d(31.563691276531237, -28.613813587135891, 0.0)
    viewCenter110 = NXOpen.Point3d(-31.563691276531113, 28.613813587135589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint110, viewCenter110)
    
    scaleAboutPoint111 = NXOpen.Point3d(25.250953021224991, -22.891050869708732, 0.0)
    viewCenter111 = NXOpen.Point3d(-25.25095302122493, 22.89105086970843, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint111, viewCenter111)
    
    scaleAboutPoint112 = NXOpen.Point3d(19.823178072737399, -14.348205081219565, 0.0)
    viewCenter112 = NXOpen.Point3d(-19.823178072737303, 14.348205081219243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint112, viewCenter112)
    
    scaleAboutPoint113 = NXOpen.Point3d(15.254407507401728, -9.9682266880052097, 0.0)
    viewCenter113 = NXOpen.Point3d(-15.254407507401625, 9.9682266880049131, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint113, viewCenter113)
    
    scaleAboutPoint114 = NXOpen.Point3d(11.720218045290849, -7.3704463996160152, 0.0)
    viewCenter114 = NXOpen.Point3d(-11.720218045290705, 7.3704463996157159, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint114, viewCenter114)
    
    markId71 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId72 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features1 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature1 = feature5
    features1[0] = sketchFeature1
    curveFeatureRule1 = workPart.ScRuleFactory.CreateRuleCurveFeature(features1)
    
    section2.AllowSelfIntersection(True)
    
    rules3 = [None] * 1 
    rules3[0] = curveFeatureRule1
    helpPoint3 = NXOpen.Point3d(99.999999999994259, 29.999999999999886, 5.2747040441382458)
    section2.AddToSection(rules3, line7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint3, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId72, None)
    
    direction5 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder2.Direction = direction5
    
    expression38 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression39 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId71, None)
    
    scaleAboutPoint115 = NXOpen.Point3d(-31.221694256733382, -2.0298934346484532, 0.0)
    viewCenter115 = NXOpen.Point3d(31.221694256733521, 2.0298934346481565, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint115, viewCenter115)
    
    scaleAboutPoint116 = NXOpen.Point3d(-38.181328889813294, -2.7790207736258061, 0.0)
    viewCenter116 = NXOpen.Point3d(38.181328889813443, 2.7790207736255073, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint116, viewCenter116)
    
    markId73 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId73, None)
    
    markId74 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder2.ParentFeatureInternal = False
    
    markId75 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature6 = extrudeBuilder2.CommitFeature()
    
    theSession.DeleteUndoMark(markId74, None)
    
    theSession.SetUndoMarkName(markId59, "Extrude")
    
    expression40 = extrudeBuilder2.Limits.StartExtend.Value
    expression41 = extrudeBuilder2.Limits.EndExtend.Value
    extrudeBuilder2.Destroy()
    
    workPart.Expressions.Delete(expression32)
    
    workPart.Expressions.Delete(expression38)
    
    workPart.Expressions.Delete(expression39)
    
    rotMatrix5 = NXOpen.Matrix3x3()
    
    rotMatrix5.Xx = 0.54593057886700125
    rotMatrix5.Xy = 0.82981440056679301
    rotMatrix5.Xz = -0.11561947790020545
    rotMatrix5.Yx = -0.24327963717544115
    rotMatrix5.Yy = 0.28905740375166367
    rotMatrix5.Yz = 0.9258838131602336
    rotMatrix5.Zx = 0.80173238751701204
    rotMatrix5.Zy = -0.4773404214481769
    rotMatrix5.Zz = 0.35968222204878358
    translation5 = NXOpen.Point3d(-114.59703191245444, 6.0599296098054083, -3.2330278012715006)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix5, translation5, 1.7518160999501466)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId76 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder5 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal7 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane8 = workPart.Planes.CreatePlane(origin7, normal7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.PlaneReference = plane8
    
    expression42 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression43 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder4 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder4.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId76, "Create Sketch Dialog")
    
    scalar6 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude2 = feature6
    edge3 = extrude2.FindObject("EDGE * 130 * 160 {(109.9999999999942,29.9999999999999,0)(109.9999999999942,29.9999999999999,7.5)(109.9999999999942,29.9999999999999,15) EXTRUDE(4)}")
    point18 = workPart.Points.CreatePoint(edge3, scalar6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge4 = extrude2.FindObject("EDGE * 130 * 190 {(109.9999999999942,14.9999999999999,-0)(109.9999999999942,22.4999999999999,-0)(109.9999999999942,29.9999999999999,0) EXTRUDE(4)}")
    direction6 = workPart.Directions.CreateDirection(edge4, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face2 = extrude2.FindObject("FACE 130 {(109.9999999999942,22.4999999999999,7.5) EXTRUDE(4)}")
    xform2 = workPart.Xforms.CreateXformByPlaneXDirPoint(face2, direction6, point18, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem2 = workPart.CoordinateSystems.CreateCoordinateSystem(xform2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder5.Csystem = cartesianCoordinateSystem2
    
    origin8 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal8 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane9 = workPart.Planes.CreatePlane(origin8, normal8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane9.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom10 = [NXOpen.NXObject.Null] * 1 
    geom10[0] = face2
    plane9.SetGeometry(geom10)
    
    plane9.SetFlip(False)
    
    plane9.SetExpression(None)
    
    plane9.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane9.Evaluate()
    
    origin9 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal9 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane10 = workPart.Planes.CreatePlane(origin9, normal9, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression44 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression45 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane10.SynchronizeToPlane(plane9)
    
    scalar7 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point19 = workPart.Points.CreatePoint(edge3, scalar7, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane10.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom11 = [NXOpen.NXObject.Null] * 1 
    geom11[0] = face2
    plane10.SetGeometry(geom11)
    
    plane10.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane10.Evaluate()
    
    markId77 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId77, None)
    
    markId78 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject16 = sketchInPlaceBuilder5.Commit()
    
    sketch5 = nXObject16
    feature7 = sketch5.Feature
    
    markId79 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs6 = theSession.UpdateManager.DoUpdate(markId79)
    
    sketch5.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId78, None)
    
    theSession.SetUndoMarkName(markId76, "Create Sketch")
    
    sketchInPlaceBuilder5.Destroy()
    
    sketchAlongPathBuilder4.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression43)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point19)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression42)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane8.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression45)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression44)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane10.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId80 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId81 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId81, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint13 = NXOpen.Point3d(109.99999999999416, 0.0, 0.0)
    endPoint13 = NXOpen.Point3d(109.99999999999416, 100.0, 0.0)
    line14 = workPart.Curves.CreateLine(startPoint13, endPoint13)
    
    startPoint14 = NXOpen.Point3d(109.99999999999416, 100.0, 0.0)
    endPoint14 = NXOpen.Point3d(109.99999999999416, 100.0, 15.0)
    line15 = workPart.Curves.CreateLine(startPoint14, endPoint14)
    
    startPoint15 = NXOpen.Point3d(109.99999999999416, 100.0, 15.0)
    endPoint15 = NXOpen.Point3d(109.99999999999416, 0.0, 15.0)
    line16 = workPart.Curves.CreateLine(startPoint15, endPoint15)
    
    startPoint16 = NXOpen.Point3d(109.99999999999416, 0.0, 15.0)
    endPoint16 = NXOpen.Point3d(109.99999999999416, 0.0, 0.0)
    line17 = workPart.Curves.CreateLine(startPoint16, endPoint16)
    
    theSession.ActiveSketch.AddGeometry(line14, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line15, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line16, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line17, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_14.Geometry = line14
    geom1_14.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_14.SplineDefiningPointIndex = 0
    geom2_14 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_14.Geometry = line15
    geom2_14.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_14.SplineDefiningPointIndex = 0
    sketchGeometricConstraint33 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_14, geom2_14)
    
    geom1_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_15.Geometry = line15
    geom1_15.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_15.SplineDefiningPointIndex = 0
    geom2_15 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_15.Geometry = line16
    geom2_15.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_15.SplineDefiningPointIndex = 0
    sketchGeometricConstraint34 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_15, geom2_15)
    
    geom1_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_16.Geometry = line16
    geom1_16.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_16.SplineDefiningPointIndex = 0
    geom2_16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_16.Geometry = line17
    geom2_16.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint35 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_16, geom2_16)
    
    geom1_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_17.Geometry = line17
    geom1_17.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_17.SplineDefiningPointIndex = 0
    geom2_17 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_17.Geometry = line14
    geom2_17.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_17.SplineDefiningPointIndex = 0
    sketchGeometricConstraint36 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_17, geom2_17)
    
    geom12 = NXOpen.Sketch.ConstraintGeometry()
    
    geom12.Geometry = line14
    geom12.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom12.SplineDefiningPointIndex = 0
    sketchGeometricConstraint37 = theSession.ActiveSketch.CreateHorizontalConstraint(geom12)
    
    conGeom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_18.Geometry = line14
    conGeom1_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_18.SplineDefiningPointIndex = 0
    conGeom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_18.Geometry = line15
    conGeom2_18.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint38 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_18, conGeom2_18)
    
    conGeom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_19.Geometry = line15
    conGeom1_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_19.SplineDefiningPointIndex = 0
    conGeom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_19.Geometry = line16
    conGeom2_19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint39 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_19, conGeom2_19)
    
    conGeom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_20.Geometry = line16
    conGeom1_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_20.SplineDefiningPointIndex = 0
    conGeom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_20.Geometry = line17
    conGeom2_20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint40 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_20, conGeom2_20)
    
    conGeom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_21.Geometry = line17
    conGeom1_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_21.SplineDefiningPointIndex = 0
    conGeom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_21.Geometry = line14
    conGeom2_21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint41 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_21, conGeom2_21)
    
    geom1_18 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_18.Geometry = line14
    geom1_18.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_18.SplineDefiningPointIndex = 0
    geom2_18 = NXOpen.Sketch.ConstraintGeometry()
    
    edge5 = extrude1.FindObject("EDGE * 150 * 160 {(99.9999999999942,-0.0000000000001,40)(99.9999999999942,-0.0000000000001,20)(99.9999999999942,-0.0000000000001,0) EXTRUDE(2)}")
    geom2_18.Geometry = edge5
    geom2_18.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_18.SplineDefiningPointIndex = 0
    sketchGeometricConstraint42 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_18, geom2_18)
    
    geom13 = NXOpen.Sketch.ConstraintGeometry()
    
    geom13.Geometry = line14
    geom13.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom13.SplineDefiningPointIndex = 0
    try:
        # Constraint already exists.
        sketchGeometricConstraint43 = theSession.ActiveSketch.CreateHorizontalConstraint(geom13)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(910023)
        
    geom1_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_19.Geometry = line14
    geom1_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_19.SplineDefiningPointIndex = 0
    geom2_19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_19.Geometry = edge2
    geom2_19.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint44 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_19, geom2_19)
    
    conGeom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_22.Geometry = line14
    conGeom1_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_22.SplineDefiningPointIndex = 0
    geom1Help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help3.Point.X = 109.99999999999416
    geom1Help3.Point.Y = 100.0
    geom1Help3.Point.Z = 0.0
    geom1Help3.Parameter = 0.0
    conGeom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_22.Geometry = edge2
    conGeom2_22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_22.SplineDefiningPointIndex = 0
    geom2Help3 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help3.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help3.Point.X = 109.99999999999416
    geom2Help3.Point.Y = 100.0
    geom2Help3.Point.Z = 0.0
    geom2Help3.Parameter = 0.0
    try:
        # Invalid object type
        sketchGeometricConstraint45 = theSession.ActiveSketch.CreateNormalConstraint(conGeom1_22, geom1Help3, conGeom2_22, geom2Help3)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(875033)
        
    dimObject1_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_8.Geometry = line14
    dimObject1_8.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_8.AssocValue = 0
    dimObject1_8.HelpPoint.X = 0.0
    dimObject1_8.HelpPoint.Y = 0.0
    dimObject1_8.HelpPoint.Z = 0.0
    dimObject1_8.View = NXOpen.NXObject.Null
    dimObject2_8 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_8.Geometry = line14
    dimObject2_8.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_8.AssocValue = 0
    dimObject2_8.HelpPoint.X = 0.0
    dimObject2_8.HelpPoint.Y = 0.0
    dimObject2_8.HelpPoint.Z = 0.0
    dimObject2_8.View = NXOpen.NXObject.Null
    dimOrigin8 = NXOpen.Point3d(109.99999999999416, 50.0, -5.1375255657578016)
    sketchDimensionalConstraint8 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_8, dimObject2_8, dimOrigin8, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint7 = sketchDimensionalConstraint8
    dimension8 = sketchHelpedDimensionalConstraint7.AssociatedDimension
    
    expression46 = sketchHelpedDimensionalConstraint7.AssociatedExpression
    
    dimObject1_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_9.Geometry = line15
    dimObject1_9.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_9.AssocValue = 0
    dimObject1_9.HelpPoint.X = 0.0
    dimObject1_9.HelpPoint.Y = 0.0
    dimObject1_9.HelpPoint.Z = 0.0
    dimObject1_9.View = NXOpen.NXObject.Null
    dimObject2_9 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_9.Geometry = line15
    dimObject2_9.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_9.AssocValue = 0
    dimObject2_9.HelpPoint.X = 0.0
    dimObject2_9.HelpPoint.Y = 0.0
    dimObject2_9.HelpPoint.Z = 0.0
    dimObject2_9.View = NXOpen.NXObject.Null
    dimOrigin9 = NXOpen.Point3d(109.99999999999416, 105.1375255657578, 7.5)
    sketchDimensionalConstraint9 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_9, dimObject2_9, dimOrigin9, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint8 = sketchDimensionalConstraint9
    dimension9 = sketchHelpedDimensionalConstraint8.AssociatedDimension
    
    expression47 = sketchHelpedDimensionalConstraint8.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms7 = [NXOpen.SmartObject.Null] * 4 
    geoms7[0] = line14
    geoms7[1] = line15
    geoms7[2] = line16
    geoms7[3] = line17
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms7)
    
    geoms8 = [NXOpen.SmartObject.Null] * 4 
    geoms8[0] = line14
    geoms8[1] = line15
    geoms8[2] = line16
    geoms8[3] = line17
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms8)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId82 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder3 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section3 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder3.Section = section3
    
    extrudeBuilder3.AllowSelfIntersectingSection(True)
    
    expression48 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder3.DistanceTolerance = 0.01
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies5 = [NXOpen.Body.Null] * 1 
    targetBodies5[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies5)
    
    extrudeBuilder3.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder3.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies6 = [NXOpen.Body.Null] * 1 
    targetBodies6[0] = NXOpen.Body.Null
    extrudeBuilder3.BooleanOperation.SetTargetBodies(targetBodies6)
    
    extrudeBuilder3.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder3.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder3.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder3 = extrudeBuilder3.SmartVolumeProfile
    
    smartVolumeProfileBuilder3.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder3.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId82, "Extrude Dialog")
    
    section3.DistanceTolerance = 0.01
    
    section3.ChainingTolerance = 0.0094999999999999998
    
    section3.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId83 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves4 = [NXOpen.ICurve.Null] * 4 
    curves4[0] = line16
    curves4[1] = line14
    curves4[2] = line17
    curves4[3] = line15
    seedPoint4 = NXOpen.Point3d(109.99999999999416, 33.333333333333336, 10.0)
    regionBoundaryRule4 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves4, seedPoint4, 0.01)
    
    section3.AllowSelfIntersection(True)
    
    rules4 = [None] * 1 
    rules4[0] = regionBoundaryRule4
    helpPoint4 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section3.AddToSection(rules4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint4, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId83, None)
    
    markId84 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId85 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId85, None)
    
    direction7 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction7
    
    expression49 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId84, None)
    
    markId86 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId87 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section3.Clear()
    
    theSession.DeleteUndoMark(markId87, None)
    
    workPart.Expressions.Delete(expression49)
    
    theSession.DeleteUndoMark(markId86, None)
    
    rotMatrix6 = NXOpen.Matrix3x3()
    
    rotMatrix6.Xx = -0.33472794836011566
    rotMatrix6.Xy = 0.85597289099598117
    rotMatrix6.Xz = -0.39404011276342299
    rotMatrix6.Yx = -0.73325050128723235
    rotMatrix6.Yy = 0.026046252579931914
    rotMatrix6.Yz = 0.67945956103992411
    rotMatrix6.Zx = 0.59186223308186503
    rotMatrix6.Zy = 0.51636421507161556
    rotMatrix6.Zz = 0.61892414272253471
    translation6 = NXOpen.Point3d(4.109066405914156, 30.325717000408371, -127.9607166678237)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix6, translation6, 1.7518160999501462)
    
    markId88 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId89 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features2 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature2 = feature7
    features2[0] = sketchFeature2
    curveFeatureRule2 = workPart.ScRuleFactory.CreateRuleCurveFeature(features2)
    
    section3.AllowSelfIntersection(True)
    
    rules5 = [None] * 1 
    rules5[0] = curveFeatureRule2
    helpPoint5 = NXOpen.Point3d(109.99999999999434, 2.8421709430404007e-14, 4.6893320837230661)
    section3.AddToSection(rules5, line17, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint5, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId89, None)
    
    direction8 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder3.Direction = direction8
    
    expression50 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId88, None)
    
    extrudeBuilder3.Limits.EndExtend.Value.SetFormula("15")
    
    markId90 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId90, None)
    
    markId91 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder3.ParentFeatureInternal = False
    
    markId92 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature8 = extrudeBuilder3.CommitFeature()
    
    theSession.DeleteUndoMark(markId91, None)
    
    theSession.SetUndoMarkName(markId82, "Extrude")
    
    expression51 = extrudeBuilder3.Limits.StartExtend.Value
    expression52 = extrudeBuilder3.Limits.EndExtend.Value
    extrudeBuilder3.Destroy()
    
    workPart.Expressions.Delete(expression48)
    
    workPart.Expressions.Delete(expression50)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId93 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder6 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal10 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane11 = workPart.Planes.CreatePlane(origin10, normal10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.PlaneReference = plane11
    
    expression53 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression54 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder5 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder5.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId93, "Create Sketch Dialog")
    
    scalar8 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude3 = feature8
    edge6 = extrude3.FindObject("EDGE * 140 * 150 {(124.9999999999942,0,15)(117.4999999999942,0,15)(109.9999999999942,0,15) EXTRUDE(6)}")
    point20 = workPart.Points.CreatePoint(edge6, scalar8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge7 = extrude3.FindObject("EDGE * 120 * 150 {(109.9999999999942,0,15)(109.9999999999942,50,15)(109.9999999999942,100,15) EXTRUDE(6)}")
    direction9 = workPart.Directions.CreateDirection(edge7, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face3 = extrude3.FindObject("FACE 150 {(117.4999999999942,50,15) EXTRUDE(6)}")
    xform3 = workPart.Xforms.CreateXformByPlaneXDirPoint(face3, direction9, point20, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem3 = workPart.CoordinateSystems.CreateCoordinateSystem(xform3, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder6.Csystem = cartesianCoordinateSystem3
    
    origin11 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal11 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane12 = workPart.Planes.CreatePlane(origin11, normal11, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane12.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom14 = [NXOpen.NXObject.Null] * 1 
    geom14[0] = face3
    plane12.SetGeometry(geom14)
    
    plane12.SetFlip(False)
    
    plane12.SetExpression(None)
    
    plane12.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane12.Evaluate()
    
    origin12 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal12 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane13 = workPart.Planes.CreatePlane(origin12, normal12, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression55 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression56 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane13.SynchronizeToPlane(plane12)
    
    scalar9 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point21 = workPart.Points.CreatePoint(edge6, scalar9, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane13.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom15 = [NXOpen.NXObject.Null] * 1 
    geom15[0] = face3
    plane13.SetGeometry(geom15)
    
    plane13.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane13.Evaluate()
    
    markId94 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId94, None)
    
    markId95 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject17 = sketchInPlaceBuilder6.Commit()
    
    sketch6 = nXObject17
    feature9 = sketch6.Feature
    
    markId96 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs7 = theSession.UpdateManager.DoUpdate(markId96)
    
    sketch6.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId95, None)
    
    theSession.SetUndoMarkName(markId93, "Create Sketch")
    
    sketchInPlaceBuilder6.Destroy()
    
    sketchAlongPathBuilder5.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression54)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point21)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression53)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane11.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression56)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression55)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane13.DestroyPlane()
    
    scaleAboutPoint117 = NXOpen.Point3d(75.516868848523288, -22.957128129951215, 0.0)
    viewCenter117 = NXOpen.Point3d(-75.51686884852316, 22.95712812995092, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint117, viewCenter117)
    
    scaleAboutPoint118 = NXOpen.Point3d(94.396086060654099, -28.696410162438966, 0.0)
    viewCenter118 = NXOpen.Point3d(-94.396086060653943, 28.696410162438674, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint118, viewCenter118)
    
    scaleAboutPoint119 = NXOpen.Point3d(117.9951075758176, -35.870512703048661, 0.0)
    viewCenter119 = NXOpen.Point3d(-117.9951075758174, 35.870512703048362, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint119, viewCenter119)
    
    scaleAboutPoint120 = NXOpen.Point3d(147.49388446977201, -44.838140878810812, 0.0)
    viewCenter120 = NXOpen.Point3d(-147.49388446977187, 44.838140878810513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint120, viewCenter120)
    
    scaleAboutPoint121 = NXOpen.Point3d(184.36735558721489, -55.31020667616459, 0.0)
    viewCenter121 = NXOpen.Point3d(-184.36735558721477, 55.310206676164306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint121, viewCenter121)
    
    scaleAboutPoint122 = NXOpen.Point3d(147.49388446977193, -44.248165340931699, 0.0)
    viewCenter122 = NXOpen.Point3d(-147.49388446977181, 44.248165340931394, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint122, viewCenter122)
    
    scaleAboutPoint123 = NXOpen.Point3d(117.99510757581756, -35.398532272745399, 0.0)
    viewCenter123 = NXOpen.Point3d(-117.99510757581744, 35.398532272745115, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint123, viewCenter123)
    
    scaleAboutPoint124 = NXOpen.Point3d(94.396086060654042, -28.318825818196348, 0.0)
    viewCenter124 = NXOpen.Point3d(-94.396086060653943, 28.318825818196057, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint124, viewCenter124)
    
    scaleAboutPoint125 = NXOpen.Point3d(75.516868848523202, -22.655060654557101, 0.0)
    viewCenter125 = NXOpen.Point3d(-75.516868848523117, 22.655060654556831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint125, viewCenter125)
    
    scaleAboutPoint126 = NXOpen.Point3d(60.413495078818592, -18.124048523645715, 0.0)
    viewCenter126 = NXOpen.Point3d(-60.413495078818507, 18.124048523645435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint126, viewCenter126)
    
    scaleAboutPoint127 = NXOpen.Point3d(52.583906116603714, -16.045824292934345, 0.0)
    viewCenter127 = NXOpen.Point3d(-52.583906116603629, 16.045824292934064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint127, viewCenter127)
    
    scaleAboutPoint128 = NXOpen.Point3d(66.454844586700403, -20.540588326798435, 0.0)
    viewCenter128 = NXOpen.Point3d(-66.454844586700347, 20.540588326798169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint128, viewCenter128)
    
    scaleAboutPoint129 = NXOpen.Point3d(83.370623208769601, -25.826769146195065, 0.0)
    viewCenter129 = NXOpen.Point3d(-83.370623208769572, 25.826769146194785, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint129, viewCenter129)
    
    scaleAboutPoint130 = NXOpen.Point3d(104.40207118308331, -32.283461432743806, 0.0)
    viewCenter130 = NXOpen.Point3d(-104.40207118308325, 32.283461432743529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint130, viewCenter130)
    
    scaleAboutPoint131 = NXOpen.Point3d(130.73857919400575, -40.354326790929711, 0.0)
    viewCenter131 = NXOpen.Point3d(-130.73857919400567, 40.354326790929406, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint131, viewCenter131)
    
    scaleAboutPoint132 = NXOpen.Point3d(163.42322399250713, -50.442908488662106, 0.0)
    viewCenter132 = NXOpen.Point3d(-163.4232239925071, 50.4429084886618, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint132, viewCenter132)
    
    scaleAboutPoint133 = NXOpen.Point3d(255.90188955505403, -75.221881079583738, 0.0)
    viewCenter133 = NXOpen.Point3d(-255.90188955505403, 75.221881079583454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint133, viewCenter133)
    
    scaleAboutPoint134 = NXOpen.Point3d(320.79919872175361, -95.410106516383735, 0.0)
    viewCenter134 = NXOpen.Point3d(-320.79919872175361, 95.410106516383507, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint134, viewCenter134)
    
    scaleAboutPoint135 = NXOpen.Point3d(402.15129437461195, -119.2626331454796, 0.0)
    viewCenter135 = NXOpen.Point3d(-402.15129437461189, 119.2626331454794, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint135, viewCenter135)
    
    scaleAboutPoint136 = NXOpen.Point3d(-190.84902043207762, -99.385527621233052, 0.0)
    viewCenter136 = NXOpen.Point3d(190.84902043207785, 99.385527621232796, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint136, viewCenter136)
    
    scaleAboutPoint137 = NXOpen.Point3d(-243.96266291081639, -124.23190952654129, 0.0)
    viewCenter137 = NXOpen.Point3d(243.96266291081645, 124.23190952654106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint137, viewCenter137)
    
    scaleAboutPoint138 = NXOpen.Point3d(-308.32919574521969, -155.28988690817658, 0.0)
    viewCenter138 = NXOpen.Point3d(308.32919574521998, 155.28988690817638, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint138, viewCenter138)
    
    scaleAboutPoint139 = NXOpen.Point3d(-389.63132856489909, -194.11235863522072, 0.0)
    viewCenter139 = NXOpen.Point3d(389.6313285648996, 194.11235863522046, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint139, viewCenter139)
    
    scaleAboutPoint140 = NXOpen.Point3d(318.24580537114991, -522.20444306757724, 0.0)
    viewCenter140 = NXOpen.Point3d(-318.24580537114929, 522.20444306757713, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint140, viewCenter140)
    
    scaleAboutPoint141 = NXOpen.Point3d(256.00325559137798, -414.95033186514564, 0.0)
    viewCenter141 = NXOpen.Point3d(-256.00325559137747, 414.95033186514513, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint141, viewCenter141)
    
    scaleAboutPoint142 = NXOpen.Point3d(205.92789350866897, -326.33382031428403, 0.0)
    viewCenter142 = NXOpen.Point3d(-205.9278935086686, 326.33382031428357, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint142, viewCenter142)
    
    scaleAboutPoint143 = NXOpen.Point3d(116.12982847046263, -185.44763306135877, 0.0)
    viewCenter143 = NXOpen.Point3d(-116.12982847046217, 185.44763306135823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint143, viewCenter143)
    
    scaleAboutPoint144 = NXOpen.Point3d(92.903862776370104, -148.35810644908707, 0.0)
    viewCenter144 = NXOpen.Point3d(-92.903862776369735, 148.35810644908659, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint144, viewCenter144)
    
    scaleAboutPoint145 = NXOpen.Point3d(73.170794248676074, -119.2626331454798, 0.0)
    viewCenter145 = NXOpen.Point3d(-73.170794248675634, 119.2626331454793, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint145, viewCenter145)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId97 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId98 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId98, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint17 = NXOpen.Point3d(124.99999999999416, 50.0, 15.0)
    endPoint17 = NXOpen.Point3d(329.99999999999415, 49.999999999999233, 15.0)
    line18 = workPart.Curves.CreateLine(startPoint17, endPoint17)
    
    theSession.ActiveSketch.AddGeometry(line18, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_20.Geometry = line18
    geom1_20.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_20.SplineDefiningPointIndex = 0
    geom2_20 = NXOpen.Sketch.ConstraintGeometry()
    
    edge8 = extrude3.FindObject("EDGE * 130 * 150 {(124.9999999999942,0,15)(124.9999999999942,50,15)(124.9999999999942,100,15) EXTRUDE(6)}")
    geom2_20.Geometry = edge8
    geom2_20.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint46 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_20, geom2_20)
    
    geom16 = NXOpen.Sketch.ConstraintGeometry()
    
    geom16.Geometry = line18
    geom16.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom16.SplineDefiningPointIndex = 0
    sketchGeometricConstraint47 = theSession.ActiveSketch.CreateVerticalConstraint(geom16)
    
    dimObject1_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_10.Geometry = line18
    dimObject1_10.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_10.AssocValue = 0
    dimObject1_10.HelpPoint.X = 0.0
    dimObject1_10.HelpPoint.Y = 0.0
    dimObject1_10.HelpPoint.Z = 0.0
    dimObject1_10.View = NXOpen.NXObject.Null
    dimObject2_10 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_10.Geometry = line18
    dimObject2_10.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_10.AssocValue = 0
    dimObject2_10.HelpPoint.X = 0.0
    dimObject2_10.HelpPoint.Y = 0.0
    dimObject2_10.HelpPoint.Z = 0.0
    dimObject2_10.View = NXOpen.NXObject.Null
    dimOrigin10 = NXOpen.Point3d(227.49999999999409, 34.321516217779788, 15.0)
    sketchDimensionalConstraint10 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_10, dimObject2_10, dimOrigin10, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint9 = sketchDimensionalConstraint10
    dimension10 = sketchHelpedDimensionalConstraint9.AssociatedDimension
    
    expression57 = sketchHelpedDimensionalConstraint9.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId99 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId100 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId100, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix1 = theSession.ActiveSketch.Orientation
    
    center1 = NXOpen.Point3d(329.99999999999415, 49.999999999999233, 15.0)
    arc1 = workPart.Curves.CreateArc(center1, nXMatrix1, 211.00947846009211, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc1, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_21.Geometry = arc1
    geom1_21.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    geom1_21.SplineDefiningPointIndex = 0
    geom2_21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_21.Geometry = line18
    geom2_21.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint48 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_21, geom2_21)
    
    conGeom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_23.Geometry = arc1
    conGeom1_23.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_23.SplineDefiningPointIndex = 0
    conGeom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    edge9 = extrude3.FindObject("EDGE * 150 * 160 {(124.9999999999942,100,15)(117.4999999999942,100,15)(109.9999999999942,100,15) EXTRUDE(6)}")
    conGeom2_23.Geometry = edge9
    conGeom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom2_23.SplineDefiningPointIndex = 0
    help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help4.Point.X = 124.99999999999416
    help4.Point.Y = 100.0
    help4.Point.Z = 15.0
    help4.Parameter = 0.0
    sketchHelpedGeometricConstraint4 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_23, conGeom2_23, help4)
    
    dimObject1_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_11.Geometry = arc1
    dimObject1_11.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_11.AssocValue = 0
    dimObject1_11.HelpPoint.X = 0.0
    dimObject1_11.HelpPoint.Y = 0.0
    dimObject1_11.HelpPoint.Z = 0.0
    dimObject1_11.View = NXOpen.NXObject.Null
    dimOrigin11 = NXOpen.Point3d(324.77383873925419, 49.999999999999233, 15.0)
    sketchDimensionalConstraint11 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_11, dimOrigin11, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension11 = sketchDimensionalConstraint11.AssociatedDimension
    
    expression58 = sketchDimensionalConstraint11.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId101 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder4 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section4 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder4.Section = section4
    
    extrudeBuilder4.AllowSelfIntersectingSection(True)
    
    expression59 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder4.DistanceTolerance = 0.01
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies7 = [NXOpen.Body.Null] * 1 
    targetBodies7[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies7)
    
    extrudeBuilder4.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("15")
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies8 = [NXOpen.Body.Null] * 1 
    targetBodies8[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies8)
    
    extrudeBuilder4.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder4.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder4.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder4 = extrudeBuilder4.SmartVolumeProfile
    
    smartVolumeProfileBuilder4.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder4.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId101, "Extrude Dialog")
    
    section4.DistanceTolerance = 0.01
    
    section4.ChainingTolerance = 0.0094999999999999998
    
    section4.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId102 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves5 = [NXOpen.ICurve.Null] * 2 
    curves5[0] = line18
    curves5[1] = arc1
    seedPoint5 = NXOpen.Point3d(306.27315642203706, 26.273156422042234, 15.0)
    regionBoundaryRule5 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves5, seedPoint5, 0.01)
    
    section4.AllowSelfIntersection(True)
    
    rules6 = [None] * 1 
    rules6[0] = regionBoundaryRule5
    helpPoint6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section4.AddToSection(rules6, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint6, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId102, None)
    
    markId103 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId104 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId104, None)
    
    direction10 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder4.Direction = direction10
    
    expression60 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId103, None)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies9 = [NXOpen.Body.Null] * 1 
    targetBodies9[0] = NXOpen.Body.Null
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies9)
    
    rotMatrix7 = NXOpen.Matrix3x3()
    
    rotMatrix7.Xx = 0.0
    rotMatrix7.Xy = 1.0
    rotMatrix7.Xz = 0.0
    rotMatrix7.Yx = -0.56036266787402678
    rotMatrix7.Yy = 0.0
    rotMatrix7.Yz = 0.82824735463091137
    rotMatrix7.Zx = 0.82824735463091137
    rotMatrix7.Zy = 0.0
    rotMatrix7.Zz = 0.56036266787402678
    translation7 = NXOpen.Point3d(-127.89900495879019, 78.44083901639965, -230.25208803988826)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix7, translation7, 0.57403509963166466)
    
    rotMatrix8 = NXOpen.Matrix3x3()
    
    rotMatrix8.Xx = 0.61158583690567159
    rotMatrix8.Xy = 0.79110746417281863
    rotMatrix8.Xz = 0.010570914172463423
    rotMatrix8.Yx = -0.072106134942563849
    rotMatrix8.Yy = 0.042428163626641119
    rotMatrix8.Yz = 0.99649413256421904
    rotMatrix8.Zx = 0.78788544179977915
    rotMatrix8.Zy = -0.61020392579966543
    rotMatrix8.Zz = 0.082992165525684822
    translation8 = NXOpen.Point3d(-286.63572303758656, -58.403611164334613, -189.59694667679821)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix8, translation8, 0.57403509963166466)
    
    direction11 = extrudeBuilder4.Direction
    
    success1 = direction11.ReverseDirection()
    
    extrudeBuilder4.Direction = direction11
    
    extrudeBuilder4.Limits.EndExtend.Value.SetFormula("50")
    
    rotMatrix9 = NXOpen.Matrix3x3()
    
    rotMatrix9.Xx = 0.60297771826225666
    rotMatrix9.Xy = 0.79766941939144331
    rotMatrix9.Xz = -0.011889854791384189
    rotMatrix9.Yx = -0.62482075613407684
    rotMatrix9.Yy = 0.48147881193097525
    rotMatrix9.Yz = 0.61463580791032424
    rotMatrix9.Zx = 0.4960009011920069
    rotMatrix9.Zy = -0.36318266895496959
    rotMatrix9.Zz = 0.78872140517895328
    translation9 = NXOpen.Point3d(-284.07508430325049, 84.218736688609113, -132.9285015383501)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix9, translation9, 0.57403509963166466)
    
    extrudeBuilder4.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies10 = [NXOpen.Body.Null] * 1 
    body1 = workPart.Bodies.FindObject("EXTRUDE(6)")
    targetBodies10[0] = body1
    extrudeBuilder4.BooleanOperation.SetTargetBodies(targetBodies10)
    
    rotMatrix10 = NXOpen.Matrix3x3()
    
    rotMatrix10.Xx = 0.60686178236492438
    rotMatrix10.Xy = 0.79480615727843507
    rotMatrix10.Xz = -0.0013962296210164524
    rotMatrix10.Yx = -0.74309507761303129
    rotMatrix10.Yy = 0.56800014328045101
    rotMatrix10.Yz = 0.35381569052357059
    rotMatrix10.Zx = 0.28200794799464546
    rotMatrix10.Zy = -0.21367968922121619
    rotMatrix10.Zz = 0.93531412246484058
    translation10 = NXOpen.Point3d(-285.24087862003074, 118.56619700357066, -82.92081017484027)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix10, translation10, 0.57403509963166466)
    
    markId105 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId105, None)
    
    markId106 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder4.ParentFeatureInternal = False
    
    markId107 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature10 = extrudeBuilder4.CommitFeature()
    
    theSession.DeleteUndoMark(markId106, None)
    
    theSession.SetUndoMarkName(markId101, "Extrude")
    
    expression61 = extrudeBuilder4.Limits.StartExtend.Value
    expression62 = extrudeBuilder4.Limits.EndExtend.Value
    extrudeBuilder4.Destroy()
    
    workPart.Expressions.Delete(expression59)
    
    workPart.Expressions.Delete(expression60)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId108 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder7 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal13 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane14 = workPart.Planes.CreatePlane(origin13, normal13, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.PlaneReference = plane14
    
    expression63 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression64 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder6 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder6.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId108, "Create Sketch Dialog")
    
    scalar10 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    edge10 = extrude1.FindObject("EDGE * 120 * 150 {(0,-0,0)(49.9999999999971,-0.0000000000001,0)(99.9999999999942,-0.0000000000001,0) EXTRUDE(2)}")
    point22 = workPart.Points.CreatePoint(edge10, scalar10, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction12 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face4 = extrude1.FindObject("FACE 150 {(49.9999999999971,-0.0000000000001,20) EXTRUDE(2)}")
    xform4 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction12, point22, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder7.Csystem = cartesianCoordinateSystem4
    
    origin14 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal14 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane15 = workPart.Planes.CreatePlane(origin14, normal14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane15.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom17 = [NXOpen.NXObject.Null] * 1 
    geom17[0] = face4
    plane15.SetGeometry(geom17)
    
    plane15.SetFlip(False)
    
    plane15.SetExpression(None)
    
    plane15.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane15.Evaluate()
    
    origin15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal15 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane16 = workPart.Planes.CreatePlane(origin15, normal15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression65 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression66 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane16.SynchronizeToPlane(plane15)
    
    scalar11 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point23 = workPart.Points.CreatePoint(edge10, scalar11, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane16.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom18 = [NXOpen.NXObject.Null] * 1 
    geom18[0] = face4
    plane16.SetGeometry(geom18)
    
    plane16.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane16.Evaluate()
    
    markId109 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId109, None)
    
    markId110 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject18 = sketchInPlaceBuilder7.Commit()
    
    sketch7 = nXObject18
    feature11 = sketch7.Feature
    
    markId111 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs8 = theSession.UpdateManager.DoUpdate(markId111)
    
    sketch7.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId110, None)
    
    theSession.SetUndoMarkName(markId108, "Create Sketch")
    
    sketchInPlaceBuilder7.Destroy()
    
    sketchAlongPathBuilder6.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression64)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point23)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression63)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane14.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression66)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression65)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane16.DestroyPlane()
    
    scaleAboutPoint146 = NXOpen.Point3d(188.51562108792729, -0.46091838896824644, 0.0)
    viewCenter146 = NXOpen.Point3d(-188.5156210879268, 0.46091838896777482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint146, viewCenter146)
    
    scaleAboutPoint147 = NXOpen.Point3d(201.07564718730632, 3.4568879172600311, 0.0)
    viewCenter147 = NXOpen.Point3d(-201.07564718730586, -3.4568879172605222, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint147, viewCenter147)
    
    scaleAboutPoint148 = NXOpen.Point3d(198.05087025970343, 10.082589758675601, 0.0)
    viewCenter148 = NXOpen.Point3d(-198.05087025970312, -10.082589758676093, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint148, viewCenter148)
    
    scaleAboutPoint149 = NXOpen.Point3d(158.44069620776276, 6.9137758345203562, 0.0)
    viewCenter149 = NXOpen.Point3d(-158.44069620776244, -6.9137758345207985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint149, viewCenter149)
    
    scaleAboutPoint150 = NXOpen.Point3d(127.21347535517832, 5.5310206676162457, 0.0)
    viewCenter150 = NXOpen.Point3d(-127.21347535517801, -5.5310206676166382, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint150, viewCenter150)
    
    scaleAboutPoint151 = NXOpen.Point3d(101.77078028414279, 4.4248165340929653, 0.0)
    viewCenter151 = NXOpen.Point3d(-101.77078028414235, -4.4248165340933419, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint151, viewCenter151)
    
    scaleAboutPoint152 = NXOpen.Point3d(81.416624227314287, 3.5398532272743473, 0.0)
    viewCenter152 = NXOpen.Point3d(-81.416624227313775, -3.5398532272747243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint152, viewCenter152)
    
    scaleAboutPoint153 = NXOpen.Point3d(88.968311112166489, 21.947090009101835, 0.0)
    viewCenter153 = NXOpen.Point3d(-88.968311112166091, -21.947090009102237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint153, viewCenter153)
    
    scaleAboutPoint154 = NXOpen.Point3d(71.17464888973322, 17.557672007281418, 0.0)
    viewCenter154 = NXOpen.Point3d(-71.174648889732836, -17.557672007281823, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint154, viewCenter154)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId112 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId113 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    theSession.SetUndoMarkVisibility(markId113, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint18 = NXOpen.Point3d(0.0, -2.2413700126928761e-45, 40.0)
    endPoint18 = NXOpen.Point3d(-3.920107718544707e-14, -2.2413700126928761e-45, 20.0)
    line19 = workPart.Curves.CreateLine(startPoint18, endPoint18)
    
    startPoint19 = NXOpen.Point3d(-3.920107718544707e-14, -2.2413700126928761e-45, 20.0)
    endPoint19 = NXOpen.Point3d(43.088697478379267, -2.2413700126928761e-45, 19.999999999999847)
    line20 = workPart.Curves.CreateLine(startPoint19, endPoint19)
    
    startPoint20 = NXOpen.Point3d(43.088697478379267, -2.2413700126928761e-45, 19.999999999999847)
    endPoint20 = NXOpen.Point3d(43.088697478379274, -2.2413700126928761e-45, 40.0)
    line21 = workPart.Curves.CreateLine(startPoint20, endPoint20)
    
    startPoint21 = NXOpen.Point3d(43.088697478379274, -2.2413700126928761e-45, 40.0)
    endPoint21 = NXOpen.Point3d(0.0, -2.2413700126928761e-45, 40.0)
    line22 = workPart.Curves.CreateLine(startPoint21, endPoint21)
    
    theSession.ActiveSketch.AddGeometry(line19, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line20, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line21, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line22, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_22.Geometry = line19
    geom1_22.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_22.SplineDefiningPointIndex = 0
    geom2_22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_22.Geometry = line20
    geom2_22.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint49 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_22, geom2_22)
    
    geom1_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_23.Geometry = line20
    geom1_23.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_23.SplineDefiningPointIndex = 0
    geom2_23 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_23.Geometry = line21
    geom2_23.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_23.SplineDefiningPointIndex = 0
    sketchGeometricConstraint50 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_23, geom2_23)
    
    geom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_24.Geometry = line21
    geom1_24.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_24.SplineDefiningPointIndex = 0
    geom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_24.Geometry = line22
    geom2_24.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint51 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_24, geom2_24)
    
    geom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_25.Geometry = line22
    geom1_25.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_25.SplineDefiningPointIndex = 0
    geom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_25.Geometry = line19
    geom2_25.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint52 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_25, geom2_25)
    
    geom19 = NXOpen.Sketch.ConstraintGeometry()
    
    geom19.Geometry = line20
    geom19.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom19.SplineDefiningPointIndex = 0
    sketchGeometricConstraint53 = theSession.ActiveSketch.CreateHorizontalConstraint(geom19)
    
    conGeom1_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_24.Geometry = line19
    conGeom1_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_24.SplineDefiningPointIndex = 0
    conGeom2_24 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_24.Geometry = line20
    conGeom2_24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint54 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_24, conGeom2_24)
    
    conGeom1_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_25.Geometry = line20
    conGeom1_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_25.SplineDefiningPointIndex = 0
    conGeom2_25 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_25.Geometry = line21
    conGeom2_25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint55 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_25, conGeom2_25)
    
    conGeom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_26.Geometry = line21
    conGeom1_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_26.SplineDefiningPointIndex = 0
    conGeom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_26.Geometry = line22
    conGeom2_26.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint56 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_26, conGeom2_26)
    
    conGeom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_27.Geometry = line22
    conGeom1_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_27.SplineDefiningPointIndex = 0
    conGeom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_27.Geometry = line19
    conGeom2_27.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint57 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_27, conGeom2_27)
    
    geom1_26 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_26.Geometry = line19
    geom1_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_26.SplineDefiningPointIndex = 0
    geom2_26 = NXOpen.Sketch.ConstraintGeometry()
    
    edge11 = extrude1.FindObject("EDGE * 130 * 150 {(0,-0,40)(49.9999999999971,-0.0000000000001,40)(99.9999999999942,-0.0000000000001,40) EXTRUDE(2)}")
    geom2_26.Geometry = edge11
    geom2_26.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_26.SplineDefiningPointIndex = 0
    sketchGeometricConstraint58 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_26, geom2_26)
    
    geom20 = NXOpen.Sketch.ConstraintGeometry()
    
    geom20.Geometry = line19
    geom20.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom20.SplineDefiningPointIndex = 0
    sketchGeometricConstraint59 = theSession.ActiveSketch.CreateVerticalConstraint(geom20)
    
    conGeom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_28.Geometry = line19
    conGeom1_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_28.SplineDefiningPointIndex = 0
    conGeom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    edge12 = extrude1.FindObject("EDGE * 140 * 150 {(0,0,40)(0,0,20)(0,0,0) EXTRUDE(2)}")
    conGeom2_28.Geometry = edge12
    conGeom2_28.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_28.SplineDefiningPointIndex = 0
    help5 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help5.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help5.Point.X = 0.0
    help5.Point.Y = -2.2413700126928761e-45
    help5.Point.Z = 20.0
    help5.Parameter = 0.0
    sketchHelpedGeometricConstraint5 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_28, conGeom2_28, help5)
    
    conGeom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_29.Geometry = line19
    conGeom1_29.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_29.SplineDefiningPointIndex = 0
    conGeom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_29.Geometry = edge12
    conGeom2_29.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint60 = theSession.ActiveSketch.CreateMidpointConstraint(conGeom1_29, conGeom2_29)
    
    conGeom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_30.Geometry = line19
    conGeom1_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_30.SplineDefiningPointIndex = 0
    geom1Help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom1Help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom1Help4.Point.X = -1.4210854715202004e-14
    geom1Help4.Point.Y = 0.0
    geom1Help4.Point.Z = 40.0
    geom1Help4.Parameter = 0.0
    conGeom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    edge13 = extrude1.FindObject("EDGE * 130 * 170 {(100,100,40)(50,100,40)(-0,100,40) EXTRUDE(2)}")
    conGeom2_30.Geometry = edge13
    conGeom2_30.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_30.SplineDefiningPointIndex = 0
    geom2Help4 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    geom2Help4.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    geom2Help4.Point.X = -1.4210854715202004e-14
    geom2Help4.Point.Y = 0.0
    geom2Help4.Point.Z = 40.0
    geom2Help4.Parameter = 0.0
    try:
        # Invalid object type
        sketchGeometricConstraint61 = theSession.ActiveSketch.CreateNormalConstraint(conGeom1_30, geom1Help4, conGeom2_30, geom2Help4)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(875033)
        
    dimObject1_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_12.Geometry = line19
    dimObject1_12.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_12.AssocValue = 0
    dimObject1_12.HelpPoint.X = 0.0
    dimObject1_12.HelpPoint.Y = 0.0
    dimObject1_12.HelpPoint.Z = 0.0
    dimObject1_12.View = NXOpen.NXObject.Null
    dimObject2_11 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_11.Geometry = line19
    dimObject2_11.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_11.AssocValue = 0
    dimObject2_11.HelpPoint.X = 0.0
    dimObject2_11.HelpPoint.Y = 0.0
    dimObject2_11.HelpPoint.Z = 0.0
    dimObject2_11.View = NXOpen.NXObject.Null
    dimOrigin12 = NXOpen.Point3d(-5.1375255657578149, -2.2413700126928761e-45, 30.000000000000011)
    sketchDimensionalConstraint12 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_12, dimObject2_11, dimOrigin12, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint10 = sketchDimensionalConstraint12
    dimension12 = sketchHelpedDimensionalConstraint10.AssociatedDimension
    
    expression67 = sketchHelpedDimensionalConstraint10.AssociatedExpression
    
    dimObject1_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_13.Geometry = line20
    dimObject1_13.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_13.AssocValue = 0
    dimObject1_13.HelpPoint.X = 0.0
    dimObject1_13.HelpPoint.Y = 0.0
    dimObject1_13.HelpPoint.Z = 0.0
    dimObject1_13.View = NXOpen.NXObject.Null
    dimObject2_12 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_12.Geometry = line20
    dimObject2_12.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_12.AssocValue = 0
    dimObject2_12.HelpPoint.X = 0.0
    dimObject2_12.HelpPoint.Y = 0.0
    dimObject2_12.HelpPoint.Z = 0.0
    dimObject2_12.View = NXOpen.NXObject.Null
    dimOrigin13 = NXOpen.Point3d(21.544348739189594, -2.2413700126928761e-45, 14.862474434242127)
    sketchDimensionalConstraint13 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_13, dimObject2_12, dimOrigin13, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint11 = sketchDimensionalConstraint13
    dimension13 = sketchHelpedDimensionalConstraint11.AssociatedDimension
    
    expression68 = sketchHelpedDimensionalConstraint11.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms9 = [NXOpen.SmartObject.Null] * 4 
    geoms9[0] = line19
    geoms9[1] = line20
    geoms9[2] = line21
    geoms9[3] = line22
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms9)
    
    geoms10 = [NXOpen.SmartObject.Null] * 4 
    geoms10[0] = line19
    geoms10[1] = line20
    geoms10[2] = line21
    geoms10[3] = line22
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms10)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId114 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId115 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId115, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint22 = NXOpen.Point3d(86.737447672825638, -2.2413700126928761e-45, 40.0)
    endPoint22 = NXOpen.Point3d(99.999999999994145, -2.2413700126928761e-45, 19.999999999999982)
    line23 = workPart.Curves.CreateLine(startPoint22, endPoint22)
    
    theSession.ActiveSketch.AddGeometry(line23, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_31.Geometry = line23
    conGeom1_31.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_31.SplineDefiningPointIndex = 0
    conGeom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_31.Geometry = edge11
    conGeom2_31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_31.SplineDefiningPointIndex = 0
    help6 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help6.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help6.Point.X = 86.737447672825638
    help6.Point.Y = -2.2413700126928761e-45
    help6.Point.Z = 40.0
    help6.Parameter = 0.0
    sketchHelpedGeometricConstraint6 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_31, conGeom2_31, help6)
    
    geom1_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_27.Geometry = line23
    geom1_27.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_27.SplineDefiningPointIndex = 0
    geom2_27 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_27.Geometry = edge5
    geom2_27.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_27.SplineDefiningPointIndex = 0
    sketchGeometricConstraint62 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_27, geom2_27)
    
    dimObject1_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_14.Geometry = line23
    dimObject1_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_14.AssocValue = 0
    dimObject1_14.HelpPoint.X = 0.0
    dimObject1_14.HelpPoint.Y = 0.0
    dimObject1_14.HelpPoint.Z = 0.0
    dimObject1_14.View = NXOpen.NXObject.Null
    dimObject2_13 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_13.Geometry = line23
    dimObject2_13.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_13.AssocValue = 0
    dimObject2_13.HelpPoint.X = 0.0
    dimObject2_13.HelpPoint.Y = 0.0
    dimObject2_13.HelpPoint.Z = 0.0
    dimObject2_13.View = NXOpen.NXObject.Null
    dimOrigin14 = NXOpen.Point3d(89.087063351985222, -2.2413700126928761e-45, 27.16071268890741)
    sketchDimensionalConstraint14 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_14, dimObject2_13, dimOrigin14, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint12 = sketchDimensionalConstraint14
    dimension14 = sketchHelpedDimensionalConstraint12.AssociatedDimension
    
    expression69 = sketchHelpedDimensionalConstraint12.AssociatedExpression
    
    dimObject1_15 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis2 = workPart.Datums.FindObject("SKETCH(9:1B) X axis")
    dimObject1_15.Geometry = datumAxis2
    dimObject1_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_15.AssocValue = 0
    dimObject1_15.HelpPoint.X = 28.574999999999996
    dimObject1_15.HelpPoint.Y = -4.1568975742960183e-14
    dimObject1_15.HelpPoint.Z = 0.0
    dimObject1_15.View = NXOpen.NXObject.Null
    dimObject2_14 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_14.Geometry = line23
    dimObject2_14.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject2_14.AssocValue = 0
    dimObject2_14.HelpPoint.X = 86.737447672825638
    dimObject2_14.HelpPoint.Y = -2.2413700126928761e-45
    dimObject2_14.HelpPoint.Z = 40.0
    dimObject2_14.View = NXOpen.NXObject.Null
    dimOrigin15 = NXOpen.Point3d(127.04180552120287, -2.0957594812015843e-13, 25.671004207698527)
    sketchDimensionalConstraint15 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_15, dimObject2_14, dimOrigin15, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension15 = sketchDimensionalConstraint15.AssociatedDimension
    
    expression70 = sketchDimensionalConstraint15.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId116 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId116, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint23 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    endPoint23 = NXOpen.Point3d(87.190548885916797, -2.2413700126928761e-45, 40.000000000000014)
    line24 = workPart.Curves.CreateLine(startPoint23, endPoint23)
    
    theSession.ActiveSketch.AddGeometry(line24, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_28.Geometry = line24
    geom1_28.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_28.SplineDefiningPointIndex = 0
    geom2_28 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_28.Geometry = edge11
    geom2_28.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_28.SplineDefiningPointIndex = 0
    sketchGeometricConstraint63 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_28, geom2_28)
    
    geom21 = NXOpen.Sketch.ConstraintGeometry()
    
    geom21.Geometry = line24
    geom21.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom21.SplineDefiningPointIndex = 0
    sketchGeometricConstraint64 = theSession.ActiveSketch.CreateHorizontalConstraint(geom21)
    
    conGeom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_32.Geometry = line24
    conGeom1_32.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    conGeom1_32.SplineDefiningPointIndex = 0
    conGeom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_32.Geometry = edge11
    conGeom2_32.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_32.SplineDefiningPointIndex = 0
    help7 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help7.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help7.Point.X = 87.190548885916797
    help7.Point.Y = -2.2413700126928761e-45
    help7.Point.Z = 40.0
    help7.Parameter = 0.0
    sketchHelpedGeometricConstraint7 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_32, conGeom2_32, help7)
    
    dimObject1_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_16.Geometry = line24
    dimObject1_16.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_16.AssocValue = 0
    dimObject1_16.HelpPoint.X = 0.0
    dimObject1_16.HelpPoint.Y = 0.0
    dimObject1_16.HelpPoint.Z = 0.0
    dimObject1_16.View = NXOpen.NXObject.Null
    dimObject2_15 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_15.Geometry = line24
    dimObject2_15.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_15.AssocValue = 0
    dimObject2_15.HelpPoint.X = 0.0
    dimObject2_15.HelpPoint.Y = 0.0
    dimObject2_15.HelpPoint.Z = 0.0
    dimObject2_15.View = NXOpen.NXObject.Null
    dimOrigin16 = NXOpen.Point3d(93.595274442955485, -2.2413700126928761e-45, 45.137525565757805)
    sketchDimensionalConstraint16 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_16, dimObject2_15, dimOrigin16, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint13 = sketchDimensionalConstraint16
    dimension16 = sketchHelpedDimensionalConstraint13.AssociatedDimension
    
    expression71 = sketchHelpedDimensionalConstraint13.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId117 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId117, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint24 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    endPoint24 = NXOpen.Point3d(99.999999999994131, -2.2413700126928761e-45, 19.999999999999982)
    line25 = workPart.Curves.CreateLine(startPoint24, endPoint24)
    
    theSession.ActiveSketch.AddGeometry(line25, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_29.Geometry = line25
    geom1_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_29.SplineDefiningPointIndex = 0
    geom2_29 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_29.Geometry = line24
    geom2_29.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_29.SplineDefiningPointIndex = 0
    sketchGeometricConstraint65 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_29, geom2_29)
    
    geom22 = NXOpen.Sketch.ConstraintGeometry()
    
    geom22.Geometry = line25
    geom22.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom22.SplineDefiningPointIndex = 0
    sketchGeometricConstraint66 = theSession.ActiveSketch.CreateVerticalConstraint(geom22)
    
    geom1_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_30.Geometry = line25
    geom1_30.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_30.SplineDefiningPointIndex = 0
    geom2_30 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_30.Geometry = line23
    geom2_30.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_30.SplineDefiningPointIndex = 0
    sketchGeometricConstraint67 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_30, geom2_30)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId118 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder8 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin16 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal16 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane17 = workPart.Planes.CreatePlane(origin16, normal16, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.PlaneReference = plane17
    
    expression72 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression73 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder7 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder7.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId118, "Create Sketch Dialog")
    
    coordinates6 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point24 = workPart.Points.CreatePoint(coordinates6)
    
    origin17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector1 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    direction13 = workPart.Directions.CreateDirection(origin17, vector1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin18 = NXOpen.Point3d(0.0, 0.0, 0.0)
    vector2 = NXOpen.Vector3d(1.0, 0.0, 0.0)
    direction14 = workPart.Directions.CreateDirection(origin18, vector2, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    origin19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    matrix1 = NXOpen.Matrix3x3()
    
    matrix1.Xx = 1.0
    matrix1.Xy = 0.0
    matrix1.Xz = 0.0
    matrix1.Yx = 0.0
    matrix1.Yy = 1.0
    matrix1.Yz = 0.0
    matrix1.Zx = 0.0
    matrix1.Zy = 0.0
    matrix1.Zz = 1.0
    plane18 = workPart.Planes.CreateFixedTypePlane(origin19, matrix1, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform5 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane18, direction14, point24, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem5 = workPart.CoordinateSystems.CreateCoordinateSystem(xform5, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder8.Csystem = cartesianCoordinateSystem5
    
    origin20 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal17 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19 = workPart.Planes.CreatePlane(origin20, normal17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression74 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression75 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane19.SynchronizeToPlane(plane18)
    
    expression76 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    origin21 = plane19.Origin
    
    normal18 = plane19.Normal
    
    plane19.SetMethod(NXOpen.PlaneTypes.MethodType.Fixed)
    
    geom23 = []
    plane19.SetGeometry(geom23)
    
    origin22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    plane19.Origin = origin22
    
    normal19 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane19.Normal = normal19
    
    plane19.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane19.Evaluate()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId119 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId119, None)
    
    markId120 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    markId121 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject19 = sketchInPlaceBuilder8.Commit()
    
    sketch8 = nXObject19
    feature12 = sketch8.Feature
    
    markId122 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs9 = theSession.UpdateManager.DoUpdate(markId122)
    
    sketch8.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId120, None)
    
    theSession.SetUndoMarkName(markId118, "Create Sketch")
    
    sketchInPlaceBuilder8.Destroy()
    
    sketchAlongPathBuilder7.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression73)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression72)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane17.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression75)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression74)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane19.DestroyPlane()
    
    workPart.Expressions.Delete(expression76)
    
    markId123 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder3 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines13 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines13)
    
    lines14 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines14)
    
    lines15 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines15)
    
    lines16 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines16)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder3.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines17 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBefore(lines17)
    
    lines18 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAfter(lines18)
    
    lines19 = []
    sketchRapidDimensionBuilder3.AppendedText.SetAbove(lines19)
    
    lines20 = []
    sketchRapidDimensionBuilder3.AppendedText.SetBelow(lines20)
    
    theSession.SetUndoMarkName(markId123, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder3.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits95 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits96 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits97 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits98 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits99 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits100 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits101 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits102 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits103 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits104 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder3.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder3.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder3.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits105 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits106 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits107 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits108 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits109 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits110 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits111 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits112 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits113 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits114 = sketchRapidDimensionBuilder3.Style.UnitsStyle.DimensionLinearUnits
    
    rotMatrix11 = NXOpen.Matrix3x3()
    
    rotMatrix11.Xx = 1.0
    rotMatrix11.Xy = 0.0
    rotMatrix11.Xz = 0.0
    rotMatrix11.Yx = 0.0
    rotMatrix11.Yy = 0.051951480901893957
    rotMatrix11.Yz = 0.99864961003952835
    rotMatrix11.Zx = 0.0
    rotMatrix11.Zy = -0.99864961003952835
    rotMatrix11.Zz = 0.051951480901893957
    translation11 = NXOpen.Point3d(0.0, -19.972992200790763, 18.960970381961932)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix11, translation11, 1.7518160999501484)
    
    sketchRapidDimensionBuilder3.Destroy()
    
    theSession.UndoToMark(markId123, None)
    
    theSession.DeleteUndoMark(markId123, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Settings...
    # ----------------------------------------------
    markId124 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId124, "Sketch Settings Dialog")
    
    scaleAboutPoint155 = NXOpen.Point3d(-0.9062024261820717, 3.9268771801229998, 0.0)
    viewCenter155 = NXOpen.Point3d(0.90620242618245805, -3.926877180123399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint155, viewCenter155)
    
    scaleAboutPoint156 = NXOpen.Point3d(-5.4749729915177765, 4.9085964751538294, 0.0)
    viewCenter156 = NXOpen.Point3d(5.4749729915180989, -4.9085964751541997, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint156, viewCenter156)
    
    rotMatrix12 = NXOpen.Matrix3x3()
    
    rotMatrix12.Xx = 0.99674280026362072
    rotMatrix12.Xy = -0.080639736161246825
    rotMatrix12.Xz = 0.0010114714429513409
    rotMatrix12.Yx = 0.0013210329822371223
    rotMatrix12.Yy = 0.028866403623351834
    rotMatrix12.Yz = 0.9995824056143231
    rotMatrix12.Zx = -0.080635259003088822
    rotMatrix12.Zy = -0.99632522987913053
    rotMatrix12.Zz = 0.028878907732227309
    translation12 = NXOpen.Point3d(2.7142298505060047, -16.749291881796296, 26.677708038347721)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix12, translation12, 1.1211623039680951)
    
    scaleAboutPoint157 = NXOpen.Point3d(100.29584143944493, 12.743471618188096, 0.0)
    viewCenter157 = NXOpen.Point3d(-100.29584143944457, -12.743471618188439, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint157, viewCenter157)
    
    scaleAboutPoint158 = NXOpen.Point3d(128.31967948870147, 14.454400678037455, 0.0)
    viewCenter158 = NXOpen.Point3d(-128.31967948870121, -14.454400678037809, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint158, viewCenter158)
    
    scaleAboutPoint159 = NXOpen.Point3d(162.24327291674888, 17.699266136372444, 0.0)
    viewCenter159 = NXOpen.Point3d(-162.24327291674857, -17.699266136372788, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint159, viewCenter159)
    
    scaleAboutPoint160 = NXOpen.Point3d(207.41327503561664, 22.124082670465558, 0.0)
    viewCenter160 = NXOpen.Point3d(-207.41327503561641, -22.12408267046591, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint160, viewCenter160)
    
    scaleAboutPoint161 = NXOpen.Point3d(279.43177331187223, 28.231251324292057, 0.0)
    viewCenter161 = NXOpen.Point3d(-279.43177331187195, -28.231251324292401, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint161, viewCenter161)
    
    scaleAboutPoint162 = NXOpen.Point3d(223.54541864949778, 22.585001059433608, 0.0)
    viewCenter162 = NXOpen.Point3d(-223.54541864949755, -22.58500105943396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint162, viewCenter162)
    
    scaleAboutPoint163 = NXOpen.Point3d(178.83633491959833, 18.068000847546887, 0.0)
    viewCenter163 = NXOpen.Point3d(-178.83633491959796, -18.068000847547232, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint163, viewCenter163)
    
    scaleAboutPoint164 = NXOpen.Point3d(143.0690679356787, 14.454400678037459, 0.0)
    viewCenter164 = NXOpen.Point3d(-143.06906793567833, -14.454400678037837, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint164, viewCenter164)
    
    scaleAboutPoint165 = NXOpen.Point3d(114.45525434854299, 11.563520542429927, 0.0)
    viewCenter165 = NXOpen.Point3d(-114.45525434854271, -11.56352054243029, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint165, viewCenter165)
    
    scaleAboutPoint166 = NXOpen.Point3d(73.440154955188888, 7.5516868848521401, 0.0)
    viewCenter166 = NXOpen.Point3d(-73.440154955188532, -7.5516868848525105, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint166, viewCenter166)
    
    scaleAboutPoint167 = NXOpen.Point3d(58.752123964151131, 6.0413495078816597, 0.0)
    viewCenter167 = NXOpen.Point3d(-58.752123964150798, -6.0413495078820336, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint167, viewCenter167)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    theSession.UndoToMark(markId124, None)
    
    theSession.DeleteUndoMark(markId124, None)
    
    markId125 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder4 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines21 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines21)
    
    lines22 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines22)
    
    lines23 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines23)
    
    lines24 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines24)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder4.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines25 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBefore(lines25)
    
    lines26 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAfter(lines26)
    
    lines27 = []
    sketchRapidDimensionBuilder4.AppendedText.SetAbove(lines27)
    
    lines28 = []
    sketchRapidDimensionBuilder4.AppendedText.SetBelow(lines28)
    
    theSession.SetUndoMarkName(markId125, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder4.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits115 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits116 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits117 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits118 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits119 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits120 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits121 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits122 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits123 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits124 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder4.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder4.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder4.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits125 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits126 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits127 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits128 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits129 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits130 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits131 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits132 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits133 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits134 = sketchRapidDimensionBuilder4.Style.UnitsStyle.DimensionLinearUnits
    
    point1_22 = NXOpen.Point3d(-1.9600538592723535e-14, -2.2413700126928761e-45, 30.0)
    point2_22 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder4.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Mid, line19, workPart.ModelingViews.WorkView, point1_22, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_22)
    
    sketchRapidDimensionBuilder4.Destroy()
    
    theSession.UndoToMark(markId125, None)
    
    theSession.DeleteUndoMark(markId125, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Settings...
    # ----------------------------------------------
    markId126 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    theSession.SetUndoMarkName(markId126, "Sketch Settings Dialog")
    
    theSession.UndoToMark(markId126, None)
    
    theSession.DeleteUndoMark(markId126, None)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled1, undoUnavailable1 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled2, undoUnavailable2 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled3, undoUnavailable3 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Edit->Undo
    # ----------------------------------------------
    marksRecycled4, undoUnavailable4 = theSession.UndoLastNVisibleMarks(1)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Line...
    # ----------------------------------------------
    markId127 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId128 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId128, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint25 = NXOpen.Point3d(83.399646231019474, -2.2413700126928761e-45, 40.0)
    endPoint25 = NXOpen.Point3d(99.999999999994145, -2.2413700126928761e-45, 19.999999999999968)
    line26 = workPart.Curves.CreateLine(startPoint25, endPoint25)
    
    theSession.ActiveSketch.AddGeometry(line26, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_33.Geometry = line26
    conGeom1_33.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    conGeom1_33.SplineDefiningPointIndex = 0
    conGeom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_33.Geometry = edge11
    conGeom2_33.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_33.SplineDefiningPointIndex = 0
    help8 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help8.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help8.Point.X = 83.399646231019474
    help8.Point.Y = -2.2413700126928761e-45
    help8.Point.Z = 40.0
    help8.Parameter = 0.0
    sketchHelpedGeometricConstraint8 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_33, conGeom2_33, help8)
    
    geom1_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_31.Geometry = line26
    geom1_31.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_31.SplineDefiningPointIndex = 0
    geom2_31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_31.Geometry = edge5
    geom2_31.PointType = NXOpen.Sketch.ConstraintPointType.MidVertex
    geom2_31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint68 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_31, geom2_31)
    
    dimObject1_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_17.Geometry = line26
    dimObject1_17.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_17.AssocValue = 0
    dimObject1_17.HelpPoint.X = 0.0
    dimObject1_17.HelpPoint.Y = 0.0
    dimObject1_17.HelpPoint.Z = 0.0
    dimObject1_17.View = NXOpen.NXObject.Null
    dimObject2_16 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_16.Geometry = line26
    dimObject2_16.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_16.AssocValue = 0
    dimObject2_16.HelpPoint.X = 0.0
    dimObject2_16.HelpPoint.Y = 0.0
    dimObject2_16.HelpPoint.Z = 0.0
    dimObject2_16.View = NXOpen.NXObject.Null
    dimOrigin17 = NXOpen.Point3d(88.537267002382436, -2.2413700126928761e-45, 27.375022485395093)
    sketchDimensionalConstraint17 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_17, dimObject2_16, dimOrigin17, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint14 = sketchDimensionalConstraint17
    dimension17 = sketchHelpedDimensionalConstraint14.AssociatedDimension
    
    expression77 = sketchHelpedDimensionalConstraint14.AssociatedExpression
    
    dimObject1_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_18.Geometry = datumAxis2
    dimObject1_18.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_18.AssocValue = 0
    dimObject1_18.HelpPoint.X = 28.574999999999996
    dimObject1_18.HelpPoint.Y = -4.1568975742960183e-14
    dimObject1_18.HelpPoint.Z = 0.0
    dimObject1_18.View = NXOpen.NXObject.Null
    dimObject2_17 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_17.Geometry = line26
    dimObject2_17.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject2_17.AssocValue = 0
    dimObject2_17.HelpPoint.X = 83.399646231019474
    dimObject2_17.HelpPoint.Y = -2.2413700126928761e-45
    dimObject2_17.HelpPoint.Z = 40.0
    dimObject2_17.View = NXOpen.NXObject.Null
    dimOrigin18 = NXOpen.Point3d(129.3948957504887, -2.2113482242785437e-13, 27.247331321436565)
    sketchDimensionalConstraint18 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_18, dimObject2_17, dimOrigin18, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension18 = sketchDimensionalConstraint18.AssociatedDimension
    
    expression78 = sketchDimensionalConstraint18.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId129 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId129, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint26 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    endPoint26 = NXOpen.Point3d(99.999999999994131, -2.2413700126928761e-45, 19.999999999999968)
    line27 = workPart.Curves.CreateLine(startPoint26, endPoint26)
    
    theSession.ActiveSketch.AddGeometry(line27, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_32.Geometry = line27
    geom1_32.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_32.SplineDefiningPointIndex = 0
    geom2_32 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_32.Geometry = edge5
    geom2_32.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_32.SplineDefiningPointIndex = 0
    sketchGeometricConstraint69 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_32, geom2_32)
    
    geom24 = NXOpen.Sketch.ConstraintGeometry()
    
    geom24.Geometry = line27
    geom24.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom24.SplineDefiningPointIndex = 0
    sketchGeometricConstraint70 = theSession.ActiveSketch.CreateVerticalConstraint(geom24)
    
    geom1_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_33.Geometry = line27
    geom1_33.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_33.SplineDefiningPointIndex = 0
    geom2_33 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_33.Geometry = line26
    geom2_33.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom2_33.SplineDefiningPointIndex = 0
    sketchGeometricConstraint71 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_33, geom2_33)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    markId130 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId130, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    startPoint27 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    endPoint27 = NXOpen.Point3d(83.399646231019474, -2.2413700126928761e-45, 40.000000000000014)
    line28 = workPart.Curves.CreateLine(startPoint27, endPoint27)
    
    theSession.ActiveSketch.AddGeometry(line28, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_34.Geometry = line28
    geom1_34.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom1_34.SplineDefiningPointIndex = 0
    geom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_34.Geometry = line27
    geom2_34.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_34.SplineDefiningPointIndex = 0
    sketchGeometricConstraint72 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_34, geom2_34)
    
    geom25 = NXOpen.Sketch.ConstraintGeometry()
    
    geom25.Geometry = line28
    geom25.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom25.SplineDefiningPointIndex = 0
    sketchGeometricConstraint73 = theSession.ActiveSketch.CreateHorizontalConstraint(geom25)
    
    geom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_35.Geometry = line28
    geom1_35.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_35.SplineDefiningPointIndex = 0
    geom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_35.Geometry = line26
    geom2_35.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_35.SplineDefiningPointIndex = 0
    sketchGeometricConstraint74 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_35, geom2_35)
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    # ----------------------------------------------
    #   Dialog Begin Line
    # ----------------------------------------------
    rotMatrix13 = NXOpen.Matrix3x3()
    
    rotMatrix13.Xx = 0.9999824717307535
    rotMatrix13.Xy = -0.0056884132589045209
    rotMatrix13.Xz = 0.0016426155508260411
    rotMatrix13.Yx = -0.0018707738335209268
    rotMatrix13.Yy = -0.04033908366786064
    rotMatrix13.Yz = 0.99918429658101848
    rotMatrix13.Zx = -0.0056175115946217307
    rotMatrix13.Zy = -0.99916985557183291
    rotMatrix13.Zz = -0.040349018328220208
    translation13 = NXOpen.Point3d(-66.698130638353305, -17.366301510665956, 22.839245802254499)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix13, translation13, 2.1897701249376862)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId131 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder5 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines29 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines29)
    
    lines30 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines30)
    
    lines31 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines31)
    
    lines32 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines32)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder5.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines33 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBefore(lines33)
    
    lines34 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAfter(lines34)
    
    lines35 = []
    sketchRapidDimensionBuilder5.AppendedText.SetAbove(lines35)
    
    lines36 = []
    sketchRapidDimensionBuilder5.AppendedText.SetBelow(lines36)
    
    theSession.SetUndoMarkName(markId131, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder5.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits135 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits136 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits137 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits138 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits139 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits140 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits141 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits142 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits143 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits144 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder5.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits145 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits146 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits147 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits148 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits149 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits150 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits151 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits152 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits153 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits154 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    point25 = NXOpen.Point3d(99.999999999994088, 1.0880185641326534e-14, 34.135501111207681)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(line27, workPart.ModelingViews.WorkView, point25)
    
    point1_23 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    point2_23 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line27, workPart.ModelingViews.WorkView, point1_23, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_23)
    
    point1_24 = NXOpen.Point3d(99.999999999994131, -2.2413700126928761e-45, 19.999999999999968)
    point2_24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder5.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line27, workPart.ModelingViews.WorkView, point1_24, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_24)
    
    dimensionlinearunits155 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits156 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits157 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits158 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits159 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits160 = sketchRapidDimensionBuilder5.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin2 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin2.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin2.View = NXOpen.View.Null
    assocOrigin2.ViewOfGeometry = workPart.ModelingViews.WorkView
    point26 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin2.PointOnGeometry = point26
    assocOrigin2.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.DimensionLine = 0
    assocOrigin2.AssociatedView = NXOpen.View.Null
    assocOrigin2.AssociatedPoint = NXOpen.Point.Null
    assocOrigin2.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin2.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin2.XOffsetFactor = 0.0
    assocOrigin2.YOffsetFactor = 0.0
    assocOrigin2.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder5.Origin.SetAssociativeOrigin(assocOrigin2)
    
    point27 = NXOpen.Point3d(108.69411541258431, 0.0, 32.699690636794152)
    sketchRapidDimensionBuilder5.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point27)
    
    sketchRapidDimensionBuilder5.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder5.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder5.Style.DimensionStyle.TextCentered = False
    
    markId132 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject20 = sketchRapidDimensionBuilder5.Commit()
    
    theSession.DeleteUndoMark(markId132, None)
    
    theSession.SetUndoMarkName(markId131, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId131, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder5.Destroy()
    
    markId133 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder6 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines37 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBefore(lines37)
    
    lines38 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAfter(lines38)
    
    lines39 = []
    sketchRapidDimensionBuilder6.AppendedText.SetAbove(lines39)
    
    lines40 = []
    sketchRapidDimensionBuilder6.AppendedText.SetBelow(lines40)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder6.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId133, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder6.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits161 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits162 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits163 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits164 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits165 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits166 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits167 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits168 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits169 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits170 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder6.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits171 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits172 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits173 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits174 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits175 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits176 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits177 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits178 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits179 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits180 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    point28 = NXOpen.Point3d(94.907737222577282, 1.1546319456101628e-14, 40.000000000000149)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(line28, workPart.ModelingViews.WorkView, point28)
    
    point1_25 = NXOpen.Point3d(99.999999999994174, -2.2413700126928761e-45, 40.0)
    point2_25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line28, workPart.ModelingViews.WorkView, point1_25, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_25)
    
    point1_26 = NXOpen.Point3d(83.399646231019474, -2.2413700126928761e-45, 40.000000000000014)
    point2_26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder6.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line28, workPart.ModelingViews.WorkView, point1_26, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_26)
    
    dimensionlinearunits181 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits182 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits183 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits184 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits185 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits186 = sketchRapidDimensionBuilder6.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin3 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin3.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin3.View = NXOpen.View.Null
    assocOrigin3.ViewOfGeometry = workPart.ModelingViews.WorkView
    point29 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin3.PointOnGeometry = point29
    assocOrigin3.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.DimensionLine = 0
    assocOrigin3.AssociatedView = NXOpen.View.Null
    assocOrigin3.AssociatedPoint = NXOpen.Point.Null
    assocOrigin3.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin3.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin3.XOffsetFactor = 0.0
    assocOrigin3.YOffsetFactor = 0.0
    assocOrigin3.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder6.Origin.SetAssociativeOrigin(assocOrigin3)
    
    point30 = NXOpen.Point3d(95.142029120348568, 0.0, 44.404103122941969)
    sketchRapidDimensionBuilder6.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point30)
    
    sketchRapidDimensionBuilder6.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder6.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder6.Style.DimensionStyle.TextCentered = False
    
    markId134 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject21 = sketchRapidDimensionBuilder6.Commit()
    
    theSession.DeleteUndoMark(markId134, None)
    
    theSession.SetUndoMarkName(markId133, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId133, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder6.Destroy()
    
    markId135 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder7 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines41 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBefore(lines41)
    
    lines42 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAfter(lines42)
    
    lines43 = []
    sketchRapidDimensionBuilder7.AppendedText.SetAbove(lines43)
    
    lines44 = []
    sketchRapidDimensionBuilder7.AppendedText.SetBelow(lines44)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder7.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId135, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder7.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits187 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits188 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits189 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits190 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits191 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits192 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits193 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits194 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits195 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits196 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder7.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder7.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder7.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits197 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits198 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits199 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits200 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits201 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits202 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits203 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits204 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits205 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits206 = sketchRapidDimensionBuilder7.Style.UnitsStyle.DimensionLinearUnits
    
    expression79 = workPart.Expressions.FindObject("p32")
    expression79.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId135, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId136 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId136, None)
    
    markId137 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId135, "Edit Driving Value")
    
    parallelDimension7 = dimension13
    point31 = NXOpen.Point3d(22.45479155766877, 22.094937944666786, 15.775099907153846)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(parallelDimension7, workPart.ModelingViews.WorkView, point31)
    
    point1_27 = NXOpen.Point3d(43.088697478379267, -2.2413700126928761e-45, 19.999999999999847)
    point2_27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.End, line20, NXOpen.View.Null, point1_27, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_27)
    
    point1_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder7.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_28, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_28)
    
    sketchRapidDimensionBuilder7.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    convertToFromReferenceBuilder6 = workPart.Sketches.CreateConvertToFromReferenceBuilder()
    
    selectNXObjectList6 = convertToFromReferenceBuilder6.InputObjects
    
    added6 = selectNXObjectList6.Add(parallelDimension7)
    
    convertToFromReferenceBuilder6.OutputState = NXOpen.ConvertToFromReferenceBuilder.OutputType.Active
    
    nXObject22 = convertToFromReferenceBuilder6.Commit()
    
    convertToFromReferenceBuilder6.Destroy()
    
    expression80 = workPart.Expressions.FindObject("p33")
    expression80.SetFormula("45")
    
    theSession.SetUndoMarkVisibility(markId137, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId138 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId138, None)
    
    markId139 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId137, "Edit Driving Value")
    
    rotMatrix14 = NXOpen.Matrix3x3()
    
    rotMatrix14.Xx = 0.9913772081958715
    rotMatrix14.Xy = -0.12185072156029976
    rotMatrix14.Xz = 0.048204073738568685
    rotMatrix14.Yx = -0.020882595532556354
    rotMatrix14.Yy = 0.21624966705419282
    rotMatrix14.Yz = 0.97611474668851195
    rotMatrix14.Zx = -0.12936440110626521
    rotMatrix14.Zy = -0.96870453862578199
    rotMatrix14.Zz = 0.21184043186377832
    translation14 = NXOpen.Point3d(-60.227327206710882, -30.443131499245442, 25.173545181008134)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix14, translation14, 2.1897701249376862)
    
    scaleAboutPoint168 = NXOpen.Point3d(-33.227422293350003, 37.456366948867284, 0.0)
    viewCenter168 = NXOpen.Point3d(33.227422293350344, -37.456366948867654, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint168, viewCenter168)
    
    rotMatrix15 = NXOpen.Matrix3x3()
    
    rotMatrix15.Xx = 0.97718693204542562
    rotMatrix15.Xy = 0.21238061831927307
    rotMatrix15.Xz = 0.00041569456607659004
    rotMatrix15.Yx = -0.0077625926546176323
    rotMatrix15.Yy = 0.033760420739519847
    rotMatrix15.Yz = 0.99939980795814265
    rotMatrix15.Zx = 0.21223911513886232
    rotMatrix15.Zy = -0.97660365909299074
    rotMatrix15.Zz = 0.034638866194762322
    translation15 = NXOpen.Point3d(-78.363476089445697, -24.677935618628819, 8.3390810301344054)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix15, translation15, 2.7372126561721077)
    
    scaleAboutPoint169 = NXOpen.Point3d(-22.232166189005046, 21.0722270834917, 0.0)
    viewCenter169 = NXOpen.Point3d(22.23216618900539, -21.072227083492074, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint169, viewCenter169)
    
    scaleAboutPoint170 = NXOpen.Point3d(-27.790207736256338, 26.098629874049394, 0.0)
    viewCenter170 = NXOpen.Point3d(27.790207736256686, -26.098629874049774, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint170, viewCenter170)
    
    scaleAboutPoint171 = NXOpen.Point3d(-34.737759670320457, 32.472253604864747, 0.0)
    viewCenter171 = NXOpen.Point3d(34.73775967032082, -32.472253604865116, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint171, viewCenter171)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    sketchRapidDimensionBuilder7.Destroy()
    
    theSession.UndoToMark(markId139, None)
    
    theSession.DeleteUndoMark(markId139, None)
    
    sketchRapidDimensionBuilder7.Destroy()
    
    markId140 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder5 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section5 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder5.Section = section5
    
    extrudeBuilder5.AllowSelfIntersectingSection(True)
    
    expression81 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder5.DistanceTolerance = 0.01
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies11 = [NXOpen.Body.Null] * 1 
    targetBodies11[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies11)
    
    extrudeBuilder5.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder5.Limits.EndExtend.Value.SetFormula("50")
    
    extrudeBuilder5.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies12 = [NXOpen.Body.Null] * 1 
    targetBodies12[0] = NXOpen.Body.Null
    extrudeBuilder5.BooleanOperation.SetTargetBodies(targetBodies12)
    
    extrudeBuilder5.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder5.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder5.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder5 = extrudeBuilder5.SmartVolumeProfile
    
    smartVolumeProfileBuilder5.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder5.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId140, "Extrude Dialog")
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    section5.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId141 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves6 = [NXOpen.ICurve.Null] * 7 
    curves6[0] = line28
    curves6[1] = line21
    curves6[2] = line19
    curves6[3] = line27
    curves6[4] = line22
    curves6[5] = line20
    curves6[6] = line26
    seedPoint6 = NXOpen.Point3d(96.666666666660831, -2.2413700126928761e-45, 33.333333333333329)
    regionBoundaryRule6 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves6, seedPoint6, 0.01)
    
    curves7 = [NXOpen.ICurve.Null] * 7 
    curves7[0] = line28
    curves7[1] = line21
    curves7[2] = line19
    curves7[3] = line27
    curves7[4] = line22
    curves7[5] = line20
    curves7[6] = line26
    seedPoint7 = NXOpen.Point3d(15.0, -2.2413700126928761e-45, 33.333333333333336)
    regionBoundaryRule7 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves7, seedPoint7, 0.01)
    
    section5.AllowSelfIntersection(True)
    
    rules7 = [None] * 2 
    rules7[0] = regionBoundaryRule6
    rules7[1] = regionBoundaryRule7
    helpPoint7 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section5.AddToSection(rules7, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint7, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId141, None)
    
    markId142 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId143 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId143, None)
    
    direction15 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder5.Direction = direction15
    
    expression82 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression83 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId142, None)
    
    markId144 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId145 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    facesOfFeatures1 = [NXOpen.Face.Null] * 1 
    facesOfFeatures1[0] = face4
    edgeBoundaryRule1 = workPart.ScRuleFactory.CreateRuleEdgeBoundary(facesOfFeatures1)
    
    section5.AllowSelfIntersection(True)
    
    rules8 = [None] * 1 
    rules8[0] = edgeBoundaryRule1
    helpPoint8 = NXOpen.Point3d(31.151991856802397, 2.2737367544323206e-10, 34.292346873677104)
    section5.AddToSection(rules8, face4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint8, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId145, None)
    
    workPart.Expressions.Delete(expression82)
    
    workPart.Expressions.Delete(expression83)
    
    expression84 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId144, None)
    
    markId146 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId147 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    facesOfFeatures2 = [NXOpen.Face.Null] * 1 
    face5 = extrude1.FindObject("FACE 170 {(50,100,20) EXTRUDE(2)}")
    facesOfFeatures2[0] = face5
    edgeBoundaryRule2 = workPart.ScRuleFactory.CreateRuleEdgeBoundary(facesOfFeatures2)
    
    section5.AllowSelfIntersection(True)
    
    rules9 = [None] * 1 
    rules9[0] = edgeBoundaryRule2
    helpPoint9 = NXOpen.Point3d(52.313338584554003, 99.999999999909051, 22.76679859870967)
    section5.AddToSection(rules9, face5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint9, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId147, None)
    
    extrudeBuilder5.Draft.DraftOption = NXOpen.GeometricUtilities.SimpleDraft.SimpleDraftType.NoDraft
    
    workPart.Expressions.Delete(expression84)
    
    expression85 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression86 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId146, None)
    
    markId148 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId149 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section5.Clear()
    
    theSession.DeleteUndoMark(markId149, None)
    
    workPart.Expressions.Delete(expression85)
    
    workPart.Expressions.Delete(expression86)
    
    theSession.DeleteUndoMark(markId148, None)
    
    markId150 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Enter Sketch")
    
    theSession.BeginTaskEnvironment()
    
    markId151 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.Model)
    
    origin23 = NXOpen.Point3d(49.999999999997087, -7.2736615473241934e-14, 20.0)
    normal20 = NXOpen.Vector3d(-1.4547323094649234e-15, -1.0, 0.0)
    geometry2 = [NXOpen.NXObject.Null] * 1 
    geometry2[0] = face4
    plane20 = workPart.Planes.CreatePlane(NXOpen.PlaneTypes.MethodType.Coincident, NXOpen.PlaneTypes.AlternateType.One, origin23, normal20, "", False, False, geometry2)
    
    plane20.Evaluate()
    
    direction16 = workPart.Directions.CreateDirection(edge10, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression87 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar12 = workPart.Scalars.CreateScalarExpression(expression87, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression88 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar13 = workPart.Scalars.CreateScalarExpression(expression88, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression89 = workPart.Expressions.CreateSystemExpression("0")
    
    scalar14 = workPart.Scalars.CreateScalarExpression(expression89, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point32 = workPart.Points.CreatePoint(scalar12, scalar13, scalar14, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder9 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    sketchInPlaceBuilder9.PlaneReference = plane20
    
    sketchInPlaceBuilder9.AxisReference = direction16
    
    sketchInPlaceBuilder9.SketchOrigin = point32
    
    sketchInPlaceBuilder9.AxisOrientation = NXOpen.AxisOrientation.Horizontal
    
    sketchInPlaceBuilder9.PlaneOption = NXOpen.Sketch.PlaneOption.ExistingPlane
    
    sketchInPlaceBuilder9.OriginOption = NXOpen.OriginMethod.SpecifyPoint
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject23 = sketchInPlaceBuilder9.Commit()
    
    sketch9 = nXObject23
    sketch9.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    markId152 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    sketchInPlaceBuilder9.Destroy()
    
    theSession.DeleteUndoMarksUpToMark(markId152, None, True)
    
    markId153 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Open Sketch")
    
    theSession.ActiveSketch.SetName("SKETCH_006")
    
    markId154 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    # ----------------------------------------------
    #   Dialog Begin Profile
    # ----------------------------------------------
    scaleAboutPoint172 = NXOpen.Point3d(-66.077260242457555, 21.295757015283328, 0.0)
    viewCenter172 = NXOpen.Point3d(66.077260242457953, -21.295757015283723, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint172, viewCenter172)
    
    scaleAboutPoint173 = NXOpen.Point3d(-82.407783130950676, 26.242111924861597, 0.0)
    viewCenter173 = NXOpen.Point3d(82.407783130951074, -26.242111924861991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint173, viewCenter173)
    
    scaleAboutPoint174 = NXOpen.Point3d(-103.00972891368839, 32.566649690925431, 0.0)
    viewCenter174 = NXOpen.Point3d(103.0097289136888, -32.566649690925821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint174, viewCenter174)
    
    scaleAboutPoint175 = NXOpen.Point3d(-128.76216114211053, 40.708312113656802, 0.0)
    viewCenter175 = NXOpen.Point3d(128.76216114211098, -40.708312113657193, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint175, viewCenter175)
    
    scaleAboutPoint176 = NXOpen.Point3d(-160.9527014276382, 50.885390142071074, 0.0)
    viewCenter176 = NXOpen.Point3d(160.95270142763863, -50.885390142071458, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint176, viewCenter176)
    
    scaleAboutPoint177 = NXOpen.Point3d(-201.19087678454778, 63.606737677588917, 0.0)
    viewCenter177 = NXOpen.Point3d(201.19087678454827, -63.606737677589237, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint177, viewCenter177)
    
    scaleAboutPoint178 = NXOpen.Point3d(-103.99471151091304, 88.726789876346842, 0.0)
    viewCenter178 = NXOpen.Point3d(103.99471151091355, -88.726789876347183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint178, viewCenter178)
    
    scaleAboutPoint179 = NXOpen.Point3d(-83.195769208730368, 70.981431901077485, 0.0)
    viewCenter179 = NXOpen.Point3d(83.195769208730852, -70.981431901077812, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint179, viewCenter179)
    
    scaleAboutPoint180 = NXOpen.Point3d(-66.556615366984232, 56.78514552086196, 0.0)
    viewCenter180 = NXOpen.Point3d(66.556615366984687, -56.78514552086228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint180, viewCenter180)
    
    scaleAboutPoint181 = NXOpen.Point3d(-53.245292293587333, 45.428116416689512, 0.0)
    viewCenter181 = NXOpen.Point3d(53.245292293587795, -45.428116416689875, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint181, viewCenter181)
    
    scaleAboutPoint182 = NXOpen.Point3d(-56.519656528816299, 36.342493133351567, 0.0)
    viewCenter182 = NXOpen.Point3d(56.519656528816725, -36.342493133351937, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint182, viewCenter182)
    
    scaleAboutPoint183 = NXOpen.Point3d(-45.215725223052985, 29.07399450668122, 0.0)
    viewCenter183 = NXOpen.Point3d(45.215725223053411, -29.073994506681583, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint183, viewCenter183)
    
    # ----------------------------------------------
    #   Menu: Task->Finish Sketch
    # ----------------------------------------------
    theSession.DeleteUndoMark(markId154, "Curve")
    
    theSession.Preferences.Sketch.SectionView = False
    
    markId155 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    theSession.ActiveSketch.Deactivate(NXOpen.Sketch.ViewReorient.TrueValue, NXOpen.Sketch.UpdateLevel.SketchOnly)
    
    theSession.DeleteUndoMarksSetInTaskEnvironment()
    
    theSession.EndTaskEnvironment()
    
    theSession.UndoToMark(markId150, None)
    
    theSession.DeleteUndoMark(markId150, None)
    
    section5.DistanceTolerance = 0.01
    
    section5.ChainingTolerance = 0.0094999999999999998
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    extrudeBuilder5.Destroy()
    
    section5.Destroy()
    
    workPart.Expressions.Delete(expression81)
    
    theSession.UndoToMark(markId140, None)
    
    theSession.DeleteUndoMark(markId140, None)
    
    markId156 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder6 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section6 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder6.Section = section6
    
    extrudeBuilder6.AllowSelfIntersectingSection(True)
    
    expression90 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder6.DistanceTolerance = 0.01
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies13 = [NXOpen.Body.Null] * 1 
    targetBodies13[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies13)
    
    extrudeBuilder6.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder6.Limits.EndExtend.Value.SetFormula("50")
    
    extrudeBuilder6.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies14 = [NXOpen.Body.Null] * 1 
    targetBodies14[0] = NXOpen.Body.Null
    extrudeBuilder6.BooleanOperation.SetTargetBodies(targetBodies14)
    
    extrudeBuilder6.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder6.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder6.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder6 = extrudeBuilder6.SmartVolumeProfile
    
    smartVolumeProfileBuilder6.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder6.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId156, "Extrude Dialog")
    
    section6.DistanceTolerance = 0.01
    
    section6.ChainingTolerance = 0.0094999999999999998
    
    section6.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId157 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves8 = [NXOpen.ICurve.Null] * 7 
    curves8[0] = line28
    curves8[1] = line21
    curves8[2] = line19
    curves8[3] = line27
    curves8[4] = line22
    curves8[5] = line20
    curves8[6] = line26
    seedPoint8 = NXOpen.Point3d(96.666666666660831, -2.2413700126928761e-45, 33.333333333333329)
    regionBoundaryRule8 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves8, seedPoint8, 0.01)
    
    curves9 = [NXOpen.ICurve.Null] * 7 
    curves9[0] = line28
    curves9[1] = line21
    curves9[2] = line19
    curves9[3] = line27
    curves9[4] = line22
    curves9[5] = line20
    curves9[6] = line26
    seedPoint9 = NXOpen.Point3d(15.0, -2.2413700126928761e-45, 33.333333333333336)
    regionBoundaryRule9 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves9, seedPoint9, 0.01)
    
    section6.AllowSelfIntersection(True)
    
    rules10 = [None] * 2 
    rules10[0] = regionBoundaryRule8
    rules10[1] = regionBoundaryRule9
    helpPoint10 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section6.AddToSection(rules10, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint10, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId157, None)
    
    markId158 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId159 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId159, None)
    
    direction17 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder6.Direction = direction17
    
    expression91 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression92 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId158, None)
    
    markId160 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId161 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    facesOfFeatures3 = [NXOpen.Face.Null] * 1 
    facesOfFeatures3[0] = face4
    edgeBoundaryRule3 = workPart.ScRuleFactory.CreateRuleEdgeBoundary(facesOfFeatures3)
    
    section6.AllowSelfIntersection(True)
    
    rules11 = [None] * 1 
    rules11[0] = edgeBoundaryRule3
    helpPoint11 = NXOpen.Point3d(42.057420238166614, 0.0, 20.665183785703917)
    section6.AddToSection(rules11, face4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint11, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId161, None)
    
    workPart.Expressions.Delete(expression91)
    
    workPart.Expressions.Delete(expression92)
    
    expression93 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId160, None)
    
    markId162 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId163 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    facesOfFeatures4 = [NXOpen.Face.Null] * 1 
    facesOfFeatures4[0] = face5
    edgeBoundaryRule4 = workPart.ScRuleFactory.CreateRuleEdgeBoundary(facesOfFeatures4)
    
    section6.AllowSelfIntersection(True)
    
    rules12 = [None] * 1 
    rules12[0] = edgeBoundaryRule4
    helpPoint12 = NXOpen.Point3d(96.741662868641299, 99.999999999909051, 25.91734268241618)
    section6.AddToSection(rules12, face5, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint12, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId163, None)
    
    extrudeBuilder6.Draft.DraftOption = NXOpen.GeometricUtilities.SimpleDraft.SimpleDraftType.NoDraft
    
    workPart.Expressions.Delete(expression93)
    
    expression94 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression95 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId162, None)
    
    extrudeBuilder6.Destroy()
    
    section6.Destroy()
    
    workPart.Expressions.Delete(expression90)
    
    workPart.Expressions.Delete(expression94)
    
    workPart.Expressions.Delete(expression95)
    
    theSession.UndoToMark(markId156, None)
    
    theSession.DeleteUndoMark(markId156, None)
    
    workPart.ModelingViews.WorkView.Fit()
    
    scaleAboutPoint184 = NXOpen.Point3d(-36.617197616597451, -37.342290638708249, 0.0)
    viewCenter184 = NXOpen.Point3d(36.617197616597451, 37.342290638708249, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint184, viewCenter184)
    
    scaleAboutPoint185 = NXOpen.Point3d(-41.239665632554036, -49.396962131300953, 0.0)
    viewCenter185 = NXOpen.Point3d(41.239665632554036, 49.396962131300953, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint185, viewCenter185)
    
    scaleAboutPoint186 = NXOpen.Point3d(-49.283666346596149, -62.312681587650289, 0.0)
    viewCenter186 = NXOpen.Point3d(49.283666346596249, 62.312681587650289, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint186, viewCenter186)
    
    scaleAboutPoint187 = NXOpen.Point3d(-60.188385624434964, -77.890851984562786, 0.0)
    viewCenter187 = NXOpen.Point3d(60.188385624434964, 77.890851984562914, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint187, viewCenter187)
    
    scaleAboutPoint188 = NXOpen.Point3d(-75.235482030543707, -97.363564980703572, 0.0)
    viewCenter188 = NXOpen.Point3d(75.235482030543707, 97.363564980703572, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint188, viewCenter188)
    
    scaleAboutPoint189 = NXOpen.Point3d(-147.1517516185634, -109.53401060329143, 0.0)
    viewCenter189 = NXOpen.Point3d(147.1517516185634, 109.53401060329162, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint189, viewCenter189)
    
    scaleAboutPoint190 = NXOpen.Point3d(-117.72140129485074, -87.627208482633151, 0.0)
    viewCenter190 = NXOpen.Point3d(117.72140129485074, 87.627208482633307, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint190, viewCenter190)
    
    scaleAboutPoint191 = NXOpen.Point3d(-94.177121035880589, -70.101766786106523, 0.0)
    viewCenter191 = NXOpen.Point3d(94.177121035880589, 70.101766786106651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint191, viewCenter191)
    
    scaleAboutPoint192 = NXOpen.Point3d(-77.607612522800864, -55.514934505361119, 0.0)
    viewCenter192 = NXOpen.Point3d(77.607612522800821, 55.514934505361261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint192, viewCenter192)
    
    scaleAboutPoint193 = NXOpen.Point3d(-225.68520313199895, -29.456904023252786, 0.0)
    viewCenter193 = NXOpen.Point3d(225.68520313199895, 29.4569040232529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint193, viewCenter193)
    
    scaleAboutPoint194 = NXOpen.Point3d(-185.26126714931965, -21.390244152269709, 0.0)
    viewCenter194 = NXOpen.Point3d(185.26126714931965, 21.390244152269833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint194, viewCenter194)
    
    scaleAboutPoint195 = NXOpen.Point3d(-148.78908813714438, -16.822158112971447, 0.0)
    viewCenter195 = NXOpen.Point3d(148.78908813714435, 16.822158112971522, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint195, viewCenter195)
    
    scaleAboutPoint196 = NXOpen.Point3d(-119.49533004386647, -13.225696723301681, 0.0)
    viewCenter196 = NXOpen.Point3d(119.49533004386639, 13.225696723301759, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint196, viewCenter196)
    
    scaleAboutPoint197 = NXOpen.Point3d(-96.52438310339501, -5.7543382234715832, 0.0)
    viewCenter197 = NXOpen.Point3d(96.52438310339501, 5.7543382234716622, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint197, viewCenter197)
    
    scaleAboutPoint198 = NXOpen.Point3d(-77.219506482716014, -4.603470578777241, 0.0)
    viewCenter198 = NXOpen.Point3d(77.219506482716014, 4.6034705787773298, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint198, viewCenter198)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId164 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder7 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section7 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder7.Section = section7
    
    extrudeBuilder7.AllowSelfIntersectingSection(True)
    
    expression96 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder7.DistanceTolerance = 0.01
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies15 = [NXOpen.Body.Null] * 1 
    targetBodies15[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies15)
    
    extrudeBuilder7.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("50")
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies16 = [NXOpen.Body.Null] * 1 
    targetBodies16[0] = NXOpen.Body.Null
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies16)
    
    extrudeBuilder7.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder7.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder7.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder7 = extrudeBuilder7.SmartVolumeProfile
    
    smartVolumeProfileBuilder7.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder7.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId164, "Extrude Dialog")
    
    section7.DistanceTolerance = 0.01
    
    section7.ChainingTolerance = 0.0094999999999999998
    
    section7.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId165 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves10 = [NXOpen.ICurve.Null] * 7 
    curves10[0] = line28
    curves10[1] = line21
    curves10[2] = line19
    curves10[3] = line27
    curves10[4] = line22
    curves10[5] = line20
    curves10[6] = line26
    seedPoint10 = NXOpen.Point3d(96.666666666660831, -2.2413700126928761e-45, 33.333333333333329)
    regionBoundaryRule10 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves10, seedPoint10, 0.01)
    
    curves11 = [NXOpen.ICurve.Null] * 7 
    curves11[0] = line28
    curves11[1] = line21
    curves11[2] = line19
    curves11[3] = line27
    curves11[4] = line22
    curves11[5] = line20
    curves11[6] = line26
    seedPoint11 = NXOpen.Point3d(15.0, -2.2413700126928761e-45, 33.333333333333336)
    regionBoundaryRule11 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves11, seedPoint11, 0.01)
    
    section7.AllowSelfIntersection(True)
    
    rules13 = [None] * 2 
    rules13[0] = regionBoundaryRule10
    rules13[1] = regionBoundaryRule11
    helpPoint13 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section7.AddToSection(rules13, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint13, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId165, None)
    
    markId166 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId167 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId167, None)
    
    direction18 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder7.Direction = direction18
    
    expression97 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression98 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId166, None)
    
    rotMatrix16 = NXOpen.Matrix3x3()
    
    rotMatrix16.Xx = 0.99999570398428006
    rotMatrix16.Xy = 0.00077844125120590281
    rotMatrix16.Xz = 0.0028259586342995707
    rotMatrix16.Yx = -0.0029236398193139123
    rotMatrix16.Yy = 0.33414258526628554
    rotMatrix16.Yz = 0.94251800250274798
    rotMatrix16.Zx = -0.00021057823076810894
    rotMatrix16.Zy = -0.94252221551578397
    rotMatrix16.Zz = 0.33414342566632549
    translation16 = NXOpen.Point3d(-77.181697655437745, -35.981821995686879, 39.612178446893978)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix16, translation16, 2.2271466692831128)
    
    rotMatrix17 = NXOpen.Matrix3x3()
    
    rotMatrix17.Xx = 0.99720346111717917
    rotMatrix17.Xy = 0.070651502844804037
    rotMatrix17.Xz = -0.02436436499663434
    rotMatrix17.Yx = -0.017328618336527126
    rotMatrix17.Yy = 0.53571497440519489
    rotMatrix17.Yz = 0.84422105232254707
    rotMatrix17.Zx = 0.072697841250380701
    rotMatrix17.Zy = -0.84143795454199266
    rotMatrix17.Zz = 0.53544111957686114
    translation17 = NXOpen.Point3d(-79.46726022501484, -41.594015648657589, 24.414384010274929)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix17, translation17, 2.2271466692831128)
    
    scaleAboutPoint199 = NXOpen.Point3d(-27.917821574520403, -28.749416259718824, 0.0)
    viewCenter199 = NXOpen.Point3d(27.917821574520403, 28.749416259718927, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint199, viewCenter199)
    
    scaleAboutPoint200 = NXOpen.Point3d(-22.334257259616322, -22.999533007775046, 0.0)
    viewCenter200 = NXOpen.Point3d(22.334257259616322, 22.999533007775149, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint200, viewCenter200)
    
    scaleAboutPoint201 = NXOpen.Point3d(-16.422807040262562, -15.738523413584891, 0.0)
    viewCenter201 = NXOpen.Point3d(16.422807040262551, 15.738523413584996, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint201, viewCenter201)
    
    scaleAboutPoint202 = NXOpen.Point3d(-20.528508800328193, -19.768193659575243, 0.0)
    viewCenter202 = NXOpen.Point3d(20.528508800328193, 19.768193659575338, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint202, viewCenter202)
    
    scaleAboutPoint203 = NXOpen.Point3d(-25.660636000410239, -24.829041315211704, 0.0)
    viewCenter203 = NXOpen.Point3d(25.660636000410239, 24.829041315211807, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint203, viewCenter203)
    
    scaleAboutPoint204 = NXOpen.Point3d(-32.075795000512791, -31.036301644014635, 0.0)
    viewCenter204 = NXOpen.Point3d(32.075795000512819, 31.036301644014724, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint204, viewCenter204)
    
    direction19 = extrudeBuilder7.Direction
    
    success2 = direction19.ReverseDirection()
    
    extrudeBuilder7.Direction = direction19
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("127")
    
    rotMatrix18 = NXOpen.Matrix3x3()
    
    rotMatrix18.Xx = 0.99720346111717917
    rotMatrix18.Xy = 0.070651502844804037
    rotMatrix18.Xz = -0.02436436499663434
    rotMatrix18.Yx = 0.0023650260294442575
    rotMatrix18.Yy = 0.29601559144375578
    rotMatrix18.Yz = 0.95518018000484273
    rotMatrix18.Zx = 0.074697147119542853
    rotMatrix18.Zy = -0.95256660384876735
    rotMatrix18.Zz = 0.29502067968911483
    translation18 = NXOpen.Point3d(-93.088781168565959, -42.186209079875489, 37.277610262751985)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix18, translation18, 1.4253738683411923)
    
    markId168 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId169 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    facesOfFeatures5 = [NXOpen.Face.Null] * 1 
    facesOfFeatures5[0] = face4
    edgeBoundaryRule5 = workPart.ScRuleFactory.CreateRuleEdgeBoundary(facesOfFeatures5)
    
    section7.AllowSelfIntersection(True)
    
    rules14 = [None] * 1 
    rules14[0] = edgeBoundaryRule5
    helpPoint14 = NXOpen.Point3d(35.048686363296611, 0.0, 28.92088962590833)
    section7.AddToSection(rules14, face4, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint14, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId169, None)
    
    workPart.Expressions.Delete(expression97)
    
    workPart.Expressions.Delete(expression98)
    
    expression99 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId168, None)
    
    rotMatrix19 = NXOpen.Matrix3x3()
    
    rotMatrix19.Xx = 0.99720346111717917
    rotMatrix19.Xy = 0.070651502844804037
    rotMatrix19.Xz = -0.02436436499663434
    rotMatrix19.Yx = 0.02230504092977514
    rotMatrix19.Yy = 0.029791611745590807
    rotMatrix19.Yz = 0.99930723254598786
    rotMatrix19.Zx = 0.071328411485463747
    rotMatrix19.Zy = -0.99705607917276695
    rotMatrix19.Zz = 0.028132413682258946
    translation19 = NXOpen.Point3d(-93.088781168565959, -26.977153574096327, 46.721973941631305)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix19, translation19, 1.4253738683411923)
    
    rotMatrix20 = NXOpen.Matrix3x3()
    
    rotMatrix20.Xx = 0.98586440499872829
    rotMatrix20.Xy = -0.0076066164975658185
    rotMatrix20.Xz = 0.16737238225574352
    rotMatrix20.Yx = -0.16675674106567309
    rotMatrix20.Yy = 0.052249307996449154
    rotMatrix20.Yz = 0.98461271529624694
    rotMatrix20.Zx = -0.016234662474465374
    rotMatrix20.Zy = -0.99860510172908223
    rotMatrix20.Zz = 0.050242278361844209
    translation20 = NXOpen.Point3d(-82.366732366679742, -11.759168919843177, 55.242677279322578)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix20, translation20, 1.4253738683411923)
    
    extrudeBuilder7.Limits.EndExtend.Value.SetFormula("100")
    
    rotMatrix21 = NXOpen.Matrix3x3()
    
    rotMatrix21.Xx = 0.92057923140448894
    rotMatrix21.Xy = 0.37921573742912007
    rotMatrix21.Xz = 0.093430740084884778
    rotMatrix21.Yx = -0.22516672612782326
    rotMatrix21.Yy = 0.31986477454477935
    rotMatrix21.Yz = 0.9203186792901118
    rotMatrix21.Zx = 0.31911412402399009
    rotMatrix21.Zy = -0.86826375629269781
    rotMatrix21.Zz = 0.37984763439686653
    translation21 = NXOpen.Point3d(-20.868458112759122, 32.516189786726109, 29.312716895047259)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix21, translation21, 1.4253738683411923)
    
    scaleAboutPoint205 = NXOpen.Point3d(35.825396036452354, 35.082900781810899, 0.0)
    viewCenter205 = NXOpen.Point3d(-35.825396036452325, -35.082900781810821, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint205, viewCenter205)
    
    scaleAboutPoint206 = NXOpen.Point3d(46.870012949244661, 43.853625977263619, 0.0)
    viewCenter206 = NXOpen.Point3d(-46.870012949244661, -43.85362597726354, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint206, viewCenter206)
    
    scaleAboutPoint207 = NXOpen.Point3d(59.457627813088827, 54.817032471579516, 0.0)
    viewCenter207 = NXOpen.Point3d(-59.457627813088848, -54.817032471579445, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint207, viewCenter207)
    
    scaleAboutPoint208 = NXOpen.Point3d(74.684581277416356, 68.52129058947439, 0.0)
    viewCenter208 = NXOpen.Point3d(-74.684581277416484, -68.521290589474262, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint208, viewCenter208)
    
    scaleAboutPoint209 = NXOpen.Point3d(93.355726596770523, 85.651613236842977, 0.0)
    viewCenter209 = NXOpen.Point3d(-93.355726596770594, -85.651613236842834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint209, viewCenter209)
    
    scaleAboutPoint210 = NXOpen.Point3d(117.82761609301136, 107.06451654605372, 0.0)
    viewCenter210 = NXOpen.Point3d(-117.82761609301146, -107.06451654605353, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint210, viewCenter210)
    
    scaleAboutPoint211 = NXOpen.Point3d(286.07185637966683, 209.59720170391452, 0.0)
    viewCenter211 = NXOpen.Point3d(-286.07185637966694, -209.59720170391441, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint211, viewCenter211)
    
    scaleAboutPoint212 = NXOpen.Point3d(228.85748510373332, 167.67776136313162, 0.0)
    viewCenter212 = NXOpen.Point3d(-228.85748510373352, -167.67776136313148, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint212, viewCenter212)
    
    scaleAboutPoint213 = NXOpen.Point3d(183.99235436062523, 134.1422090905053, 0.0)
    viewCenter213 = NXOpen.Point3d(-183.9923543606254, -134.14220909050516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint213, viewCenter213)
    
    scaleAboutPoint214 = NXOpen.Point3d(147.19388348850018, 107.31376727240431, 0.0)
    viewCenter214 = NXOpen.Point3d(-147.19388348850043, -107.31376727240408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint214, viewCenter214)
    
    scaleAboutPoint215 = NXOpen.Point3d(93.682018456720328, 72.219265002239695, 0.0)
    viewCenter215 = NXOpen.Point3d(-93.682018456720456, -72.219265002239467, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint215, viewCenter215)
    
    scaleAboutPoint216 = NXOpen.Point3d(74.249525464149826, 57.543382234716276, 0.0)
    viewCenter216 = NXOpen.Point3d(-74.249525464149983, -57.543382234716098, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint216, viewCenter216)
    
    extrudeBuilder7.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies17 = [NXOpen.Body.Null] * 1 
    body2 = workPart.Bodies.FindObject("EXTRUDE(2)")
    targetBodies17[0] = body2
    extrudeBuilder7.BooleanOperation.SetTargetBodies(targetBodies17)
    
    markId170 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId170, None)
    
    markId171 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder7.ParentFeatureInternal = False
    
    markId172 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    try:
        # Solid tool body is required for current Boolean option.
        # Change the body type to solid or change the Boolean option to None.
        #
        feature13 = extrudeBuilder7.CommitFeature()
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(671468)
        
    theSession.UndoToMarkWithStatus(markId171, None)
    
    theSession.DeleteUndoMark(markId171, None)
    
    pointonstartcurve1 = NXOpen.Point3d(49.999999999997087, -7.2736615473241934e-14, 40.0)
    section7.SetStartCurveOfClosedLoop(0, pointonstartcurve1)
    
    pointonstartcurve2 = NXOpen.Point3d(99.999999999994174, -1.4547323094648387e-13, 20.0)
    section7.SetStartCurveOfClosedLoop(0, pointonstartcurve2)
    
    section7.ReverseDirectionOfClosedLoop(0)
    
    rotMatrix22 = NXOpen.Matrix3x3()
    
    rotMatrix22.Xx = 0.92057923140448894
    rotMatrix22.Xy = 0.37921573742912007
    rotMatrix22.Xz = 0.093430740084884778
    rotMatrix22.Yx = -0.18490724862765159
    rotMatrix22.Yy = 0.21247492464474066
    rotMatrix22.Yz = 0.95951222806286529
    rotMatrix22.Zx = 0.34401044767807931
    rotMatrix22.Zy = -0.9005830505196617
    rotMatrix22.Zz = 0.26571974146650679
    translation22 = NXOpen.Point3d(-116.67264257194235, -24.230038694560211, 26.79174016200114)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix22, translation22, 1.4253738683411936)
    
    scaleAboutPoint217 = NXOpen.Point3d(-7.9818239873961847, -6.3112096644526376, 0.0)
    viewCenter217 = NXOpen.Point3d(7.9818239873960586, 6.3112096644528277, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint217, viewCenter217)
    
    scaleAboutPoint218 = NXOpen.Point3d(-10.673369285471637, -9.281190683018627, 0.0)
    viewCenter218 = NXOpen.Point3d(10.673369285471477, 9.2811906830188242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint218, viewCenter218)
    
    scaleAboutPoint219 = NXOpen.Point3d(-13.921786024528156, -12.471599980306314, 0.0)
    viewCenter219 = NXOpen.Point3d(13.921786024527982, 12.471599980306511, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint219, viewCenter219)
    
    scaleAboutPoint220 = NXOpen.Point3d(-19.214965085937433, -18.127325552770863, 0.0)
    viewCenter220 = NXOpen.Point3d(19.214965085937184, 18.127325552771051, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint220, viewCenter220)
    
    scaleAboutPoint221 = NXOpen.Point3d(-28.097354606795186, -26.284622051517804, 0.0)
    viewCenter221 = NXOpen.Point3d(28.097354606794877, 26.28462205151796, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint221, viewCenter221)
    
    scaleAboutPoint222 = NXOpen.Point3d(-22.477883685436147, -21.027697641214214, 0.0)
    viewCenter222 = NXOpen.Point3d(22.477883685435902, 21.027697641214399, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint222, viewCenter222)
    
    scaleAboutPoint223 = NXOpen.Point3d(-17.982306948348963, -16.822158112971366, 0.0)
    viewCenter223 = NXOpen.Point3d(17.982306948348764, 16.822158112971515, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint223, viewCenter223)
    
    scaleAboutPoint224 = NXOpen.Point3d(-14.38584555867917, -13.457726490377073, 0.0)
    viewCenter224 = NXOpen.Point3d(14.385845558678934, 13.457726490377212, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint224, viewCenter224)
    
    scaleAboutPoint225 = NXOpen.Point3d(-11.508676446943371, -10.766181192301644, 0.0)
    viewCenter225 = NXOpen.Point3d(11.508676446943117, 10.766181192301786, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint225, viewCenter225)
    
    scaleAboutPoint226 = NXOpen.Point3d(-9.2069411575546951, -8.6129449538413159, 0.0)
    viewCenter226 = NXOpen.Point3d(9.2069411575544802, 8.612944953841442, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint226, viewCenter226)
    
    scaleAboutPoint227 = NXOpen.Point3d(-7.3655529260437964, -6.8903559630730413, 0.0)
    viewCenter227 = NXOpen.Point3d(7.3655529260435531, 6.890355963073163, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint227, viewCenter227)
    
    scaleAboutPoint228 = NXOpen.Point3d(-5.8924423408350686, -5.5122847704584244, 0.0)
    viewCenter228 = NXOpen.Point3d(5.8924423408348092, 5.512284770458538, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint228, viewCenter228)
    
    scaleAboutPoint229 = NXOpen.Point3d(-4.7139538726680925, -4.4098278163667253, 0.0)
    viewCenter229 = NXOpen.Point3d(4.7139538726678074, 4.4098278163668416, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint229, viewCenter229)
    
    scaleAboutPoint230 = NXOpen.Point3d(-3.7711630981345046, -3.5278622530933692, 0.0)
    viewCenter230 = NXOpen.Point3d(3.7711630981342141, 3.5278622530934833, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint230, viewCenter230)
    
    rotMatrix23 = NXOpen.Matrix3x3()
    
    rotMatrix23.Xx = 0.9777444401814126
    rotMatrix23.Xy = 0.18210826303563971
    rotMatrix23.Xz = 0.10417480611203078
    rotMatrix23.Yx = -0.15152385049473524
    rotMatrix23.Yy = 0.26951754422696317
    rotMatrix23.Yz = 0.95099990330447304
    rotMatrix23.Zx = 0.14510800262420459
    rotMatrix23.Zy = -0.94561983581564601
    rotMatrix23.Zz = 0.29111302562132968
    translation23 = NXOpen.Point3d(-100.62104032017592, -17.93043091750986, 46.709938209871794)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix23, translation23, 5.4373697980544797)
    
    scaleAboutPoint231 = NXOpen.Point3d(-23.746162475994545, -2.2383677743764601, 0.0)
    viewCenter231 = NXOpen.Point3d(23.746162475994247, 2.2383677743765804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint231, viewCenter231)
    
    scaleAboutPoint232 = NXOpen.Point3d(-29.682703094993144, -2.9196101404910575, 0.0)
    viewCenter232 = NXOpen.Point3d(29.682703094992853, 2.9196101404911818, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint232, viewCenter232)
    
    scaleAboutPoint233 = NXOpen.Point3d(-37.10337886874138, -3.7255441896891135, 0.0)
    viewCenter233 = NXOpen.Point3d(37.10337886874111, 3.7255441896892432, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint233, viewCenter233)
    
    scaleAboutPoint234 = NXOpen.Point3d(-46.379223585926702, -4.656930237111407, 0.0)
    viewCenter234 = NXOpen.Point3d(46.379223585926411, 4.6569302371115366, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint234, viewCenter234)
    
    scaleAboutPoint235 = NXOpen.Point3d(-56.786037074981941, -5.82116279638928, 0.0)
    viewCenter235 = NXOpen.Point3d(56.786037074981657, 5.8211627963894008, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint235, viewCenter235)
    
    extrudeBuilder7.Destroy()
    
    section7.Destroy()
    
    workPart.Expressions.Delete(expression96)
    
    workPart.Expressions.Delete(expression99)
    
    theSession.UndoToMark(markId164, None)
    
    theSession.DeleteUndoMark(markId164, None)
    
    scaleAboutPoint236 = NXOpen.Point3d(71.184505052989536, 19.10291791141653, 0.0)
    viewCenter236 = NXOpen.Point3d(-71.18450505298982, -19.102917911416398, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint236, viewCenter236)
    
    scaleAboutPoint237 = NXOpen.Point3d(86.010650297671035, 22.690654981844244, 0.0)
    viewCenter237 = NXOpen.Point3d(-86.010650297671305, -22.69065498184413, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint237, viewCenter237)
    
    scaleAboutPoint238 = NXOpen.Point3d(101.87034893681341, 26.284332014309086, 0.0)
    viewCenter238 = NXOpen.Point3d(-101.87034893681368, -26.284332014308987, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint238, viewCenter238)
    
    scaleAboutPoint239 = NXOpen.Point3d(121.026726506564, 30.627929253961856, 0.0)
    viewCenter239 = NXOpen.Point3d(-121.02672650656433, -30.627929253961728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint239, viewCenter239)
    
    scaleAboutPoint240 = NXOpen.Point3d(119.72735981094132, 23.435006474622337, 0.0)
    viewCenter240 = NXOpen.Point3d(-119.72735981094172, -23.435006474622199, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint240, viewCenter240)
    
    scaleAboutPoint241 = NXOpen.Point3d(95.781887848753115, 18.748005179697905, 0.0)
    viewCenter241 = NXOpen.Point3d(-95.781887848753428, -18.748005179697763, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint241, viewCenter241)
    
    scaleAboutPoint242 = NXOpen.Point3d(76.625510279002398, 14.998404143758322, 0.0)
    viewCenter242 = NXOpen.Point3d(-76.625510279002754, -14.998404143758183, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint242, viewCenter242)
    
    scaleAboutPoint243 = NXOpen.Point3d(61.300408223201963, 11.998723315006663, 0.0)
    viewCenter243 = NXOpen.Point3d(-61.300408223202226, -11.998723315006551, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint243, viewCenter243)
    
    scaleAboutPoint244 = NXOpen.Point3d(-19.768193659575402, 17.677327022504844, 0.0)
    viewCenter244 = NXOpen.Point3d(19.768193659575111, -17.677327022504716, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint244, viewCenter244)
    
    scaleAboutPoint245 = NXOpen.Point3d(-24.710242074469196, 22.096658778131047, 0.0)
    viewCenter245 = NXOpen.Point3d(24.710242074468912, -22.096658778130916, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint245, viewCenter245)
    
    scaleAboutPoint246 = NXOpen.Point3d(-30.887802593086462, 27.62082347266378, 0.0)
    viewCenter246 = NXOpen.Point3d(30.88780259308616, -27.620823472663652, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint246, viewCenter246)
    
    scaleAboutPoint247 = NXOpen.Point3d(-38.609753241358035, 34.526029340829702, 0.0)
    viewCenter247 = NXOpen.Point3d(38.609753241357701, -34.526029340829574, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint247, viewCenter247)
    
    scaleAboutPoint248 = NXOpen.Point3d(-56.84729293348979, 42.461447374810703, 0.0)
    viewCenter248 = NXOpen.Point3d(56.847292933489499, -42.461447374810582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint248, viewCenter248)
    
    scaleAboutPoint249 = NXOpen.Point3d(-45.663458160452301, 33.969157899848582, 0.0)
    viewCenter249 = NXOpen.Point3d(45.663458160451981, -33.969157899848454, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint249, viewCenter249)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId173 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder8 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section8 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder8.Section = section8
    
    extrudeBuilder8.AllowSelfIntersectingSection(True)
    
    expression100 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder8.DistanceTolerance = 0.01
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies18 = [NXOpen.Body.Null] * 1 
    targetBodies18[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies18)
    
    extrudeBuilder8.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("50")
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies19 = [NXOpen.Body.Null] * 1 
    targetBodies19[0] = NXOpen.Body.Null
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies19)
    
    extrudeBuilder8.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder8.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder8.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder8 = extrudeBuilder8.SmartVolumeProfile
    
    smartVolumeProfileBuilder8.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder8.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId173, "Extrude Dialog")
    
    section8.DistanceTolerance = 0.01
    
    section8.ChainingTolerance = 0.0094999999999999998
    
    section8.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId174 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves12 = [NXOpen.ICurve.Null] * 7 
    curves12[0] = line28
    curves12[1] = line21
    curves12[2] = line19
    curves12[3] = line27
    curves12[4] = line22
    curves12[5] = line20
    curves12[6] = line26
    seedPoint12 = NXOpen.Point3d(96.666666666660831, -2.2413700126928761e-45, 33.333333333333329)
    regionBoundaryRule12 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves12, seedPoint12, 0.01)
    
    curves13 = [NXOpen.ICurve.Null] * 7 
    curves13[0] = line28
    curves13[1] = line21
    curves13[2] = line19
    curves13[3] = line27
    curves13[4] = line22
    curves13[5] = line20
    curves13[6] = line26
    seedPoint13 = NXOpen.Point3d(15.0, -2.2413700126928761e-45, 33.333333333333336)
    regionBoundaryRule13 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves13, seedPoint13, 0.01)
    
    section8.AllowSelfIntersection(True)
    
    rules15 = [None] * 2 
    rules15[0] = regionBoundaryRule12
    rules15[1] = regionBoundaryRule13
    helpPoint15 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section8.AddToSection(rules15, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint15, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId174, None)
    
    markId175 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId176 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId176, None)
    
    direction20 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction20
    
    expression101 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression102 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId175, None)
    
    markId177 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId178 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section8.Clear()
    
    theSession.DeleteUndoMark(markId178, None)
    
    workPart.Expressions.Delete(expression101)
    
    workPart.Expressions.Delete(expression102)
    
    theSession.DeleteUndoMark(markId177, None)
    
    markId179 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId180 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features3 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature3 = feature11
    features3[0] = sketchFeature3
    curveFeatureRule3 = workPart.ScRuleFactory.CreateRuleCurveFeature(features3)
    
    section8.AllowSelfIntersection(True)
    
    rules16 = [None] * 1 
    rules16[0] = curveFeatureRule3
    helpPoint16 = NXOpen.Point3d(45.000000000000043, -2.1316282072803006e-14, 28.094376003475592)
    section8.AddToSection(rules16, line21, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint16, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId180, None)
    
    direction21 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder8.Direction = direction21
    
    expression103 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression104 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId179, None)
    
    extrudeBuilder8.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies20 = [NXOpen.Body.Null] * 1 
    targetBodies20[0] = body2
    extrudeBuilder8.BooleanOperation.SetTargetBodies(targetBodies20)
    
    extrudeBuilder8.Limits.EndExtend.Value.SetFormula("-100")
    
    markId181 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId181, None)
    
    markId182 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder8.ParentFeatureInternal = False
    
    markId183 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature14 = extrudeBuilder8.CommitFeature()
    
    theSession.DeleteUndoMark(markId182, None)
    
    theSession.SetUndoMarkName(markId173, "Extrude")
    
    expression105 = extrudeBuilder8.Limits.StartExtend.Value
    expression106 = extrudeBuilder8.Limits.EndExtend.Value
    extrudeBuilder8.Destroy()
    
    workPart.Expressions.Delete(expression100)
    
    workPart.Expressions.Delete(expression103)
    
    workPart.Expressions.Delete(expression104)
    
    scaleAboutPoint250 = NXOpen.Point3d(-58.657125116678486, -11.434426921479011, 0.0)
    viewCenter250 = NXOpen.Point3d(58.657125116678181, 11.434426921479112, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint250, viewCenter250)
    
    scaleAboutPoint251 = NXOpen.Point3d(-46.806900852600187, -8.9099430556979122, 0.0)
    viewCenter251 = NXOpen.Point3d(46.80690085259986, 8.9099430556980348, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint251, viewCenter251)
    
    scaleAboutPoint252 = NXOpen.Point3d(-45.238750874797354, -8.2684271556876734, 0.0)
    viewCenter252 = NXOpen.Point3d(45.238750874797034, 8.2684271556877693, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint252, viewCenter252)
    
    scaleAboutPoint253 = NXOpen.Point3d(-56.429639352754016, -10.335533944609601, 0.0)
    viewCenter253 = NXOpen.Point3d(56.429639352753689, 10.335533944609702, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint253, viewCenter253)
    
    scaleAboutPoint254 = NXOpen.Point3d(-70.537049190942454, -12.919417430762024, 0.0)
    viewCenter254 = NXOpen.Point3d(70.537049190942142, 12.919417430762101, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint254, viewCenter254)
    
    scaleAboutPoint255 = NXOpen.Point3d(-88.171311488678043, -15.963647974792147, 0.0)
    viewCenter255 = NXOpen.Point3d(88.17131148867773, 15.963647974792243, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint255, viewCenter255)
    
    rotMatrix24 = NXOpen.Matrix3x3()
    
    rotMatrix24.Xx = 0.99682115507859748
    rotMatrix24.Xy = 0.013176852701769803
    rotMatrix24.Xz = 0.078574520938086895
    rotMatrix24.Yx = -0.075471613198612522
    rotMatrix24.Yy = 0.472160299925732
    rotMatrix24.Yz = 0.87827597415347991
    rotMatrix24.Zx = -0.025526856229723775
    rotMatrix24.Zy = -0.88141421688495625
    rotMatrix24.Zz = 0.47165385388450842
    translation24 = NXOpen.Point3d(-147.3506712201912, -36.169824577877748, 86.046378695910917)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix24, translation24, 1.1402990946729574)
    
    rotMatrix25 = NXOpen.Matrix3x3()
    
    rotMatrix25.Xx = 0.99674657208985262
    rotMatrix25.Xy = 0.024582941202222156
    rotMatrix25.Xz = 0.076759038744499131
    rotMatrix25.Yx = -0.070785830295773997
    rotMatrix25.Yy = -0.18843659381255234
    rotMatrix25.Yz = 0.97953101857045144
    rotMatrix25.Zx = 0.038543965240609428
    rotMatrix25.Zy = -0.98177763730601197
    rotMatrix25.Zz = -0.18608340503483703
    translation25 = NXOpen.Point3d(-147.86449094942054, -6.4326072615243817, 86.887834041263446)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix25, translation25, 1.1402990946729574)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId184 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder10 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin24 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal21 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane21 = workPart.Planes.CreatePlane(origin24, normal21, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.PlaneReference = plane21
    
    expression107 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression108 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder8 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder8.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId184, "Create Sketch Dialog")
    
    scalar15 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point33 = workPart.Points.CreatePoint(edge5, scalar15, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrude4 = feature14
    edge14 = extrude4.FindObject("EDGE * 190 EXTRUDE(2) 150 {(-0,-0,20)(22.5,-0,20)(45,-0,20) EXTRUDE(2)}")
    direction22 = workPart.Directions.CreateDirection(edge14, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    xform6 = workPart.Xforms.CreateXformByPlaneXDirPoint(face4, direction22, point33, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem6 = workPart.CoordinateSystems.CreateCoordinateSystem(xform6, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem6
    
    origin25 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal22 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane22 = workPart.Planes.CreatePlane(origin25, normal22, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane22.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom26 = [NXOpen.NXObject.Null] * 1 
    geom26[0] = face4
    plane22.SetGeometry(geom26)
    
    plane22.SetFlip(False)
    
    plane22.SetExpression(None)
    
    plane22.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane22.Evaluate()
    
    origin26 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal23 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane23 = workPart.Planes.CreatePlane(origin26, normal23, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression109 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression110 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane23.SynchronizeToPlane(plane22)
    
    scalar16 = workPart.Scalars.CreateScalar(0.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point34 = workPart.Points.CreatePoint(edge5, scalar16, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom27 = [NXOpen.NXObject.Null] * 1 
    geom27[0] = face4
    plane23.SetGeometry(geom27)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    plane23.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom28 = [NXOpen.NXObject.Null] * 1 
    geom28[0] = face5
    plane23.SetGeometry(geom28)
    
    plane23.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane23.Evaluate()
    
    plane22.SynchronizeToPlane(plane23)
    
    xform7 = workPart.Xforms.CreateXformByPlaneXDirPoint(plane22, direction22, point33, NXOpen.SmartObject.UpdateOption.WithinModeling, 1.0, False, False)
    
    cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder10.Csystem = cartesianCoordinateSystem7
    
    markId185 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId185, None)
    
    markId186 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject24 = sketchInPlaceBuilder10.Commit()
    
    sketch10 = nXObject24
    feature15 = sketch10.Feature
    
    markId187 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs10 = theSession.UpdateManager.DoUpdate(markId187)
    
    sketch10.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId186, None)
    
    theSession.SetUndoMarkName(markId184, "Create Sketch")
    
    sketchInPlaceBuilder10.Destroy()
    
    sketchAlongPathBuilder8.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression108)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point34)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression107)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane21.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression110)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression109)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane23.DestroyPlane()
    
    scaleAboutPoint256 = NXOpen.Point3d(-22.506887406320569, 6.2648037110376773, 0.0)
    viewCenter256 = NXOpen.Point3d(22.506887406320232, -6.2648037110375983, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint256, viewCenter256)
    
    scaleAboutPoint257 = NXOpen.Point3d(-28.133609257900709, 8.1210418476414397, 0.0)
    viewCenter257 = NXOpen.Point3d(28.133609257900314, -8.1210418476413651, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint257, viewCenter257)
    
    scaleAboutPoint258 = NXOpen.Point3d(-35.16701157237582, 10.513848820607214, 0.0)
    viewCenter258 = NXOpen.Point3d(35.167011572375451, -10.513848820607089, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint258, viewCenter258)
    
    scaleAboutPoint259 = NXOpen.Point3d(-43.958764465469699, 13.142311025758977, 0.0)
    viewCenter259 = NXOpen.Point3d(43.958764465469464, -13.142311025758861, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint259, viewCenter259)
    
    scaleAboutPoint260 = NXOpen.Point3d(-53.815497734788863, 23.792114788011908, 0.0)
    viewCenter260 = NXOpen.Point3d(53.815497734788664, -23.792114788011762, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint260, viewCenter260)
    
    scaleAboutPoint261 = NXOpen.Point3d(-43.052398187831166, 19.033691830409527, 0.0)
    viewCenter261 = NXOpen.Point3d(43.052398187830931, -19.03369183040941, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint261, viewCenter261)
    
    scaleAboutPoint262 = NXOpen.Point3d(-34.441918550264937, 15.226953464327654, 0.0)
    viewCenter262 = NXOpen.Point3d(34.441918550264688, -15.226953464327529, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint262, viewCenter262)
    
    scaleAboutPoint263 = NXOpen.Point3d(-27.553534840211949, 12.181562771462122, 0.0)
    viewCenter263 = NXOpen.Point3d(27.55353484021175, -12.181562771462024, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint263, viewCenter263)
    
    scaleAboutPoint264 = NXOpen.Point3d(-26.915452980754424, 9.5132204500942521, 0.0)
    viewCenter264 = NXOpen.Point3d(26.915452980754146, -9.5132204500941331, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint264, viewCenter264)
    
    scaleAboutPoint265 = NXOpen.Point3d(-21.532362384603609, 7.6105763600754193, 0.0)
    viewCenter265 = NXOpen.Point3d(21.532362384603289, -7.6105763600752923, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint265, viewCenter265)
    
    scaleAboutPoint266 = NXOpen.Point3d(-17.225889907682884, 6.088461088060348, 0.0)
    viewCenter266 = NXOpen.Point3d(17.225889907682632, -6.0884610880602086, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint266, viewCenter266)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Circle...
    # ----------------------------------------------
    markId188 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId189 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId189, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix2 = theSession.ActiveSketch.Orientation
    
    center2 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    arc2 = workPart.Curves.CreateArc(center2, nXMatrix2, 2.7263422971495022, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc2, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_34.Geometry = arc2
    conGeom1_34.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_34.SplineDefiningPointIndex = 0
    conGeom2_34 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_34.Geometry = line2
    conGeom2_34.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_34.SplineDefiningPointIndex = 0
    help9 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help9.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help9.Point.X = 15.30421888675815
    help9.Point.Y = 100.0
    help9.Point.Z = 0.0
    help9.Parameter = 0.0
    sketchHelpedGeometricConstraint9 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_34, conGeom2_34, help9)
    
    dimObject1_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_19.Geometry = arc2
    dimObject1_19.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_19.AssocValue = 0
    dimObject1_19.HelpPoint.X = 0.0
    dimObject1_19.HelpPoint.Y = 0.0
    dimObject1_19.HelpPoint.Z = 0.0
    dimObject1_19.View = NXOpen.NXObject.Null
    dimOrigin19 = NXOpen.Point3d(15.30421888675815, 100.0, -1.3470150131448904)
    sketchDimensionalConstraint19 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_19, dimOrigin19, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension19 = sketchDimensionalConstraint19.AssociatedDimension
    
    expression111 = sketchDimensionalConstraint19.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId190 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Curve")
    
    theSession.SetUndoMarkVisibility(markId190, "Curve", NXOpen.Session.MarkVisibility.Visible)
    
    nXMatrix3 = theSession.ActiveSketch.Orientation
    
    center3 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    arc3 = workPart.Curves.CreateArc(center3, nXMatrix3, 5.0446244782728655, 0.0, ( 360.0 * math.pi/180.0 ))
    
    theSession.ActiveSketch.AddGeometry(arc3, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    conGeom1_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_35.Geometry = arc3
    conGeom1_35.PointType = NXOpen.Sketch.ConstraintPointType.ArcCenter
    conGeom1_35.SplineDefiningPointIndex = 0
    conGeom2_35 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_35.Geometry = line2
    conGeom2_35.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_35.SplineDefiningPointIndex = 0
    help10 = NXOpen.Sketch.ConstraintGeometryHelp()
    
    help10.Type = NXOpen.Sketch.ConstraintGeometryHelpType.Point
    help10.Point.X = 91.929729165760733
    help10.Point.Y = 100.0
    help10.Point.Z = 0.0
    help10.Parameter = 0.0
    sketchHelpedGeometricConstraint10 = theSession.ActiveSketch.CreatePointOnCurveConstraint(conGeom1_35, conGeom2_35, help10)
    
    dimObject1_20 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_20.Geometry = arc3
    dimObject1_20.AssocType = NXOpen.Sketch.AssocType.NotSet
    dimObject1_20.AssocValue = 0
    dimObject1_20.HelpPoint.X = 0.0
    dimObject1_20.HelpPoint.Y = 0.0
    dimObject1_20.HelpPoint.Z = 0.0
    dimObject1_20.View = NXOpen.NXObject.Null
    dimOrigin20 = NXOpen.Point3d(91.929729165760733, 100.0, -1.3470150131448904)
    sketchDimensionalConstraint20 = theSession.ActiveSketch.CreateDiameterDimension(dimObject1_20, dimOrigin20, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension20 = sketchDimensionalConstraint20.AssociatedDimension
    
    expression112 = sketchDimensionalConstraint20.AssociatedExpression
    
    theSession.ActiveSketch.Update()
    
    # ----------------------------------------------
    #   Dialog Begin Circle
    # ----------------------------------------------
    markId191 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    diameterDimension1 = dimension19
    sketchRadialDimensionBuilder1 = workPart.Sketches.CreateRadialDimensionBuilder(diameterDimension1)
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder1.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId191, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits207 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits208 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits209 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits210 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits211 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits212 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder1.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits213 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits214 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits215 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits216 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits217 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits218 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits219 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits220 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits221 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits222 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits223 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits224 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId192 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId192, None)
    
    markId193 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin4 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin4.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin4.View = NXOpen.View.Null
    assocOrigin4.ViewOfGeometry = workPart.ModelingViews.WorkView
    point35 = workPart.Points.FindObject("ENTITY 2 10")
    assocOrigin4.PointOnGeometry = point35
    assocOrigin4.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.DimensionLine = 0
    assocOrigin4.AssociatedView = NXOpen.View.Null
    assocOrigin4.AssociatedPoint = NXOpen.Point.Null
    assocOrigin4.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin4.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin4.XOffsetFactor = 0.0
    assocOrigin4.YOffsetFactor = 0.0
    assocOrigin4.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin4)
    
    point36 = NXOpen.Point3d(31.34211638701451, 100.0, -20.66061359602654)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point36)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.DiameterDimensionDimLineAngle = 0.0
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextAngle = 48.585564806072192
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits225 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits226 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits227 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits228 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits229 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits230 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits231 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits232 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits233 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits234 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits235 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits236 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId193, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId193, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId194 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin5 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin5.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin5.View = NXOpen.View.Null
    assocOrigin5.ViewOfGeometry = workPart.ModelingViews.WorkView
    assocOrigin5.PointOnGeometry = point35
    assocOrigin5.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.DimensionLine = 0
    assocOrigin5.AssociatedView = NXOpen.View.Null
    assocOrigin5.AssociatedPoint = NXOpen.Point.Null
    assocOrigin5.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin5.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin5.XOffsetFactor = 0.0
    assocOrigin5.YOffsetFactor = 0.0
    assocOrigin5.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin5)
    
    point37 = NXOpen.Point3d(32.054911831470342, 100.0, -21.373409040482375)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point37)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.DiameterDimensionDimLineAngle = 0.0
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextAngle = 48.45231616922743
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits237 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits238 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits239 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits240 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits241 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits242 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits243 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits244 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits245 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits246 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits247 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits248 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId194, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId194, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId195 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin6 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin6.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin6.View = NXOpen.View.Null
    assocOrigin6.ViewOfGeometry = workPart.ModelingViews.WorkView
    assocOrigin6.PointOnGeometry = point35
    assocOrigin6.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.DimensionLine = 0
    assocOrigin6.AssociatedView = NXOpen.View.Null
    assocOrigin6.AssociatedPoint = NXOpen.Point.Null
    assocOrigin6.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin6.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin6.XOffsetFactor = 0.0
    assocOrigin6.YOffsetFactor = 0.0
    assocOrigin6.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin6)
    
    point38 = NXOpen.Point3d(39.539263998256644, 100.0, -13.532659151468163)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point38)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.DiameterDimensionDimLineAngle = 0.0
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextAngle = 25.792516088465689
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits249 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits250 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits251 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits252 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits253 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits254 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits255 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits256 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits257 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits258 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits259 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits260 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId195, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId195, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId196 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometryFromLeader(False)
    
    assocOrigin7 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin7.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin7.View = NXOpen.View.Null
    assocOrigin7.ViewOfGeometry = workPart.ModelingViews.WorkView
    assocOrigin7.PointOnGeometry = point35
    assocOrigin7.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.DimensionLine = 0
    assocOrigin7.AssociatedView = NXOpen.View.Null
    assocOrigin7.AssociatedPoint = NXOpen.Point.Null
    assocOrigin7.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin7.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin7.XOffsetFactor = 0.0
    assocOrigin7.YOffsetFactor = 0.0
    assocOrigin7.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRadialDimensionBuilder1.Origin.SetAssociativeOrigin(assocOrigin7)
    
    point39 = NXOpen.Point3d(25.996150553595729, 100.0, -18.047030299688469)
    sketchRadialDimensionBuilder1.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point39)
    
    sketchRadialDimensionBuilder1.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder1.DiameterDimensionDimLineAngle = 0.0
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextAngle = 54.8727538614027
    
    sketchRadialDimensionBuilder1.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRadialDimensionBuilder1.Style.DimensionStyle.TextCentered = False
    
    dimensionlinearunits261 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits262 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits263 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits264 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits265 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits266 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits267 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits268 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits269 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits270 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits271 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits272 = sketchRadialDimensionBuilder1.Style.UnitsStyle.DimensionLinearUnits
    
    theSession.SetUndoMarkName(markId196, "Radial Dimension - Specify Location")
    
    theSession.SetUndoMarkVisibility(markId196, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId197 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("5")
    
    sketchRadialDimensionBuilder1.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject25 = sketchRadialDimensionBuilder1.Commit()
    
    point1_29 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    point2_29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder1.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, NXOpen.View.Null, point1_29, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_29)
    
    sketchRadialDimensionBuilder1.Driving.ExpressionValue.SetFormula("5")
    
    theSession.SetUndoMarkName(markId197, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId197, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId198 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    markId199 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject26 = sketchRadialDimensionBuilder1.Commit()
    
    theSession.DeleteUndoMark(markId199, None)
    
    theSession.SetUndoMarkName(markId191, "Radial Dimension")
    
    expression113 = sketchRadialDimensionBuilder1.Driving.ExpressionValue
    sketchRadialDimensionBuilder1.Destroy()
    
    theSession.DeleteUndoMark(markId198, None)
    
    theSession.SetUndoMarkVisibility(markId191, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId197, None)
    
    theSession.DeleteUndoMark(markId196, None)
    
    theSession.DeleteUndoMark(markId195, None)
    
    theSession.DeleteUndoMark(markId194, None)
    
    theSession.DeleteUndoMark(markId193, None)
    
    markId200 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    diameterDimension2 = dimension20
    sketchRadialDimensionBuilder2 = workPart.Sketches.CreateRadialDimensionBuilder(diameterDimension2)
    
    sketchRadialDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Inferred
    
    sketchRadialDimensionBuilder2.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId200, "Radial Dimension Dialog")
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits273 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits274 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Style.OrdinateStyle.DoglegCreationOption = NXOpen.Annotations.OrdinateDoglegCreationOption.No
    
    dimensionlinearunits275 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits276 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits277 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits278 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Origin.SetInferRelativeToGeometry(True)
    
    sketchRadialDimensionBuilder2.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRadialDimensionBuilder2.Measurement.DirectionView = NXOpen.View.Null
    
    dimensionlinearunits279 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits280 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits281 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits282 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits283 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits284 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits285 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits286 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits287 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits288 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits289 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits290 = sketchRadialDimensionBuilder2.Style.UnitsStyle.DimensionLinearUnits
    
    # ----------------------------------------------
    #   Dialog Begin Radial Dimension
    # ----------------------------------------------
    markId201 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    theSession.DeleteUndoMark(markId201, None)
    
    markId202 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    sketchRadialDimensionBuilder2.Driving.ExpressionValue.SetFormula("5")
    
    sketchRadialDimensionBuilder2.Driving.ExpressionMode = NXOpen.Annotations.DrivingValueBuilder.DrivingExpressionMode.KeepExpression
    
    nXObject27 = sketchRadialDimensionBuilder2.Commit()
    
    point1_30 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    point2_30 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRadialDimensionBuilder2.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, NXOpen.View.Null, point1_30, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_30)
    
    sketchRadialDimensionBuilder2.Driving.ExpressionValue.SetFormula("5")
    
    theSession.SetUndoMarkName(markId202, "Radial Dimension - =")
    
    theSession.SetUndoMarkVisibility(markId202, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Invisible)
    
    markId203 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    markId204 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Radial Dimension")
    
    nXObject28 = sketchRadialDimensionBuilder2.Commit()
    
    theSession.DeleteUndoMark(markId204, None)
    
    theSession.SetUndoMarkName(markId200, "Radial Dimension")
    
    expression114 = sketchRadialDimensionBuilder2.Driving.ExpressionValue
    sketchRadialDimensionBuilder2.Destroy()
    
    theSession.DeleteUndoMark(markId203, None)
    
    theSession.SetUndoMarkVisibility(markId200, None, NXOpen.Session.MarkVisibility.Visible)
    
    theSession.DeleteUndoMark(markId202, None)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Constraint->Dimension->Rapid...
    # ----------------------------------------------
    markId205 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchRapidDimensionBuilder8 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines45 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines45)
    
    lines46 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines46)
    
    lines47 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines47)
    
    lines48 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines48)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder8.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    lines49 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBefore(lines49)
    
    lines50 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAfter(lines50)
    
    lines51 = []
    sketchRapidDimensionBuilder8.AppendedText.SetAbove(lines51)
    
    lines52 = []
    sketchRapidDimensionBuilder8.AppendedText.SetBelow(lines52)
    
    theSession.SetUndoMarkName(markId205, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder8.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits291 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits292 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits293 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits294 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits295 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits296 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits297 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits298 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits299 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits300 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder8.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits301 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits302 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits303 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits304 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits305 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits306 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits307 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits308 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits309 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits310 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    point1_31 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    point2_31 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_31, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_31)
    
    point1_32 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    point2_32 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc2, workPart.ModelingViews.WorkView, point1_32, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_32)
    
    point1_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_33 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_33, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_33)
    
    dimensionlinearunits311 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits312 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits313 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits314 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits315 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits316 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    scaleAboutPoint267 = NXOpen.Point3d(-74.24952546414994, 7.0091552038158129, 0.0)
    viewCenter267 = NXOpen.Point3d(74.249525464149656, -7.0091552038156708, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint267, viewCenter267)
    
    scaleAboutPoint268 = NXOpen.Point3d(-92.66340777925906, 7.2764534954867468, 0.0)
    viewCenter268 = NXOpen.Point3d(92.663407779258776, -7.2764534954866074, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint268, viewCenter268)
    
    scaleAboutPoint269 = NXOpen.Point3d(-115.82925972407384, 8.5386954283772916, 0.0)
    viewCenter269 = NXOpen.Point3d(115.82925972407348, -8.5386954283771495, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint269, viewCenter269)
    
    scaleAboutPoint270 = NXOpen.Point3d(-147.8029616270733, 12.065547887924424, 0.0)
    viewCenter270 = NXOpen.Point3d(147.80296162707296, -12.065547887924266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint270, viewCenter270)
    
    scaleAboutPoint271 = NXOpen.Point3d(-118.24236930165871, 9.652438310339555, 0.0)
    viewCenter271 = NXOpen.Point3d(118.24236930165836, -9.6524383103394129, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint271, viewCenter271)
    
    scaleAboutPoint272 = NXOpen.Point3d(-94.593895441326964, 7.721950648271644, 0.0)
    viewCenter272 = NXOpen.Point3d(94.593895441326666, -7.7219506482715046, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint272, viewCenter272)
    
    scaleAboutPoint273 = NXOpen.Point3d(-75.675116353061625, 6.1775605186173355, 0.0)
    viewCenter273 = NXOpen.Point3d(75.675116353061298, -6.1775605186171942, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint273, viewCenter273)
    
    scaleAboutPoint274 = NXOpen.Point3d(-60.540093082449332, 4.9420484148938773, 0.0)
    viewCenter274 = NXOpen.Point3d(60.540093082449012, -4.9420484148937396, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint274, viewCenter274)
    
    scaleAboutPoint275 = NXOpen.Point3d(-49.952704747465283, 11.556790139444058, 0.0)
    viewCenter275 = NXOpen.Point3d(49.952704747464963, -11.556790139443908, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint275, viewCenter275)
    
    scaleAboutPoint276 = NXOpen.Point3d(-62.440880934331553, 14.445987674305062, 0.0)
    viewCenter276 = NXOpen.Point3d(62.440880934331226, -14.445987674304892, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint276, viewCenter276)
    
    scaleAboutPoint277 = NXOpen.Point3d(-78.051101167914382, 18.057484592881305, 0.0)
    viewCenter277 = NXOpen.Point3d(78.051101167914098, -18.057484592881142, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint277, viewCenter277)
    
    scaleAboutPoint278 = NXOpen.Point3d(-97.563876459892938, 22.571855741101597, 0.0)
    viewCenter278 = NXOpen.Point3d(97.563876459892654, -22.571855741101459, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint278, viewCenter278)
    
    scaleAboutPoint279 = NXOpen.Point3d(-132.53540295350751, 15.035528906490407, 0.0)
    viewCenter279 = NXOpen.Point3d(132.53540295350723, -15.035528906490265, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint279, viewCenter279)
    
    scaleAboutPoint280 = NXOpen.Point3d(-165.66925369188431, 18.794411133112991, 0.0)
    viewCenter280 = NXOpen.Point3d(165.66925369188402, -18.794411133112831, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint280, viewCenter280)
    
    scaleAboutPoint281 = NXOpen.Point3d(-207.08656711485534, 23.493013916391234, 0.0)
    viewCenter281 = NXOpen.Point3d(207.08656711485503, -23.49301391639106, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint281, viewCenter281)
    
    scaleAboutPoint282 = NXOpen.Point3d(-256.68292982723665, 31.178999950766112, 0.0)
    viewCenter282 = NXOpen.Point3d(256.68292982723631, -31.178999950765927, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint282, viewCenter282)
    
    scaleAboutPoint283 = NXOpen.Point3d(-205.63638107063366, 24.943199960612912, 0.0)
    viewCenter283 = NXOpen.Point3d(205.63638107063335, -24.943199960612716, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint283, viewCenter283)
    
    scaleAboutPoint284 = NXOpen.Point3d(-164.50910485650698, 19.954559968490351, 0.0)
    viewCenter284 = NXOpen.Point3d(164.50910485650664, -19.954559968490152, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint284, viewCenter284)
    
    scaleAboutPoint285 = NXOpen.Point3d(-131.60728388520567, 15.963647974792314, 0.0)
    viewCenter285 = NXOpen.Point3d(131.60728388520531, -15.963647974792108, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint285, viewCenter285)
    
    scaleAboutPoint286 = NXOpen.Point3d(-105.28582710816457, 12.770918379833851, 0.0)
    viewCenter286 = NXOpen.Point3d(105.28582710816421, -12.770918379833661, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint286, viewCenter286)
    
    scaleAboutPoint287 = NXOpen.Point3d(-83.87226396430377, 10.454333185352382, 0.0)
    viewCenter287 = NXOpen.Point3d(83.872263964303414, -10.454333185352201, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint287, viewCenter287)
    
    scaleAboutPoint288 = NXOpen.Point3d(-67.097811171443055, 8.3634665482819237, 0.0)
    viewCenter288 = NXOpen.Point3d(67.0978111714427, -8.3634665482817372, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint288, viewCenter288)
    
    scaleAboutPoint289 = NXOpen.Point3d(-53.678248937154478, 6.6907732386255594, 0.0)
    viewCenter289 = NXOpen.Point3d(53.678248937154137, -6.6907732386253773, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint289, viewCenter289)
    
    scaleAboutPoint290 = NXOpen.Point3d(-42.94259914972362, 5.3526185909004669, 0.0)
    viewCenter290 = NXOpen.Point3d(42.942599149723264, -5.3526185909002804, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint290, viewCenter290)
    
    scaleAboutPoint291 = NXOpen.Point3d(-34.354079319778926, 4.2820948727203945, 0.0)
    viewCenter291 = NXOpen.Point3d(34.354079319778585, -4.2820948727202079, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint291, viewCenter291)
    
    point1_34 = NXOpen.Point3d(-1.0329489919888848e-14, 100.0, 0.0)
    point2_34 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_34, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_34)
    
    point1_35 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    point2_35 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_35, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_35)
    
    point1_36 = NXOpen.Point3d(-1.0329489919888848e-14, 100.0, 0.0)
    point2_36 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_36, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_36)
    
    point1_37 = NXOpen.Point3d(15.30421888675815, 100.0, 0.0)
    point2_37 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc2, workPart.ModelingViews.WorkView, point1_37, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_37)
    
    point1_38 = NXOpen.Point3d(-1.0329489919888848e-14, 100.0, 0.0)
    point2_38 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder8.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Start, line2, workPart.ModelingViews.WorkView, point1_38, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_38)
    
    dimensionlinearunits317 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits318 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits319 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits320 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits321 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits322 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits323 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits324 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits325 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits326 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits327 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits328 = sketchRapidDimensionBuilder8.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin8 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin8.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin8.View = NXOpen.View.Null
    assocOrigin8.ViewOfGeometry = workPart.ModelingViews.WorkView
    point40 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin8.PointOnGeometry = point40
    assocOrigin8.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.DimensionLine = 0
    assocOrigin8.AssociatedView = NXOpen.View.Null
    assocOrigin8.AssociatedPoint = NXOpen.Point.Null
    assocOrigin8.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin8.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin8.XOffsetFactor = 0.0
    assocOrigin8.YOffsetFactor = 0.0
    assocOrigin8.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder8.Origin.SetAssociativeOrigin(assocOrigin8)
    
    point41 = NXOpen.Point3d(5.3453564230547208, 100.0, -1.7834402664798992)
    sketchRapidDimensionBuilder8.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point41)
    
    sketchRapidDimensionBuilder8.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder8.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Right
    
    sketchRapidDimensionBuilder8.Style.DimensionStyle.TextCentered = False
    
    markId206 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject29 = sketchRapidDimensionBuilder8.Commit()
    
    theSession.DeleteUndoMark(markId206, None)
    
    theSession.SetUndoMarkName(markId205, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId205, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder8.Destroy()
    
    markId207 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder9 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines53 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBefore(lines53)
    
    lines54 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAfter(lines54)
    
    lines55 = []
    sketchRapidDimensionBuilder9.AppendedText.SetAbove(lines55)
    
    lines56 = []
    sketchRapidDimensionBuilder9.AppendedText.SetBelow(lines56)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder9.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId207, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder9.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits329 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits330 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits331 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits332 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits333 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits334 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits335 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits336 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits337 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits338 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder9.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits339 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits340 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits341 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits342 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits343 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits344 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits345 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits346 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits347 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits348 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    expression115 = workPart.Expressions.FindObject("p38")
    expression115.SetFormula("18")
    
    theSession.SetUndoMarkVisibility(markId207, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId208 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId208, None)
    
    markId209 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId207, "Edit Driving Value")
    
    scaleAboutPoint292 = NXOpen.Point3d(1.9464067603272313, 6.9292080667656712, 0.0)
    viewCenter292 = NXOpen.Point3d(-1.9464067603275765, -6.9292080667654847, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint292, viewCenter292)
    
    scaleAboutPoint293 = NXOpen.Point3d(1.2165042252044613, 7.9316075483342852, 0.0)
    viewCenter293 = NXOpen.Point3d(-1.2165042252048017, -7.9316075483340986, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint293, viewCenter293)
    
    scaleAboutPoint294 = NXOpen.Point3d(0.97320338016353458, 9.4887329565962073, 0.0)
    viewCenter294 = NXOpen.Point3d(-0.97320338016386654, -9.4887329565960208, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint294, viewCenter294)
    
    scaleAboutPoint295 = NXOpen.Point3d(1.1404727111291717, 11.860916195745229, 0.0)
    viewCenter295 = NXOpen.Point3d(-1.1404727111295088, -11.860916195745048, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint295, viewCenter295)
    
    scaleAboutPoint296 = NXOpen.Point3d(5.3222059852700649, 11.879924074264052, 0.0)
    viewCenter296 = NXOpen.Point3d(-5.3222059852703891, -11.879924074263872, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint296, viewCenter296)
    
    scaleAboutPoint297 = NXOpen.Point3d(8.4347460927272149, 13.424314203918366, 0.0)
    viewCenter297 = NXOpen.Point3d(-8.4347460927275399, -13.424314203918184, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint297, viewCenter297)
    
    scaleAboutPoint298 = NXOpen.Point3d(12.622419328905297, 15.88939844932815, 0.0)
    viewCenter298 = NXOpen.Point3d(-12.6224193289056, -15.889398449327972, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint298, viewCenter298)
    
    scaleAboutPoint299 = NXOpen.Point3d(18.562381366037236, 19.490500434339403, 0.0)
    viewCenter299 = NXOpen.Point3d(-18.562381366037616, -19.490500434339229, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint299, viewCenter299)
    
    scaleAboutPoint300 = NXOpen.Point3d(29.00372088443331, 24.131095775848749, 0.0)
    viewCenter300 = NXOpen.Point3d(-29.003720884433648, -24.131095775848593, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint300, viewCenter300)
    
    scaleAboutPoint301 = NXOpen.Point3d(97.742539380540663, 41.185283655895645, 0.0)
    viewCenter301 = NXOpen.Point3d(-97.742539380541061, -41.185283655895475, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint301, viewCenter301)
    
    scaleAboutPoint302 = NXOpen.Point3d(79.354180339809901, 32.716197157641069, 0.0)
    viewCenter302 = NXOpen.Point3d(-79.354180339810256, -32.716197157640906, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint302, viewCenter302)
    
    scaleAboutPoint303 = NXOpen.Point3d(63.668968085508226, 25.987333912452534, 0.0)
    viewCenter303 = NXOpen.Point3d(-63.66896808550861, -25.987333912452328, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint303, viewCenter303)
    
    scaleAboutPoint304 = NXOpen.Point3d(51.083673519334852, 20.641368079033743, 0.0)
    viewCenter304 = NXOpen.Point3d(-51.083673519335221, -20.641368079033541, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint304, viewCenter304)
    
    scaleAboutPoint305 = NXOpen.Point3d(42.173730463636858, 15.919098259513802, 0.0)
    viewCenter305 = NXOpen.Point3d(-42.173730463637263, -15.919098259513621, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint305, viewCenter305)
    
    scaleAboutPoint306 = NXOpen.Point3d(37.445520682079817, 10.644411970540597, 0.0)
    viewCenter306 = NXOpen.Point3d(-37.445520682080193, -10.644411970540427, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint306, viewCenter306)
    
    scaleAboutPoint307 = NXOpen.Point3d(29.956416545663814, 8.5155295764324954, 0.0)
    viewCenter307 = NXOpen.Point3d(-29.956416545664201, -8.5155295764323267, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint307, viewCenter307)
    
    scaleAboutPoint308 = NXOpen.Point3d(23.965133236531006, 6.8124236611460116, 0.0)
    viewCenter308 = NXOpen.Point3d(-23.9651332365314, -6.8124236611458411, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint308, viewCenter308)
    
    scaleAboutPoint309 = NXOpen.Point3d(19.17210658922475, 5.4499389289168239, 0.0)
    viewCenter309 = NXOpen.Point3d(-19.172106589225166, -5.4499389289166587, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint309, viewCenter309)
    
    point1_39 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    point2_39 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_39, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_39)
    
    point1_40 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    point2_40 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, arc3, workPart.ModelingViews.WorkView, point1_40, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_40)
    
    point1_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_41 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_41, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_41)
    
    dimensionlinearunits349 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits350 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits351 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits352 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits353 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits354 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    point42 = NXOpen.Point3d(99.999999999999986, 100.0, 1.3607375637775878)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(edge2, workPart.ModelingViews.WorkView, point42)
    
    point1_42 = NXOpen.Point3d(99.999999999999986, 100.0, 1.3607375637775878)
    point2_42 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge2, workPart.ModelingViews.WorkView, point1_42, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_42)
    
    point1_43 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    point2_43 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_43, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_43)
    
    point1_44 = NXOpen.Point3d(99.999999999999986, 100.0, 1.3607375637775878)
    point2_44 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, edge2, workPart.ModelingViews.WorkView, point1_44, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_44)
    
    point1_45 = NXOpen.Point3d(91.929729165760733, 100.0, 0.0)
    point2_45 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder9.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.Center, arc3, workPart.ModelingViews.WorkView, point1_45, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_45)
    
    dimensionlinearunits355 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits356 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits357 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits358 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits359 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits360 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits361 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits362 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits363 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits364 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits365 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits366 = sketchRapidDimensionBuilder9.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometryFromLeader(True)
    
    assocOrigin9 = NXOpen.Annotations.Annotation.AssociativeOriginData()
    
    assocOrigin9.OriginType = NXOpen.Annotations.AssociativeOriginType.RelativeToGeometry
    assocOrigin9.View = NXOpen.View.Null
    assocOrigin9.ViewOfGeometry = workPart.ModelingViews.WorkView
    point43 = workPart.Points.FindObject("ENTITY 2 2")
    assocOrigin9.PointOnGeometry = point43
    assocOrigin9.VertAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.VertAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.HorizAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.HorizAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.AlignedAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.DimensionLine = 0
    assocOrigin9.AssociatedView = NXOpen.View.Null
    assocOrigin9.AssociatedPoint = NXOpen.Point.Null
    assocOrigin9.OffsetAnnotation = NXOpen.Annotations.Annotation.Null
    assocOrigin9.OffsetAlignmentPosition = NXOpen.Annotations.AlignmentPosition.TopLeft
    assocOrigin9.XOffsetFactor = 0.0
    assocOrigin9.YOffsetFactor = 0.0
    assocOrigin9.StackAlignmentPosition = NXOpen.Annotations.StackAlignmentPosition.Above
    sketchRapidDimensionBuilder9.Origin.SetAssociativeOrigin(assocOrigin9)
    
    point44 = NXOpen.Point3d(97.575607320660737, 100.0, -1.8702976583659092)
    sketchRapidDimensionBuilder9.Origin.Origin.SetValue(NXOpen.TaggedObject.Null, NXOpen.View.Null, point44)
    
    sketchRapidDimensionBuilder9.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder9.Style.LineArrowStyle.LeaderOrientation = NXOpen.Annotations.LeaderSide.Left
    
    sketchRapidDimensionBuilder9.Style.DimensionStyle.TextCentered = False
    
    markId210 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    nXObject30 = sketchRapidDimensionBuilder9.Commit()
    
    theSession.DeleteUndoMark(markId210, None)
    
    theSession.SetUndoMarkName(markId209, "Rapid Dimension")
    
    theSession.SetUndoMarkVisibility(markId209, None, NXOpen.Session.MarkVisibility.Visible)
    
    sketchRapidDimensionBuilder9.Destroy()
    
    markId211 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Start")
    
    sketchRapidDimensionBuilder10 = workPart.Sketches.CreateRapidDimensionBuilder()
    
    lines57 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBefore(lines57)
    
    lines58 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAfter(lines58)
    
    lines59 = []
    sketchRapidDimensionBuilder10.AppendedText.SetAbove(lines59)
    
    lines60 = []
    sketchRapidDimensionBuilder10.AppendedText.SetBelow(lines60)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.Anchor = NXOpen.Annotations.OriginBuilder.AlignmentPosition.MidCenter
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitDeviation = "H"
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.LimitFitShaftDeviation = "g"
    
    sketchRapidDimensionBuilder10.Driving.DrivingMethod = NXOpen.Annotations.DrivingValueBuilder.DrivingValueMethod.Driving
    
    theSession.SetUndoMarkName(markId211, "Rapid Dimension Dialog")
    
    sketchRapidDimensionBuilder10.Origin.Plane.PlaneMethod = NXOpen.Annotations.PlaneBuilder.PlaneMethodType.XyPlane
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    dimensionlinearunits367 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits368 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits369 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits370 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits371 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits372 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits373 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits374 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits375 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits376 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Origin.SetInferRelativeToGeometry(True)
    
    sketchRapidDimensionBuilder10.Measurement.Direction = NXOpen.Direction.Null
    
    sketchRapidDimensionBuilder10.Measurement.DirectionView = NXOpen.View.Null
    
    sketchRapidDimensionBuilder10.Style.DimensionStyle.NarrowDisplayType = NXOpen.Annotations.NarrowDisplayOption.NotSet
    
    dimensionlinearunits377 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits378 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits379 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits380 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits381 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits382 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits383 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits384 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits385 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    dimensionlinearunits386 = sketchRapidDimensionBuilder10.Style.UnitsStyle.DimensionLinearUnits
    
    expression116 = workPart.Expressions.FindObject("p39")
    expression116.SetFormula("10")
    
    theSession.SetUndoMarkVisibility(markId211, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId212 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId212, None)
    
    markId213 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId211, "Edit Driving Value")
    
    scaleAboutPoint310 = NXOpen.Point3d(6.3063579034605866, 8.135980258168642, 0.0)
    viewCenter310 = NXOpen.Point3d(-6.3063579034610111, -8.1359802581684857, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint310, viewCenter310)
    
    scaleAboutPoint311 = NXOpen.Point3d(7.5423261962684691, 9.7806939706452933, 0.0)
    viewCenter311 = NXOpen.Point3d(-7.5423261962689212, -9.780693970645137, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint311, viewCenter311)
    
    scaleAboutPoint312 = NXOpen.Point3d(9.1237816890344874, 11.982566618265672, 0.0)
    viewCenter312 = NXOpen.Point3d(-9.1237816890349439, -11.982566618265516, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint312, viewCenter312)
    
    scaleAboutPoint313 = NXOpen.Point3d(11.328695597217877, 14.902176758756783, 0.0)
    viewCenter313 = NXOpen.Point3d(-11.328695597218324, -14.902176758756626, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint313, viewCenter313)
    
    perpendicularDimension2 = nXObject30
    point45 = NXOpen.Point3d(97.315731605551377, 200.0, -1.6130070147351345)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(perpendicularDimension2, workPart.ModelingViews.WorkView, point45)
    
    line29 = theSession.ActiveSketch.FindObject("Curve EDGE12")
    point1_46 = NXOpen.Point3d(99.999999999999986, 100.0, 1.3607375637775867)
    point2_46 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.FirstAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, line29, NXOpen.View.Null, point1_46, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_46)
    
    point1_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    point2_47 = NXOpen.Point3d(0.0, 0.0, 0.0)
    sketchRapidDimensionBuilder10.SecondAssociativity.SetValue(NXOpen.InferSnapType.SnapType.NotSet, NXOpen.TaggedObject.Null, workPart.ModelingViews.WorkView, point1_47, NXOpen.TaggedObject.Null, NXOpen.View.Null, point2_47)
    
    sketchRapidDimensionBuilder10.FirstAssociativity.Value = NXOpen.TaggedObject.Null
    
    expression116.SetFormula("8")
    
    theSession.SetUndoMarkVisibility(markId213, None, NXOpen.Session.MarkVisibility.Visible)
    
    markId214 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.ActiveSketch.LocalUpdate()
    
    theSession.DeleteUndoMark(markId214, None)
    
    markId215 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Rapid Dimension")
    
    theSession.SetUndoMarkName(markId213, "Edit Driving Value")
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    sketchRapidDimensionBuilder10.Destroy()
    
    theSession.UndoToMark(markId215, None)
    
    theSession.DeleteUndoMark(markId215, None)
    
    sketchRapidDimensionBuilder10.Destroy()
    
    markId216 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder9 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section9 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder9.Section = section9
    
    extrudeBuilder9.AllowSelfIntersectingSection(True)
    
    expression117 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder9.DistanceTolerance = 0.01
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies21 = [NXOpen.Body.Null] * 1 
    targetBodies21[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies21)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("-100")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies22 = [NXOpen.Body.Null] * 1 
    targetBodies22[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies22)
    
    extrudeBuilder9.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder9.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder9.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder9 = extrudeBuilder9.SmartVolumeProfile
    
    smartVolumeProfileBuilder9.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder9.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId216, "Extrude Dialog")
    
    section9.DistanceTolerance = 0.01
    
    section9.ChainingTolerance = 0.0094999999999999998
    
    section9.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId217 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves14 = [NXOpen.ICurve.Null] * 2 
    curves14[0] = arc2
    curves14[1] = arc3
    seedPoint14 = NXOpen.Point3d(92.8333333333333, 100.0, 6.1293562817847361e-17)
    regionBoundaryRule14 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves14, seedPoint14, 0.01)
    
    curves15 = [NXOpen.ICurve.Null] * 2 
    curves15[0] = arc2
    curves15[1] = arc3
    seedPoint15 = NXOpen.Point3d(17.999999999999982, 100.0, 0.83333333333332982)
    regionBoundaryRule15 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves15, seedPoint15, 0.01)
    
    section9.AllowSelfIntersection(True)
    
    rules17 = [None] * 2 
    rules17[0] = regionBoundaryRule14
    rules17[1] = regionBoundaryRule15
    helpPoint17 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section9.AddToSection(rules17, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint17, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId217, None)
    
    markId218 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId219 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId219, None)
    
    direction23 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction23
    
    expression118 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression119 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId218, None)
    
    extrudeBuilder9.Limits.StartExtend.Value.SetFormula("10")
    
    markId220 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId221 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    section9.Clear()
    
    theSession.DeleteUndoMark(markId221, None)
    
    workPart.Expressions.Delete(expression118)
    
    workPart.Expressions.Delete(expression119)
    
    theSession.DeleteUndoMark(markId220, None)
    
    rotMatrix26 = NXOpen.Matrix3x3()
    
    rotMatrix26.Xx = 0.99993329980345125
    rotMatrix26.Xy = 0.0055032310782426362
    rotMatrix26.Xz = 0.010154328726253681
    rotMatrix26.Yx = -7.3472390406095649e-17
    rotMatrix26.Yy = -0.87918426348778811
    rotMatrix26.Yz = 0.47648193127907379
    rotMatrix26.Zx = 0.011549716194840298
    rotMatrix26.Zy = -0.47645014984060552
    rotMatrix26.Zz = -0.87912562172461095
    translation26 = NXOpen.Point3d(-88.945542580591393, 48.106472677862939, -18.18082779471569)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix26, translation26, 2.7839333366039019)
    
    extrudeBuilder9.Limits.EndExtend.Value.SetFormula("-120")
    
    extrudeBuilder9.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies23 = [NXOpen.Body.Null] * 1 
    targetBodies23[0] = NXOpen.Body.Null
    extrudeBuilder9.BooleanOperation.SetTargetBodies(targetBodies23)
    
    scaleAboutPoint314 = NXOpen.Point3d(-48.47009022299715, -8.933702903846406, 0.0)
    viewCenter314 = NXOpen.Point3d(48.47009022299671, 8.9337029038465676, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint314, viewCenter314)
    
    scaleAboutPoint315 = NXOpen.Point3d(-38.776072178397762, -7.1469623230770987, 0.0)
    viewCenter315 = NXOpen.Point3d(38.776072178397321, 7.1469623230772736, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint315, viewCenter315)
    
    scaleAboutPoint316 = NXOpen.Point3d(-31.020857742718245, -5.7175698584616628, 0.0)
    viewCenter316 = NXOpen.Point3d(31.020857742717812, 5.7175698584618386, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint316, viewCenter316)
    
    scaleAboutPoint317 = NXOpen.Point3d(-24.816686194174647, -4.5740558867693091, 0.0)
    viewCenter317 = NXOpen.Point3d(24.816686194174199, 4.574055886769492, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint317, viewCenter317)
    
    scaleAboutPoint318 = NXOpen.Point3d(-19.853348955339751, -3.659244709415431, 0.0)
    viewCenter318 = NXOpen.Point3d(19.853348955339314, 3.65924470941561, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint318, viewCenter318)
    
    scaleAboutPoint319 = NXOpen.Point3d(-15.508969066288985, -3.1142508165237568, 0.0)
    viewCenter319 = NXOpen.Point3d(15.50896906628855, 3.1142508165239402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint319, viewCenter319)
    
    scaleAboutPoint320 = NXOpen.Point3d(-19.386211332861173, -3.9317416558612663, 0.0)
    viewCenter320 = NXOpen.Point3d(19.386211332860753, 3.9317416558614524, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint320, viewCenter320)
    
    scaleAboutPoint321 = NXOpen.Point3d(-24.232764166076411, -4.9146770698266078, 0.0)
    viewCenter321 = NXOpen.Point3d(24.232764166075988, 4.9146770698267899, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint321, viewCenter321)
    
    scaleAboutPoint322 = NXOpen.Point3d(-30.290955207595452, -6.1433463372832797, 0.0)
    viewCenter322 = NXOpen.Point3d(30.290955207595047, 6.1433463372834671, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint322, viewCenter322)
    
    scaleAboutPoint323 = NXOpen.Point3d(-37.863694009494267, -7.6791829216041192, 0.0)
    viewCenter323 = NXOpen.Point3d(37.863694009493848, 7.6791829216043208, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint323, viewCenter323)
    
    scaleAboutPoint324 = NXOpen.Point3d(-47.329617511867781, -9.5989786520051705, 0.0)
    viewCenter324 = NXOpen.Point3d(47.329617511867362, 9.598978652005373, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint324, viewCenter324)
    
    scaleAboutPoint325 = NXOpen.Point3d(-59.162021889834691, -11.998723315006485, 0.0)
    viewCenter325 = NXOpen.Point3d(59.162021889834243, 11.998723315006687, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint325, viewCenter325)
    
    scaleAboutPoint326 = NXOpen.Point3d(-73.952527362293281, -14.99840414375813, 0.0)
    viewCenter326 = NXOpen.Point3d(73.952527362292884, 14.99840414375832, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint326, viewCenter326)
    
    scaleAboutPoint327 = NXOpen.Point3d(-92.440659202866541, -18.748005179697696, 0.0)
    viewCenter327 = NXOpen.Point3d(92.440659202866172, 18.74800517969787, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint327, viewCenter327)
    
    scaleAboutPoint328 = NXOpen.Point3d(-115.31879423650766, -23.435006474622138, 0.0)
    viewCenter328 = NXOpen.Point3d(115.31879423650734, 23.435006474622337, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint328, viewCenter328)
    
    scaleAboutPoint329 = NXOpen.Point3d(-144.1484927956345, -29.293758093277695, 0.0)
    viewCenter329 = NXOpen.Point3d(144.14849279563418, 29.293758093277866, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint329, viewCenter329)
    
    rotMatrix27 = NXOpen.Matrix3x3()
    
    rotMatrix27.Xx = 0.68923960817694863
    rotMatrix27.Xy = 0.35994825348699699
    rotMatrix27.Xz = 0.62879727840675914
    rotMatrix27.Yx = 0.61945180964396118
    rotMatrix27.Yy = -0.742899819556888
    rotMatrix27.Yz = -0.25373078967907198
    rotMatrix27.Zx = 0.37580343006538508
    rotMatrix27.Zy = 0.56439092206909558
    rotMatrix27.Zz = -0.73500657754681897
    translation27 = NXOpen.Point3d(-159.56276609375368, -148.27948269728711, -169.83100514174686)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix27, translation27, 0.72979142059069368)
    
    scaleAboutPoint330 = NXOpen.Point3d(-87.373709164356029, -49.668872014592218, 0.0)
    viewCenter330 = NXOpen.Point3d(87.37370916435566, 49.668872014592402, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint330, viewCenter330)
    
    scaleAboutPoint331 = NXOpen.Point3d(-108.31077017780643, -64.352005712336663, 0.0)
    viewCenter331 = NXOpen.Point3d(108.31077017780608, 64.352005712336862, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint331, viewCenter331)
    
    scaleAboutPoint332 = NXOpen.Point3d(-86.648616142245203, -51.481604569869297, 0.0)
    viewCenter332 = NXOpen.Point3d(86.648616142244833, 51.481604569869482, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint332, viewCenter332)
    
    scaleAboutPoint333 = NXOpen.Point3d(-69.318892913796219, -41.185283655895439, 0.0)
    viewCenter333 = NXOpen.Point3d(69.318892913795821, 41.185283655895589, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint333, viewCenter333)
    
    scaleAboutPoint334 = NXOpen.Point3d(-55.455114331036981, -32.948226924716337, 0.0)
    viewCenter334 = NXOpen.Point3d(55.45511433103664, 32.948226924716515, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint334, viewCenter334)
    
    scaleAboutPoint335 = NXOpen.Point3d(-44.364091464829642, -26.35858153977307, 0.0)
    viewCenter335 = NXOpen.Point3d(44.364091464829293, 26.358581539773194, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint335, viewCenter335)
    
    scaleAboutPoint336 = NXOpen.Point3d(-35.491273171863718, -21.086865231818443, 0.0)
    viewCenter336 = NXOpen.Point3d(35.491273171863398, 21.086865231818571, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint336, viewCenter336)
    
    scaleAboutPoint337 = NXOpen.Point3d(-24.353844352241286, -21.977859537388255, 0.0)
    viewCenter337 = NXOpen.Point3d(24.353844352240941, 21.977859537388358, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint337, viewCenter337)
    
    scaleAboutPoint338 = NXOpen.Point3d(-30.442305440301553, -27.76932252359191, 0.0)
    viewCenter338 = NXOpen.Point3d(30.442305440301197, 27.769322523592038, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint338, viewCenter338)
    
    scaleAboutPoint339 = NXOpen.Point3d(-38.052881800376916, -34.711653154489909, 0.0)
    viewCenter339 = NXOpen.Point3d(38.052881800376568, 34.711653154490037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint339, viewCenter339)
    
    scaleAboutPoint340 = NXOpen.Point3d(-47.566102250471069, -43.389566443112386, 0.0)
    viewCenter340 = NXOpen.Point3d(47.566102250470728, 43.38956644311255, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint340, viewCenter340)
    
    scaleAboutPoint341 = NXOpen.Point3d(-59.457627813088827, -54.236958053890504, 0.0)
    viewCenter341 = NXOpen.Point3d(59.457627813088429, 54.236958053890653, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint341, viewCenter341)
    
    scaleAboutPoint342 = NXOpen.Point3d(-74.322034766360972, -68.15874407841855, 0.0)
    viewCenter342 = NXOpen.Point3d(74.322034766360588, 68.158744078418735, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint342, viewCenter342)
    
    scaleAboutPoint343 = NXOpen.Point3d(-92.90254345795114, -85.198430098023238, 0.0)
    viewCenter343 = NXOpen.Point3d(92.902543457950785, 85.198430098023422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint343, viewCenter343)
    
    scaleAboutPoint344 = NXOpen.Point3d(-116.12817932243891, -106.49803762252904, 0.0)
    viewCenter344 = NXOpen.Point3d(116.12817932243853, 106.49803762252924, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint344, viewCenter344)
    
    scaleAboutPoint345 = NXOpen.Point3d(-145.1602241530486, -133.12254702816134, 0.0)
    viewCenter345 = NXOpen.Point3d(145.16022415304812, 133.12254702816145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint345, viewCenter345)
    
    scaleAboutPoint346 = NXOpen.Point3d(-181.45028019131058, -166.40318378520166, 0.0)
    viewCenter346 = NXOpen.Point3d(181.45028019131021, 166.4031837852018, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint346, viewCenter346)
    
    scaleAboutPoint347 = NXOpen.Point3d(-226.81285023913824, -208.00397973150214, 0.0)
    viewCenter347 = NXOpen.Point3d(226.81285023913776, 208.00397973150226, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint347, viewCenter347)
    
    scaleAboutPoint348 = NXOpen.Point3d(-246.17492282052814, -406.60352420918645, 0.0)
    viewCenter348 = NXOpen.Point3d(246.17492282052766, 406.60352420918656, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint348, viewCenter348)
    
    scaleAboutPoint349 = NXOpen.Point3d(-307.71865352566016, -522.08445710533272, 0.0)
    viewCenter349 = NXOpen.Point3d(307.71865352565959, 522.08445710533306, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint349, viewCenter349)
    
    scaleAboutPoint350 = NXOpen.Point3d(-384.64831690707524, -676.37597298828291, 0.0)
    viewCenter350 = NXOpen.Point3d(384.6483169070745, 676.37597298828325, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint350, viewCenter350)
    
    scaleAboutPoint351 = NXOpen.Point3d(-480.81039613384348, -872.48178624287289, 0.0)
    viewCenter351 = NXOpen.Point3d(480.81039613384348, 872.48178624287334, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint351, viewCenter351)
    
    scaleAboutPoint352 = NXOpen.Point3d(-601.01299516730444, -1124.3670078129903, 0.0)
    viewCenter352 = NXOpen.Point3d(601.01299516730444, 1124.367007812991, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint352, viewCenter352)
    
    scaleAboutPoint353 = NXOpen.Point3d(-480.81039613384399, -899.4936062503923, 0.0)
    viewCenter353 = NXOpen.Point3d(480.81039613384303, 899.49360625039276, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint353, viewCenter353)
    
    scaleAboutPoint354 = NXOpen.Point3d(-384.64831690707553, -719.59488500031375, 0.0)
    viewCenter354 = NXOpen.Point3d(384.64831690707405, 719.59488500031421, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint354, viewCenter354)
    
    scaleAboutPoint355 = NXOpen.Point3d(-307.71865352566039, -575.67590800025096, 0.0)
    viewCenter355 = NXOpen.Point3d(307.71865352565908, 575.67590800025141, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint355, viewCenter355)
    
    scaleAboutPoint356 = NXOpen.Point3d(-246.17492282052862, -460.54072640020075, 0.0)
    viewCenter356 = NXOpen.Point3d(246.1749228205272, 460.54072640020121, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint356, viewCenter356)
    
    scaleAboutPoint357 = NXOpen.Point3d(-213.53600046904279, -349.6237106125248, 0.0)
    viewCenter357 = NXOpen.Point3d(213.53600046904157, 349.62371061252526, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint357, viewCenter357)
    
    scaleAboutPoint358 = NXOpen.Point3d(-173.48417032925354, -277.04359853600056, 0.0)
    viewCenter358 = NXOpen.Point3d(173.48417032925235, 277.04359853600101, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint358, viewCenter358)
    
    scaleAboutPoint359 = NXOpen.Point3d(-140.20353357221316, -220.21868151999016, 0.0)
    viewCenter359 = NXOpen.Point3d(140.20353357221194, 220.21868151999064, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint359, viewCenter359)
    
    scaleAboutPoint360 = NXOpen.Point3d(-112.16282685777061, -175.60846629246797, 0.0)
    viewCenter360 = NXOpen.Point3d(112.16282685776946, 175.60846629246845, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint360, viewCenter360)
    
    scaleAboutPoint361 = NXOpen.Point3d(-90.183444625035861, -139.5804067563358, 0.0)
    viewCenter361 = NXOpen.Point3d(90.183444625034781, 139.58040675633623, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint361, viewCenter361)
    
    rotMatrix28 = NXOpen.Matrix3x3()
    
    rotMatrix28.Xx = 0.6794969752244584
    rotMatrix28.Xy = 0.25004085482162858
    rotMatrix28.Xz = 0.68975606672278189
    rotMatrix28.Yx = 0.72526980663268392
    rotMatrix28.Yy = -0.08699511042093637
    rotMatrix28.Yz = -0.68294623386460007
    rotMatrix28.Zx = -0.11075905492465703
    rotMatrix28.Zy = 0.96431914928768336
    rotMatrix28.Zz = -0.24045999681709807
    translation28 = NXOpen.Point3d(-157.82590531643663, -39.834445866265682, -61.90147134913957)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix28, translation28, 0.72979142059069402)
    
    scaleAboutPoint362 = NXOpen.Point3d(-93.899546363353906, 13.776767420106149, 0.0)
    viewCenter362 = NXOpen.Point3d(93.899546363352769, -13.776767420105715, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint362, viewCenter362)
    
    scaleAboutPoint363 = NXOpen.Point3d(-114.65533412127661, 17.220959275132611, 0.0)
    viewCenter363 = NXOpen.Point3d(114.65533412127549, -17.220959275132145, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint363, viewCenter363)
    
    scaleAboutPoint364 = NXOpen.Point3d(-143.31916765159565, 21.526199093915761, 0.0)
    viewCenter364 = NXOpen.Point3d(143.31916765159448, -21.526199093915228, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint364, viewCenter364)
    
    scaleAboutPoint365 = NXOpen.Point3d(-178.4408609100893, 26.907748867394581, 0.0)
    viewCenter365 = NXOpen.Point3d(178.44086091008811, -26.907748867394037, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint365, viewCenter365)
    
    scaleAboutPoint366 = NXOpen.Point3d(-223.05107613761149, 32.749562766236849, 0.0)
    viewCenter366 = NXOpen.Point3d(223.05107613761029, -32.749562766236245, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint366, viewCenter366)
    
    scaleAboutPoint367 = NXOpen.Point3d(-277.70744102450629, 40.936953457795966, 0.0)
    viewCenter367 = NXOpen.Point3d(277.70744102450504, -40.936953457795404, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint367, viewCenter367)
    
    scaleAboutPoint368 = NXOpen.Point3d(-345.75129609624776, 48.405181453474952, 0.0)
    viewCenter368 = NXOpen.Point3d(345.75129609624634, -48.405181453474242, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint368, viewCenter368)
    
    scaleAboutPoint369 = NXOpen.Point3d(-423.54533771790324, 43.218912012031218, 0.0)
    viewCenter369 = NXOpen.Point3d(423.5453377179021, -43.218912012030479, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint369, viewCenter369)
    
    scaleAboutPoint370 = NXOpen.Point3d(-338.83627017432309, 34.575129609625094, 0.0)
    viewCenter370 = NXOpen.Point3d(338.83627017432121, -34.575129609624383, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint370, viewCenter370)
    
    scaleAboutPoint371 = NXOpen.Point3d(-271.06901613945854, 27.660103687700079, 0.0)
    viewCenter371 = NXOpen.Point3d(271.06901613945683, -27.660103687699422, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint371, viewCenter371)
    
    scaleAboutPoint372 = NXOpen.Point3d(-216.85521291156709, 22.128082950160213, 0.0)
    viewCenter372 = NXOpen.Point3d(216.8552129115653, -22.128082950159534, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint372, viewCenter372)
    
    scaleAboutPoint373 = NXOpen.Point3d(-173.48417032925391, 17.70246636012811, 0.0)
    viewCenter373 = NXOpen.Point3d(173.48417032925192, -17.702466360127566, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint373, viewCenter373)
    
    scaleAboutPoint374 = NXOpen.Point3d(-138.78733626340352, 14.161973088102583, 0.0)
    viewCenter374 = NXOpen.Point3d(138.7873362634013, -14.161973088102004, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint374, viewCenter374)
    
    scaleAboutPoint375 = NXOpen.Point3d(-113.29578470481933, 15.861409858674829, 0.0)
    viewCenter375 = NXOpen.Point3d(113.29578470481717, -15.86140985867425, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint375, viewCenter375)
    
    scaleAboutPoint376 = NXOpen.Point3d(-90.99917427491107, 14.139313931161592, 0.0)
    viewCenter376 = NXOpen.Point3d(90.999174274908938, -14.139313931161036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint376, viewCenter376)
    
    scaleAboutPoint377 = NXOpen.Point3d(-73.089376628773422, 12.471599980306671, 0.0)
    viewCenter377 = NXOpen.Point3d(73.089376628771248, -12.471599980306102, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint377, viewCenter377)
    
    scaleAboutPoint378 = NXOpen.Point3d(-58.93556083716993, 10.441339518396326, 0.0)
    viewCenter378 = NXOpen.Point3d(58.935560837167692, -10.441339518395752, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint378, viewCenter378)
    
    scaleAboutPoint379 = NXOpen.Point3d(-47.334072483396518, 9.2811906830189965, 0.0)
    viewCenter379 = NXOpen.Point3d(47.334072483394309, -9.2811906830184423, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint379, viewCenter379)
    
    scaleAboutPoint380 = NXOpen.Point3d(-38.164256088574028, 8.4644459029133294, 0.0)
    viewCenter380 = NXOpen.Point3d(38.164256088571825, -8.4644459029127841, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint380, viewCenter380)
    
    markId222 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId223 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    features4 = [NXOpen.Features.Feature.Null] * 1 
    sketchFeature4 = feature15
    features4[0] = sketchFeature4
    curveFeatureRule4 = workPart.ScRuleFactory.CreateRuleCurveFeature(features4)
    
    section9.AllowSelfIntersection(True)
    
    rules18 = [None] * 1 
    rules18[0] = curveFeatureRule4
    helpPoint18 = NXOpen.Point3d(94.236557254664106, 100.0, -1.1041099667383372)
    section9.AddToSection(rules18, arc3, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint18, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId223, None)
    
    direction24 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder9.Direction = direction24
    
    expression120 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression121 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId222, None)
    
    markId224 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId224, None)
    
    markId225 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder9.ParentFeatureInternal = False
    
    markId226 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature16 = extrudeBuilder9.CommitFeature()
    
    theSession.DeleteUndoMark(markId225, None)
    
    theSession.SetUndoMarkName(markId216, "Extrude")
    
    expression122 = extrudeBuilder9.Limits.StartExtend.Value
    expression123 = extrudeBuilder9.Limits.EndExtend.Value
    extrudeBuilder9.Destroy()
    
    workPart.Expressions.Delete(expression117)
    
    workPart.Expressions.Delete(expression120)
    
    workPart.Expressions.Delete(expression121)
    
    scaleAboutPoint381 = NXOpen.Point3d(-20.671067889220385, -6.415159000102248, 0.0)
    viewCenter381 = NXOpen.Point3d(20.671067889218154, 6.4151590001028049, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint381, viewCenter381)
    
    scaleAboutPoint382 = NXOpen.Point3d(-16.061657348405962, -5.1321272000817411, 0.0)
    viewCenter382 = NXOpen.Point3d(16.061657348403749, 5.1321272000823006, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint382, viewCenter382)
    
    scaleAboutPoint383 = NXOpen.Point3d(-8.9717186608852604, -2.1288823941078152, 0.0)
    viewCenter383 = NXOpen.Point3d(8.9717186608830044, 2.1288823941083792, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint383, viewCenter383)
    
    scaleAboutPoint384 = NXOpen.Point3d(-11.214648326106271, -2.5660636000407289, 0.0)
    viewCenter384 = NXOpen.Point3d(11.214648326104042, 2.566063600041288, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint384, viewCenter384)
    
    scaleAboutPoint385 = NXOpen.Point3d(-14.018310407632592, -3.2075795000509815, 0.0)
    viewCenter385 = NXOpen.Point3d(14.018310407630324, 3.2075795000515384, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint385, viewCenter385)
    
    scaleAboutPoint386 = NXOpen.Point3d(-17.374388958612155, -4.0094743750638022, 0.0)
    viewCenter386 = NXOpen.Point3d(17.374388958609874, 4.0094743750643715, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint386, viewCenter386)
    
    scaleAboutPoint387 = NXOpen.Point3d(-21.161114757283787, -4.0837239005279509, 0.0)
    viewCenter387 = NXOpen.Point3d(21.161114757281506, 4.0837239005285042, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint387, viewCenter387)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId227 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects2 = [NXOpen.DisplayableObject.Null] * 1 
    objects2[0] = sketch6
    theSession.DisplayManager.BlankObjects(objects2)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId228 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects3 = [NXOpen.DisplayableObject.Null] * 1 
    objects3[0] = sketch5
    theSession.DisplayManager.BlankObjects(objects3)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId229 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects4 = [NXOpen.DisplayableObject.Null] * 1 
    objects4[0] = sketch2
    theSession.DisplayManager.BlankObjects(objects4)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId230 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects5 = [NXOpen.DisplayableObject.Null] * 1 
    objects5[0] = sketch10
    theSession.DisplayManager.BlankObjects(objects5)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId231 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects6 = [NXOpen.DisplayableObject.Null] * 1 
    objects6[0] = sketch3
    theSession.DisplayManager.BlankObjects(objects6)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix29 = NXOpen.Matrix3x3()
    
    rotMatrix29.Xx = 0.73469756099529659
    rotMatrix29.Xy = 0.043492965892914695
    rotMatrix29.Xz = 0.67699915493699248
    rotMatrix29.Yx = 0.58121219528248802
    rotMatrix29.Yy = 0.47432216260546639
    rotMatrix29.Yz = -0.66121922999576166
    rotMatrix29.Zx = -0.34987408866973202
    rotMatrix29.Zy = 0.87927632060639171
    rotMatrix29.Zz = 0.32320469380628208
    translation29 = NXOpen.Point3d(-109.90766192490256, -53.82732790094834, -53.698567398603352)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix29, translation29, 1.1402990946729596)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId232 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects7 = [NXOpen.DisplayableObject.Null] * 1 
    objects7[0] = sketch7
    theSession.DisplayManager.BlankObjects(objects7)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch...
    # ----------------------------------------------
    markId233 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    sketchInPlaceBuilder11 = workPart.Sketches.CreateSketchInPlaceBuilder2(NXOpen.Sketch.Null)
    
    origin27 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal24 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane24 = workPart.Planes.CreatePlane(origin27, normal24, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.PlaneReference = plane24
    
    expression124 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression125 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    sketchAlongPathBuilder9 = workPart.Sketches.CreateSketchAlongPathBuilder(NXOpen.Sketch.Null)
    
    sketchAlongPathBuilder9.PlaneLocation.Expression.SetFormula("0")
    
    theSession.SetUndoMarkName(markId233, "Create Sketch Dialog")
    
    scalar17 = workPart.Scalars.CreateScalar(1.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point46 = workPart.Points.CreatePoint(edge14, scalar17, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    direction25 = workPart.Directions.CreateDirection(edge14, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    face6 = extrude4.FindObject("FACE 190 {(22.5,50,20) EXTRUDE(2)}")
    xform8 = workPart.Xforms.CreateXformByPlaneXDirPoint(face6, direction25, point46, NXOpen.SmartObject.UpdateOption.WithinModeling, 0.625, False, False)
    
    cartesianCoordinateSystem8 = workPart.CoordinateSystems.CreateCoordinateSystem(xform8, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    sketchInPlaceBuilder11.Csystem = cartesianCoordinateSystem8
    
    origin28 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal25 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane25 = workPart.Planes.CreatePlane(origin28, normal25, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane25.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom29 = [NXOpen.NXObject.Null] * 1 
    geom29[0] = face6
    plane25.SetGeometry(geom29)
    
    plane25.SetFlip(False)
    
    plane25.SetExpression(None)
    
    plane25.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane25.Evaluate()
    
    origin29 = NXOpen.Point3d(0.0, 0.0, 0.0)
    normal26 = NXOpen.Vector3d(0.0, 0.0, 1.0)
    plane26 = workPart.Planes.CreatePlane(origin29, normal26, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    expression126 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    expression127 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    plane26.SynchronizeToPlane(plane25)
    
    scalar18 = workPart.Scalars.CreateScalar(100.0, NXOpen.Scalar.DimensionalityType.NotSet, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    point47 = workPart.Points.CreatePoint(edge14, scalar18, NXOpen.PointCollection.PointOnCurveLocationOption.PercentParameter, NXOpen.Point.Null, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    plane26.SetMethod(NXOpen.PlaneTypes.MethodType.Coincident)
    
    geom30 = [NXOpen.NXObject.Null] * 1 
    geom30[0] = face6
    plane26.SetGeometry(geom30)
    
    plane26.SetAlternate(NXOpen.PlaneTypes.AlternateType.One)
    
    plane26.Evaluate()
    
    rotMatrix30 = NXOpen.Matrix3x3()
    
    rotMatrix30.Xx = 0.92054945996235293
    rotMatrix30.Xy = -0.29868609749795072
    rotMatrix30.Xz = 0.25174452709933498
    rotMatrix30.Yx = 0.36170462347476073
    rotMatrix30.Yy = 0.89513064295167322
    rotMatrix30.Yz = -0.26059719377980689
    rotMatrix30.Zx = -0.14750748157298574
    rotMatrix30.Zy = 0.33094976538800147
    rotMatrix30.Zz = 0.93204817239755666
    translation30 = NXOpen.Point3d(-98.151823485797991, -66.556149457594486, -53.087600580908244)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix30, translation30, 1.1402990946729596)
    
    markId234 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.DeleteUndoMark(markId234, None)
    
    markId235 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Sketch")
    
    theSession.Preferences.Sketch.CreateInferredConstraints = True
    
    theSession.Preferences.Sketch.ContinuousAutoDimensioning = True
    
    theSession.Preferences.Sketch.DimensionLabel = NXOpen.Preferences.SketchPreferences.DimensionLabelType.Expression
    
    theSession.Preferences.Sketch.TextSizeFixed = True
    
    theSession.Preferences.Sketch.FixedTextSize = 3.0
    
    theSession.Preferences.Sketch.DisplayParenthesesOnReferenceDimensions = True
    
    theSession.Preferences.Sketch.DisplayReferenceGeometry = False
    
    theSession.Preferences.Sketch.ConstraintSymbolSize = 3.0
    
    theSession.Preferences.Sketch.DisplayObjectColor = False
    
    theSession.Preferences.Sketch.DisplayObjectName = True
    
    nXObject31 = sketchInPlaceBuilder11.Commit()
    
    sketch11 = nXObject31
    feature17 = sketch11.Feature
    
    markId236 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "update")
    
    nErrs11 = theSession.UpdateManager.DoUpdate(markId236)
    
    sketch11.Activate(NXOpen.Sketch.ViewReorient.TrueValue)
    
    theSession.DeleteUndoMark(markId235, None)
    
    theSession.SetUndoMarkName(markId233, "Create Sketch")
    
    sketchInPlaceBuilder11.Destroy()
    
    sketchAlongPathBuilder9.Destroy()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression125)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    workPart.Points.DeletePoint(point47)
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression124)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane24.DestroyPlane()
    
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression127)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    try:
        # Expression is still in use.
        workPart.Expressions.Delete(expression126)
    except NXOpen.NXException as ex:
        ex.AssertErrorCode(1050029)
        
    plane26.DestroyPlane()
    
    # ----------------------------------------------
    #   Menu: Insert->Sketch Curve->Rectangle...
    # ----------------------------------------------
    markId237 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    scaleAboutPoint388 = NXOpen.Point3d(41.301298539432125, 35.268524595471348, 0.0)
    viewCenter388 = NXOpen.Point3d(-41.301298539434342, -35.268524595470815, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint388, viewCenter388)
    
    scaleAboutPoint389 = NXOpen.Point3d(51.626623174290444, 44.085655744339128, 0.0)
    viewCenter389 = NXOpen.Point3d(-51.626623174292646, -44.085655744338588, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint389, viewCenter389)
    
    scaleAboutPoint390 = NXOpen.Point3d(45.680860392981565, 55.107069680423834, 0.0)
    viewCenter390 = NXOpen.Point3d(-45.680860392983732, -55.10706968042328, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint390, viewCenter390)
    
    scaleAboutPoint391 = NXOpen.Point3d(40.025134820517124, 44.085655744339121, 0.0)
    viewCenter391 = NXOpen.Point3d(-40.025134820519249, -44.085655744338553, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint391, viewCenter391)
    
    scaleAboutPoint392 = NXOpen.Point3d(-2.320297670755791, 26.915452980754527, 0.0)
    viewCenter392 = NXOpen.Point3d(2.3202976707536145, -26.915452980753972, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint392, viewCenter392)
    
    scaleAboutPoint393 = NXOpen.Point3d(-2.9003720884444415, 33.644316225943079, 0.0)
    viewCenter393 = NXOpen.Point3d(2.9003720884422655, -33.644316225942539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint393, viewCenter393)
    
    scaleAboutPoint394 = NXOpen.Point3d(-3.6254651105553046, 42.05539528242879, 0.0)
    viewCenter394 = NXOpen.Point3d(3.6254651105530793, -42.055395282428236, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint394, viewCenter394)
    
    scaleAboutPoint395 = NXOpen.Point3d(-4.5318313881938215, 52.569244103035913, 0.0)
    viewCenter395 = NXOpen.Point3d(4.5318313881916197, -52.569244103035373, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint395, viewCenter395)
    
    scaleAboutPoint396 = NXOpen.Point3d(-5.6647892352419884, 65.711555128794842, 0.0)
    viewCenter396 = NXOpen.Point3d(5.664789235239815, -65.711555128794274, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint396, viewCenter396)
    
    scaleAboutPoint397 = NXOpen.Point3d(-7.0809865440523625, 82.847542565398584, 0.0)
    viewCenter397 = NXOpen.Point3d(7.0809865440500683, -82.847542565397973, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint397, viewCenter397)
    
    scaleAboutPoint398 = NXOpen.Point3d(-5.6647892352419866, 66.278034052318858, 0.0)
    viewCenter398 = NXOpen.Point3d(5.6647892352398612, -66.278034052318375, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint398, viewCenter398)
    
    scaleAboutPoint399 = NXOpen.Point3d(-4.5318313881938215, 53.022427241855134, 0.0)
    viewCenter399 = NXOpen.Point3d(4.531831388191657, -53.022427241854665, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint399, viewCenter399)
    
    scaleAboutPoint400 = NXOpen.Point3d(-3.6254651105553042, 42.417941793484161, 0.0)
    viewCenter400 = NXOpen.Point3d(3.6254651105531401, -42.417941793483699, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint400, viewCenter400)
    
    scaleAboutPoint401 = NXOpen.Point3d(-27.553534840212834, 23.202976707546988, 0.0)
    viewCenter401 = NXOpen.Point3d(27.553534840210709, -23.202976707546544, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint401, viewCenter401)
    
    scaleAboutPoint402 = NXOpen.Point3d(-22.042827872170538, 18.562381366037627, 0.0)
    viewCenter402 = NXOpen.Point3d(22.042827872168363, -18.562381366037169, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint402, viewCenter402)
    
    markId238 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Create Rectangle")
    
    scaleAboutPoint403 = NXOpen.Point3d(-4.2693477141896903, 48.262191551697477, 0.0)
    viewCenter403 = NXOpen.Point3d(4.2693477141875373, -48.262191551697036, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint403, viewCenter403)
    
    scaleAboutPoint404 = NXOpen.Point3d(-5.3366846427368753, 60.791798973772721, 0.0)
    viewCenter404 = NXOpen.Point3d(5.3366846427346983, -60.791798973772266, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint404, viewCenter404)
    
    scaleAboutPoint405 = NXOpen.Point3d(-21.17271624563751, 90.491609159432571, 0.0)
    viewCenter405 = NXOpen.Point3d(21.172716245635335, -90.49160915943213, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint405, viewCenter405)
    
    scaleAboutPoint406 = NXOpen.Point3d(-26.465895307046576, 113.11451144929063, 0.0)
    viewCenter406 = NXOpen.Point3d(26.465895307044445, -113.11451144929018, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint406, viewCenter406)
    
    scaleAboutPoint407 = NXOpen.Point3d(-4.5318313881938197, 49.850145270120208, 0.0)
    viewCenter407 = NXOpen.Point3d(4.5318313881916561, -49.850145270119746, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint407, viewCenter407)
    
    scaleAboutPoint408 = NXOpen.Point3d(-16.427888782199723, 33.988735411445674, 0.0)
    viewCenter408 = NXOpen.Point3d(16.427888782197549, -33.988735411445191, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint408, viewCenter408)
    
    scaleAboutPoint409 = NXOpen.Point3d(-163.57078916758212, -145.16022415304792, 0.0)
    viewCenter409 = NXOpen.Point3d(163.57078916758013, 145.1602241530484, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint409, viewCenter409)
    
    scaleAboutPoint410 = NXOpen.Point3d(-204.46348645947748, -181.45028019130996, 0.0)
    viewCenter410 = NXOpen.Point3d(204.46348645947535, 181.45028019131041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint410, viewCenter410)
    
    scaleAboutPoint411 = NXOpen.Point3d(-255.57935807434643, -226.81285023913753, 0.0)
    viewCenter411 = NXOpen.Point3d(255.57935807434447, 226.81285023913799, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint411, viewCenter411)
    
    scaleAboutPoint412 = NXOpen.Point3d(-319.47419759293308, -283.51606279892189, 0.0)
    viewCenter412 = NXOpen.Point3d(319.47419759293069, 283.51606279892241, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint412, viewCenter412)
    
    scaleAboutPoint413 = NXOpen.Point3d(-399.34274699116605, -338.83627017432144, 0.0)
    viewCenter413 = NXOpen.Point3d(399.34274699116366, 338.8362701743219, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint413, viewCenter413)
    
    scaleAboutPoint414 = NXOpen.Point3d(-371.68264330346625, -136.13957283789691, 0.0)
    viewCenter414 = NXOpen.Point3d(371.68264330346403, 136.13957283789728, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint414, viewCenter414)
    
    scaleAboutPoint415 = NXOpen.Point3d(-297.34611464277333, -108.91165827031769, 0.0)
    viewCenter415 = NXOpen.Point3d(297.346114642771, 108.91165827031784, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint415, viewCenter415)
    
    scaleAboutPoint416 = NXOpen.Point3d(-237.87689171421889, -87.129326616254033, 0.0)
    viewCenter416 = NXOpen.Point3d(237.87689171421653, 87.129326616254261, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint416, viewCenter416)
    
    scaleAboutPoint417 = NXOpen.Point3d(-190.30151337137511, -69.70346129300323, 0.0)
    viewCenter417 = NXOpen.Point3d(190.30151337137312, 69.703461293003414, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint417, viewCenter417)
    
    scaleAboutPoint418 = NXOpen.Point3d(-109.7552914327936, -21.242959632153315, 0.0)
    viewCenter418 = NXOpen.Point3d(109.75529143279148, 21.242959632153539, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint418, viewCenter418)
    
    scaleAboutPoint419 = NXOpen.Point3d(-87.80423314623512, -16.994367705722592, 0.0)
    viewCenter419 = NXOpen.Point3d(87.804233146232946, 16.994367705722834, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint419, viewCenter419)
    
    scaleAboutPoint420 = NXOpen.Point3d(-70.243386516988281, -13.595494164578072, 0.0)
    viewCenter420 = NXOpen.Point3d(70.243386516986249, 13.595494164578314, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint420, viewCenter420)
    
    scaleAboutPoint421 = NXOpen.Point3d(-56.194709213590791, -10.876395331662382, 0.0)
    viewCenter421 = NXOpen.Point3d(56.19470921358878, 10.876395331662691, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint421, viewCenter421)
    
    theSession.SetUndoMarkVisibility(markId238, "Create Rectangle", NXOpen.Session.MarkVisibility.Visible)
    
    # ----------------------------------------------
    # Creating rectangle using By 3 Points method 
    # ----------------------------------------------
    startPoint28 = NXOpen.Point3d(5.0, 4.0, 20.000000000000007)
    endPoint28 = NXOpen.Point3d(5.0000000000000426, 92.0, 20.000000000000007)
    line30 = workPart.Curves.CreateLine(startPoint28, endPoint28)
    
    startPoint29 = NXOpen.Point3d(5.0000000000000426, 92.0, 20.000000000000007)
    endPoint29 = NXOpen.Point3d(45.0, 92.0, 20.000000000000007)
    line31 = workPart.Curves.CreateLine(startPoint29, endPoint29)
    
    startPoint30 = NXOpen.Point3d(45.0, 92.0, 20.000000000000007)
    endPoint30 = NXOpen.Point3d(44.999999999999879, 3.9999999999999467, 20.000000000000007)
    line32 = workPart.Curves.CreateLine(startPoint30, endPoint30)
    
    startPoint31 = NXOpen.Point3d(44.999999999999879, 3.9999999999999467, 20.000000000000007)
    endPoint31 = NXOpen.Point3d(5.0, 4.0, 20.000000000000007)
    line33 = workPart.Curves.CreateLine(startPoint31, endPoint31)
    
    theSession.ActiveSketch.AddGeometry(line30, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line31, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line32, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    theSession.ActiveSketch.AddGeometry(line33, NXOpen.Sketch.InferConstraintsOption.InferNoConstraints)
    
    geom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_36.Geometry = line30
    geom1_36.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_36.SplineDefiningPointIndex = 0
    geom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_36.Geometry = line31
    geom2_36.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint75 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_36, geom2_36)
    
    geom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_37.Geometry = line31
    geom1_37.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_37.SplineDefiningPointIndex = 0
    geom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_37.Geometry = line32
    geom2_37.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint76 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_37, geom2_37)
    
    geom1_38 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_38.Geometry = line32
    geom1_38.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_38.SplineDefiningPointIndex = 0
    geom2_38 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_38.Geometry = line33
    geom2_38.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_38.SplineDefiningPointIndex = 0
    sketchGeometricConstraint77 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_38, geom2_38)
    
    geom1_39 = NXOpen.Sketch.ConstraintGeometry()
    
    geom1_39.Geometry = line33
    geom1_39.PointType = NXOpen.Sketch.ConstraintPointType.EndVertex
    geom1_39.SplineDefiningPointIndex = 0
    geom2_39 = NXOpen.Sketch.ConstraintGeometry()
    
    geom2_39.Geometry = line30
    geom2_39.PointType = NXOpen.Sketch.ConstraintPointType.StartVertex
    geom2_39.SplineDefiningPointIndex = 0
    sketchGeometricConstraint78 = theSession.ActiveSketch.CreateCoincidentConstraint(geom1_39, geom2_39)
    
    geom31 = NXOpen.Sketch.ConstraintGeometry()
    
    geom31.Geometry = line31
    geom31.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    geom31.SplineDefiningPointIndex = 0
    sketchGeometricConstraint79 = theSession.ActiveSketch.CreateHorizontalConstraint(geom31)
    
    conGeom1_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_36.Geometry = line30
    conGeom1_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_36.SplineDefiningPointIndex = 0
    conGeom2_36 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_36.Geometry = line31
    conGeom2_36.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_36.SplineDefiningPointIndex = 0
    sketchGeometricConstraint80 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_36, conGeom2_36)
    
    conGeom1_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_37.Geometry = line31
    conGeom1_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_37.SplineDefiningPointIndex = 0
    conGeom2_37 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_37.Geometry = line32
    conGeom2_37.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_37.SplineDefiningPointIndex = 0
    sketchGeometricConstraint81 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_37, conGeom2_37)
    
    conGeom1_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_38.Geometry = line32
    conGeom1_38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_38.SplineDefiningPointIndex = 0
    conGeom2_38 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_38.Geometry = line33
    conGeom2_38.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_38.SplineDefiningPointIndex = 0
    sketchGeometricConstraint82 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_38, conGeom2_38)
    
    conGeom1_39 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom1_39.Geometry = line33
    conGeom1_39.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom1_39.SplineDefiningPointIndex = 0
    conGeom2_39 = NXOpen.Sketch.ConstraintGeometry()
    
    conGeom2_39.Geometry = line30
    conGeom2_39.PointType = NXOpen.Sketch.ConstraintPointType.NotSet
    conGeom2_39.SplineDefiningPointIndex = 0
    sketchGeometricConstraint83 = theSession.ActiveSketch.CreatePerpendicularConstraint(conGeom1_39, conGeom2_39)
    
    dimObject1_21 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_21.Geometry = line30
    dimObject1_21.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_21.AssocValue = 0
    dimObject1_21.HelpPoint.X = 0.0
    dimObject1_21.HelpPoint.Y = 0.0
    dimObject1_21.HelpPoint.Z = 0.0
    dimObject1_21.View = NXOpen.NXObject.Null
    dimObject2_18 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_18.Geometry = line30
    dimObject2_18.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_18.AssocValue = 0
    dimObject2_18.HelpPoint.X = 0.0
    dimObject2_18.HelpPoint.Y = 0.0
    dimObject2_18.HelpPoint.Z = 0.0
    dimObject2_18.View = NXOpen.NXObject.Null
    dimOrigin21 = NXOpen.Point3d(17.332290769759116, 47.999999999999993, 20.000000000000007)
    sketchDimensionalConstraint21 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_21, dimObject2_18, dimOrigin21, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint15 = sketchDimensionalConstraint21
    dimension21 = sketchHelpedDimensionalConstraint15.AssociatedDimension
    
    expression128 = sketchHelpedDimensionalConstraint15.AssociatedExpression
    
    dimObject1_22 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject1_22.Geometry = line31
    dimObject1_22.AssocType = NXOpen.Sketch.AssocType.StartPoint
    dimObject1_22.AssocValue = 0
    dimObject1_22.HelpPoint.X = 0.0
    dimObject1_22.HelpPoint.Y = 0.0
    dimObject1_22.HelpPoint.Z = 0.0
    dimObject1_22.View = NXOpen.NXObject.Null
    dimObject2_19 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_19.Geometry = line31
    dimObject2_19.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_19.AssocValue = 0
    dimObject2_19.HelpPoint.X = 0.0
    dimObject2_19.HelpPoint.Y = 0.0
    dimObject2_19.HelpPoint.Z = 0.0
    dimObject2_19.View = NXOpen.NXObject.Null
    dimOrigin22 = NXOpen.Point3d(25.000000000000021, 79.667709230240902, 20.000000000000007)
    sketchDimensionalConstraint22 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.ParallelDim, dimObject1_22, dimObject2_19, dimOrigin22, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    sketchHelpedDimensionalConstraint16 = sketchDimensionalConstraint22
    dimension22 = sketchHelpedDimensionalConstraint16.AssociatedDimension
    
    expression129 = sketchHelpedDimensionalConstraint16.AssociatedExpression
    
    dimObject1_23 = NXOpen.Sketch.DimensionGeometry()
    
    datumAxis3 = workPart.Datums.FindObject("SKETCH(13:1B) X axis")
    dimObject1_23.Geometry = datumAxis3
    dimObject1_23.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject1_23.AssocValue = 0
    dimObject1_23.HelpPoint.X = 73.575000000000003
    dimObject1_23.HelpPoint.Y = -2.2413700126928761e-45
    dimObject1_23.HelpPoint.Z = 20.000000000000007
    dimObject1_23.View = NXOpen.NXObject.Null
    dimObject2_20 = NXOpen.Sketch.DimensionGeometry()
    
    dimObject2_20.Geometry = line30
    dimObject2_20.AssocType = NXOpen.Sketch.AssocType.EndPoint
    dimObject2_20.AssocValue = 0
    dimObject2_20.HelpPoint.X = 5.0000000000000426
    dimObject2_20.HelpPoint.Y = 92.0
    dimObject2_20.HelpPoint.Z = 20.000000000000007
    dimObject2_20.View = NXOpen.NXObject.Null
    dimOrigin23 = NXOpen.Point3d(16.548673555607117, 11.548673555607111, 20.000000000000007)
    sketchDimensionalConstraint23 = theSession.ActiveSketch.CreateDimension(NXOpen.Sketch.ConstraintType.AngularDim, dimObject1_23, dimObject2_20, dimOrigin23, NXOpen.Expression.Null, NXOpen.Sketch.DimensionOption.CreateAsAutomatic)
    
    dimension23 = sketchDimensionalConstraint23.AssociatedDimension
    
    expression130 = sketchDimensionalConstraint23.AssociatedExpression
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = False
    
    theSession.ActiveSketch.Update()
    
    theSession.Preferences.Sketch.AutoDimensionsToArcCenter = True
    
    geoms11 = [NXOpen.SmartObject.Null] * 4 
    geoms11[0] = line30
    geoms11[1] = line31
    geoms11[2] = line32
    geoms11[3] = line33
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms11)
    
    geoms12 = [NXOpen.SmartObject.Null] * 4 
    geoms12[0] = line30
    geoms12[1] = line31
    geoms12[2] = line32
    geoms12[3] = line33
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms12)
    
    scaleAboutPoint422 = NXOpen.Point3d(-10.513848820608191, -67.796197567362967, 0.0)
    viewCenter422 = NXOpen.Point3d(10.513848820606087, 67.796197567363279, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint422, viewCenter422)
    
    scaleAboutPoint423 = NXOpen.Point3d(-16.767776136314094, -91.089810902673591, 0.0)
    viewCenter423 = NXOpen.Point3d(16.767776136312087, 91.089810902673889, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint423, viewCenter423)
    
    scaleAboutPoint424 = NXOpen.Point3d(-50.983103117169193, -105.36507977548067, 0.0)
    viewCenter424 = NXOpen.Point3d(50.983103117167069, 105.36507977548095, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint424, viewCenter424)
    
    scaleAboutPoint425 = NXOpen.Point3d(-40.786482493735591, -83.838880681565215, 0.0)
    viewCenter425 = NXOpen.Point3d(40.78648249373343, 83.838880681565527, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint425, viewCenter425)
    
    scaleAboutPoint426 = NXOpen.Point3d(-32.629185994988724, -67.071104545252112, 0.0)
    viewCenter426 = NXOpen.Point3d(32.629185994986493, 67.071104545252481, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint426, viewCenter426)
    
    scaleAboutPoint427 = NXOpen.Point3d(-26.103348795991174, -53.656883636201663, 0.0)
    viewCenter427 = NXOpen.Point3d(26.103348795989, 53.656883636201982, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint427, viewCenter427)
    
    scaleAboutPoint428 = NXOpen.Point3d(-21.346738570944083, -32.716197157640764, 0.0)
    viewCenter428 = NXOpen.Point3d(21.346738570941948, 32.716197157641041, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint428, viewCenter428)
    
    markId239 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Profile short list")
    
    markId240 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Sketch Drag")
    
    theSession.SetUndoMarkVisibility(markId240, "Sketch Drag", NXOpen.Session.MarkVisibility.Visible)
    
    perpendicularDimension3 = theSession.ActiveSketch.FindObject("ENTITY 26 2 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension3)
    
    perpendicularDimension4 = theSession.ActiveSketch.FindObject("ENTITY 26 1 1")
    theSession.UpdateManager.LogForUpdate(perpendicularDimension4)
    
    parallelDimension8 = dimension21
    theSession.UpdateManager.LogForUpdate(parallelDimension8)
    
    parallelDimension9 = dimension22
    theSession.UpdateManager.LogForUpdate(parallelDimension9)
    
    startPoint32 = NXOpen.Point3d(4.676242305535645, 4.0, 20.000000000000007)
    endPoint32 = NXOpen.Point3d(4.6762423055356308, 95.55328904093912, 20.000000000000007)
    line30.SetEndpoints(startPoint32, endPoint32)
    
    startPoint33 = NXOpen.Point3d(44.676242305535588, 95.55328904093912, 20.000000000000007)
    endPoint33 = NXOpen.Point3d(44.676242305535482, 3.9999999999999472, 20.000000000000007)
    line32.SetEndpoints(startPoint33, endPoint33)
    
    startPoint34 = NXOpen.Point3d(4.6762423055356308, 95.55328904093912, 20.000000000000007)
    endPoint34 = NXOpen.Point3d(44.676242305535588, 95.55328904093912, 20.000000000000007)
    line31.SetEndpoints(startPoint34, endPoint34)
    
    sketchHelpedDimensionalConstraint17 = theSession.ActiveSketch.FindObject("ENTITY 243 3 1")
    sketchHelpedDimensionalConstraint17.Refresh()
    
    sketchHelpedDimensionalConstraint18 = theSession.ActiveSketch.FindObject("ENTITY 243 4 1")
    sketchHelpedDimensionalConstraint18.Refresh()
    
    nErrs12 = theSession.UpdateManager.DoUpdate(markId240)
    
    geoms13 = [NXOpen.SmartObject.Null] * 3 
    geoms13[0] = line30
    geoms13[1] = line32
    geoms13[2] = line31
    theSession.ActiveSketch.UpdateGeometryDisplay(geoms13)
    
    geoms14 = [NXOpen.SmartObject.Null] * 3 
    geoms14[0] = line30
    geoms14[1] = line32
    geoms14[2] = line31
    theSession.ActiveSketch.UpdateConstraintDisplay(geoms14)
    
    geoms15 = [NXOpen.SmartObject.Null] * 3 
    geoms15[0] = line30
    geoms15[1] = line32
    geoms15[2] = line31
    theSession.ActiveSketch.UpdateDimensionDisplay(geoms15)
    
    # ----------------------------------------------
    #   Menu: Insert->Design Feature->Extrude...
    # ----------------------------------------------
    markId241 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Start")
    
    extrudeBuilder10 = workPart.Features.CreateExtrudeBuilder(NXOpen.Features.Feature.Null)
    
    section10 = workPart.Sections.CreateSection(0.0094999999999999998, 0.01, 0.5)
    
    extrudeBuilder10.Section = section10
    
    extrudeBuilder10.AllowSelfIntersectingSection(True)
    
    expression131 = workPart.Expressions.CreateSystemExpressionWithUnits("2.00", unit2)
    
    extrudeBuilder10.DistanceTolerance = 0.01
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies24 = [NXOpen.Body.Null] * 1 
    targetBodies24[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies24)
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("10")
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("-120")
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Create
    
    targetBodies25 = [NXOpen.Body.Null] * 1 
    targetBodies25[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies25)
    
    extrudeBuilder10.Draft.FrontDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Draft.BackDraftAngle.SetFormula("2")
    
    extrudeBuilder10.Offset.StartOffset.SetFormula("0")
    
    extrudeBuilder10.Offset.EndOffset.SetFormula("5")
    
    smartVolumeProfileBuilder10 = extrudeBuilder10.SmartVolumeProfile
    
    smartVolumeProfileBuilder10.OpenProfileSmartVolumeOption = False
    
    smartVolumeProfileBuilder10.CloseProfileRule = NXOpen.GeometricUtilities.SmartVolumeProfileBuilder.CloseProfileRuleType.Fci
    
    theSession.SetUndoMarkName(markId241, "Extrude Dialog")
    
    section10.DistanceTolerance = 0.01
    
    section10.ChainingTolerance = 0.0094999999999999998
    
    section10.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves)
    
    markId242 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    curves16 = [NXOpen.ICurve.Null] * 4 
    curves16[0] = line30
    curves16[1] = line33
    curves16[2] = line31
    curves16[3] = line32
    seedPoint16 = NXOpen.Point3d(18.009575638868959, 34.517763013646338, 20.000000000000007)
    regionBoundaryRule16 = workPart.ScRuleFactory.CreateRuleRegionBoundary(theSession.ActiveSketch, curves16, seedPoint16, 0.01)
    
    section10.AllowSelfIntersection(True)
    
    rules19 = [None] * 1 
    rules19[0] = regionBoundaryRule16
    helpPoint19 = NXOpen.Point3d(0.0, 0.0, 0.0)
    section10.AddToSection(rules19, NXOpen.NXObject.Null, NXOpen.NXObject.Null, NXOpen.NXObject.Null, helpPoint19, NXOpen.Section.Mode.Create, False)
    
    theSession.DeleteUndoMark(markId242, None)
    
    markId243 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "section mark")
    
    markId244 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, None)
    
    theSession.DeleteUndoMark(markId244, None)
    
    direction26 = workPart.Directions.CreateDirection(theSession.ActiveSketch, NXOpen.Sense.Forward, NXOpen.SmartObject.UpdateOption.WithinModeling)
    
    extrudeBuilder10.Direction = direction26
    
    expression132 = workPart.Expressions.CreateSystemExpressionWithUnits("0", unit1)
    
    theSession.DeleteUndoMark(markId243, None)
    
    scaleAboutPoint429 = NXOpen.Point3d(-93.183154457508778, -11.87992407426378, 0.0)
    viewCenter429 = NXOpen.Point3d(93.183154457506689, 11.87992407426408, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint429, viewCenter429)
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies26 = [NXOpen.Body.Null] * 1 
    targetBodies26[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies26)
    
    rotMatrix31 = NXOpen.Matrix3x3()
    
    rotMatrix31.Xx = 1.0
    rotMatrix31.Xy = 0.0
    rotMatrix31.Xz = 0.0
    rotMatrix31.Yx = 0.0
    rotMatrix31.Yy = 0.45604750690379026
    rotMatrix31.Yz = 0.88995543228121121
    rotMatrix31.Zx = 0.0
    rotMatrix31.Zy = -0.88995543228121121
    rotMatrix31.Zz = 0.45604750690379026
    translation31 = NXOpen.Point3d(-96.234222471610806, -26.928125399098064, 3.7294196597682152)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix31, translation31, 1.1402990946729603)
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies27 = [NXOpen.Body.Null] * 1 
    targetBodies27[0] = body2
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies27)
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("10")
    
    extrudeBuilder10.Limits.StartExtend.Value.SetFormula("0")
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies28 = [NXOpen.Body.Null] * 1 
    targetBodies28[0] = NXOpen.Body.Null
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies28)
    
    extrudeBuilder10.Limits.EndExtend.Value.SetFormula("-10")
    
    scaleAboutPoint430 = NXOpen.Point3d(-54.294965495660442, -5.8007441768865133, 0.0)
    viewCenter430 = NXOpen.Point3d(54.294965495658303, 5.8007441768868304, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint430, viewCenter430)
    
    scaleAboutPoint431 = NXOpen.Point3d(-77.729971970282634, -4.640595341509159, 0.0)
    viewCenter431 = NXOpen.Point3d(77.729971970280531, 4.6405953415095054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint431, viewCenter431)
    
    scaleAboutPoint432 = NXOpen.Point3d(-62.648037110377267, -3.9445060402827612, 0.0)
    viewCenter432 = NXOpen.Point3d(62.648037110375135, 3.9445060402830978, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint432, viewCenter432)
    
    scaleAboutPoint433 = NXOpen.Point3d(-50.118429688302008, -3.3412286458865568, 0.0)
    viewCenter433 = NXOpen.Point3d(50.118429688299919, 3.3412286458869054, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint433, viewCenter433)
    
    scaleAboutPoint434 = NXOpen.Point3d(-40.243242801570112, -2.9699810185658015, 0.0)
    viewCenter434 = NXOpen.Point3d(40.243242801568037, 2.9699810185661435, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint434, viewCenter434)
    
    scaleAboutPoint435 = NXOpen.Point3d(-32.194594241256297, -2.4947840555952641, 0.0)
    viewCenter435 = NXOpen.Point3d(32.194594241254237, 2.4947840555955985, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(1.25, scaleAboutPoint435, viewCenter435)
    
    extrudeBuilder10.BooleanOperation.Type = NXOpen.GeometricUtilities.BooleanOperation.BooleanType.Subtract
    
    targetBodies29 = [NXOpen.Body.Null] * 1 
    targetBodies29[0] = body2
    extrudeBuilder10.BooleanOperation.SetTargetBodies(targetBodies29)
    
    rotMatrix32 = NXOpen.Matrix3x3()
    
    rotMatrix32.Xx = 1.0
    rotMatrix32.Xy = 0.0
    rotMatrix32.Xz = 0.0
    rotMatrix32.Yx = 0.0
    rotMatrix32.Yy = 0.069244382894193712
    rotMatrix32.Yz = 0.9975997270637168
    rotMatrix32.Zx = 0.0
    rotMatrix32.Zy = -0.9975997270637168
    rotMatrix32.Zz = 0.069244382894193712
    translation32 = NXOpen.Point3d(-57.221108683169028, -9.5122823696917962, 15.8259715001609)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix32, translation32, 2.7839333366039067)
    
    markId245 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    theSession.DeleteUndoMark(markId245, None)
    
    markId246 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Extrude")
    
    extrudeBuilder10.ParentFeatureInternal = False
    
    markId247 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Invisible, "Deactivate Sketch")
    
    feature18 = extrudeBuilder10.CommitFeature()
    
    theSession.DeleteUndoMark(markId246, None)
    
    theSession.SetUndoMarkName(markId241, "Extrude")
    
    expression133 = extrudeBuilder10.Limits.StartExtend.Value
    expression134 = extrudeBuilder10.Limits.EndExtend.Value
    extrudeBuilder10.Destroy()
    
    workPart.Expressions.Delete(expression131)
    
    workPart.Expressions.Delete(expression132)
    
    scaleAboutPoint436 = NXOpen.Point3d(-42.577647882162992, -0.28511817778216419, 0.0)
    viewCenter436 = NXOpen.Point3d(42.577647882160882, 0.28511817778249648, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint436, viewCenter436)
    
    scaleAboutPoint437 = NXOpen.Point3d(-52.152866686019735, -0.35639772222775584, 0.0)
    viewCenter437 = NXOpen.Point3d(52.152866686017589, 0.35639772222809013, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint437, viewCenter437)
    
    scaleAboutPoint438 = NXOpen.Point3d(-64.745586204739496, -0.44549715278472019, 0.0)
    viewCenter438 = NXOpen.Point3d(64.74558620473735, 0.44549715278506202, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint438, viewCenter438)
    
    scaleAboutPoint439 = NXOpen.Point3d(-79.818239873961858, -0.55687144098094765, 0.0)
    viewCenter439 = NXOpen.Point3d(79.818239873959712, 0.55687144098129582, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint439, viewCenter439)
    
    rotMatrix33 = NXOpen.Matrix3x3()
    
    rotMatrix33.Xx = 0.99625866514689909
    rotMatrix33.Xy = -0.085724381642694691
    rotMatrix33.Xz = 0.010954565792240613
    rotMatrix33.Yx = 0.034453928696181947
    rotMatrix33.Yy = 0.51022624235277692
    rotMatrix33.Yz = 0.85934981725253423
    rotMatrix33.Zx = -0.079256538639517399
    rotMatrix33.Zy = -0.855757274001538
    rotMatrix33.Zz = 0.51127085686193741
    translation33 = NXOpen.Point3d(-113.15866135125339, -29.328621903323707, 6.1085983904372618)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix33, translation33, 1.1402990946729605)
    
    scaleAboutPoint440 = NXOpen.Point3d(-104.18136541688597, 8.1210418476415391, 0.0)
    viewCenter440 = NXOpen.Point3d(104.18136541688375, -8.1210418476412034, 0.0)
    workPart.ModelingViews.WorkView.ZoomAboutPoint(0.80000000000000004, scaleAboutPoint440, viewCenter440)
    
    # ----------------------------------------------
    #   Menu: Edit->Show and Hide->Hide...
    # ----------------------------------------------
    markId248 = theSession.SetUndoMark(NXOpen.Session.MarkVisibility.Visible, "Hide")
    
    objects8 = [NXOpen.DisplayableObject.Null] * 1 
    objects8[0] = sketch11
    theSession.DisplayManager.BlankObjects(objects8)
    
    workPart.ModelingViews.WorkView.FitAfterShowOrHide(NXOpen.View.ShowOrHideType.HideOnly)
    
    rotMatrix34 = NXOpen.Matrix3x3()
    
    rotMatrix34.Xx = 0.9927004292121081
    rotMatrix34.Xy = -0.12017962529704519
    rotMatrix34.Xz = 0.010134865838189764
    rotMatrix34.Yx = -0.012923554199903117
    rotMatrix34.Yy = -0.022447668220876162
    rotMatrix34.Yz = 0.99966448568421573
    rotMatrix34.Zx = -0.11991179920649371
    rotMatrix34.Zy = -0.99249834249479107
    rotMatrix34.Zz = -0.023836957778925107
    translation34 = NXOpen.Point3d(-137.41575762096588, -2.9978428176877969, 24.836171782585726)
    workPart.ModelingViews.WorkView.SetRotationTranslationScale(rotMatrix34, translation34, 0.91223927573836849)
    
    # ----------------------------------------------
    #   Menu: Tools->Journal->Stop Recording
    # ----------------------------------------------
    
if __name__ == '__main__':
    main()